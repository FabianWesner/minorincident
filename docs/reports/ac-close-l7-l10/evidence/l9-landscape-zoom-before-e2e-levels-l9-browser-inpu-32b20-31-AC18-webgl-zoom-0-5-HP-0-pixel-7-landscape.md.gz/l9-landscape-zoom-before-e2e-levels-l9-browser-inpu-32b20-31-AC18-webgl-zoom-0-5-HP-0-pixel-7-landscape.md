# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/levels/l9-browser-input.spec.ts >> T-E31-17-input @E31-AC08 @E31-AC09 @E31-AC12 @E31-AC15 @E31-AC16 @E31-AC17 @E31-AC18 webgl zoom=0.5 HP=0
- Location: tests/e2e/levels/l9-browser-input.spec.ts:28:3

# Error details

```
Error: expect(received).toBeCloseTo(expected, precision)

Expected: 0.5
Received: 1

Expected precision:    2
Expected difference: < 0.005
Received difference:   0.5
```

# Page snapshot

```yaml
- generic [active]:
  - generic:
    - generic:
      - text: N ▲
      - generic "Objective direction": ➜
    - button "Pause" [ref=e2] [cursor=pointer]: Ⅱ
    - button "Home" [ref=e3] [cursor=pointer]
    - generic:
      - generic "Vehicle durability":
        - meter "durability":
          - generic: Barely functional
      - generic:
        - generic "Survivor portrait"
        - generic:
          - meter "health":
            - generic: 100 / 100
        - generic "Corgi · hiding": 🐕
      - generic:
        - button "North-up minimap, range 30 meters" [expanded] [ref=e6] [cursor=pointer]:
          - generic [ref=e7]: "N"
          - generic [ref=e8]: ▲
          - generic [ref=e10]: ⌂
        - status: ≈ Wind
        - button "Drive toward the city · 1020 m" [ref=e11] [cursor=pointer]
  - generic:
    - button "Touch left" [ref=e13] [cursor=pointer]:
      - generic: BOOST
    - button "Touch right" [ref=e14] [cursor=pointer]:
      - generic: DRIFT
    - button "ACTION" [disabled] [ref=e15] [cursor=pointer]
```

# Test source

```ts
  1   | import { mkdirSync, writeFileSync } from 'node:fs';
  2   | import type { Page } from '@playwright/test';
  3   | import { boot, expect, test } from '../fixtures';
  4   | import { tick as inputTick } from '../input-helpers';
  5   | import { crossing } from '../../../src/levels/L9/district';
  6   | import { l9Readability } from '../../helpers/l9-readability';
  7   | import { Recorder } from '../../../src/input/Recorder';
  8   | import { preset } from '../../../src/sim/progression/Campaign';
  9   | import type { Game } from '../../../src/Game';
  10  | 
  11  | // Native headless GPU, including an explicit backend assertion (no silent fallback).
  12  | test.use({ launchOptions: { args: ['--use-angle=metal', '--enable-unsafe-webgpu', '--enable-gpu', '--ignore-gpu-blocklist'] } });
  13  | const out = 'test-results/epics/E31/Q3';
  14  | async function tick(page: Page, ticks = 1) {
  15  |   // Fixed input stepping pauses the RAF clock; advance the existing render clock for smoke/trails too.
  16  |   await page.evaluate(n => window.__SS__!.vfx.stepRender(Math.min(1, n / 60)), ticks);
  17  |   return inputTick(page, ticks);
  18  | }
  19  | async function homeClear(page: Page) {
  20  |   const home = page.getByTestId('home-button'); await expect(home).toBeVisible();
  21  |   const h = (await home.boundingBox())!;
  22  |   for (const id of ['minimap', 'vitals', 'corgi-companion', 'objective-tracker', 'pause-button', 'vehicle-durability']) {
  23  |     const b = await page.getByTestId(id).boundingBox();
  24  |     if (b) expect(h.x < b.x + b.width && h.x + h.width > b.x && h.y < b.y + b.height && h.y + h.height > b.y, `Home overlaps ${id}`).toBe(false);
  25  |   }
  26  | }
  27  | for (const backend of ['webgl', 'webgpu'] as const) for (const zoom of [1, .5, 1.5]) for (const hp of [1000, 0]) {
  28  |   test(`T-E31-17-input @E31-AC08 @E31-AC09 @E31-AC12 @E31-AC15 @E31-AC16 @E31-AC17 @E31-AC18 ${backend} zoom=${zoom} HP=${hp}`, async ({ page, context }, info) => {
  29  |     test.setTimeout(300_000);
  30  |     const touch = info.project.name.startsWith('pixel'), quality = touch ? 'low' : 'high';
  31  |     // Both projects leave/rejoin the road; keyboard takes the long road, touch the open countryside.
  32  |     const route = crossing.routes.find(r => r.id === (touch ? 'countryside' : 'road'))!.detour;
  33  |     const name = `${info.project.name}-${backend}-z${zoom}-hp${hp}`;
  34  |     mkdirSync(out, { recursive: true });
  35  |     await boot(page, `/?test=1&scenelab=1&ui=1&renderer=${backend}&quality=${quality}&audio=muted&dpr=1`);
  36  |     await page.mouse.click(200, 400);
  37  |     const save = preset('L8-default'); save.completedLevels = 8; save.unlockedLevel = 9; save.settings.quality = quality;
  38  |     await page.evaluate(async ({ save, hp }) => {
  39  |       const api = window.__SS__!, game = (window.__SCENE__ as unknown as { game: Game }).game;
  40  |       game.campaign = save; await api.loadLevel('L9', { seed: 31 }); api.pause();
  41  |       // Initial fixture only. From here to the crash there are no position/mission/input writes.
  42  |       const car = game.world.missions!.l9!.state.carId;
  43  |       game.world.vehicles!.damage(car, 1000 - hp);
  44  |       // Keep speaker output muted by the URL, but enable the actual cue graph after UI setup.
  45  |       api.settings.set({ muted: false, captions: true }); await api.audio.unlock(); api.input.record();
  46  |     }, { save, hp });
  47  |     await tick(page);
  48  |     expect(await page.evaluate(() => window.__SS__!.perf().backend)).toBe(backend);
  49  |     const carId = await page.evaluate(() => window.__SS__!.getState().l9!.carId);
  50  |     await expect(page.getByTestId('durability-label')).toHaveText(hp ? 'Armor 1000 / 1000' : 'Barely functional');
  51  |     await homeClear(page);
  52  |     if (zoom !== 1) {
  53  |       // Wheel notches change zoom by one step regardless of delta magnitude.
  54  |       for (let i = 0; i < 5; i++) await page.mouse.wheel(0, zoom < 1 ? -100 : 100);
  55  |       await tick(page, 60);
  56  |     }
> 57  |     expect(await page.evaluate(() => window.__SS__!.getState().render!.camera.zoom)).toBeCloseTo(zoom, 2);
      |                                                                                      ^ Error: expect(received).toBeCloseTo(expected, precision)
  58  |     await page.evaluate(() => window.__SS__!.screenshotReady());
  59  |     await page.screenshot({ path: `${out}/${name}-start.png` });
  60  |     const floorRead = await l9Readability(page, `${out}/${name}-navigation`, false);
  61  |     expect.soft(floorRead.pairs.length).toBeGreaterThanOrEqual(3);
  62  |     expect.soft(floorRead.navigation).toBeGreaterThanOrEqual(3);
  63  |     const cdp = await context.newCDPSession(page);
  64  |     const origin = { x: 90, y: page.viewportSize()!.height - 240 };
  65  |     async function finger(type: 'touchStart' | 'touchMove' | 'touchEnd', x = origin.x, y = origin.y) {
  66  |       await cdp.send('Input.dispatchTouchEvent', { type, touchPoints: type === 'touchEnd' ? [] : [{ id: 1, x, y, radiusX: 1, radiusY: 1 }] });
  67  |       await cdp.send('Runtime.evaluate', { expression: 'new Promise(r => requestAnimationFrame(r))', awaitPromise: true });
  68  |     }
  69  |     if (touch) await finger('touchStart');
  70  |     else { await page.mouse.move(800, 450); await page.mouse.down(); await page.keyboard.down('KeyW'); }
  71  |     let index = 1, traveled = 0, peakChunks = 0, previousHP = hp;
  72  |     const samples = [];
  73  |     for (let i = 0; i < 1500; i++) {
  74  |       const s = await page.evaluate(id => {
  75  |         const a = window.__SS__!, state = a.getState(), car = a.getEntity(id)!;
  76  |         return { phase: state.l9?.phase, scenario: state.scenario, p: car.transform, hp: car.health.current, speed: car.vehicle!.speed, perf: { terrain: a.perf().terrain } };
  77  |       }, carId);
  78  |       if (s.phase !== 'driving') break;
  79  |       while (index < route.length - 1 && Math.hypot(route[index][0] - s.p.x, route[index][1] - s.p.z) < 8) index++;
  80  |       const dx = route[index][0] - s.p.x, dz = route[index][1] - s.p.z, distance = Math.hypot(dx, dz);
  81  |       const want = -Math.atan2(dz, dx), delta = Math.atan2(Math.sin(want - s.p.yaw), Math.cos(want - s.p.yaw));
  82  |       if (touch) {
  83  |         // Invert the production camera-relative stick transform, then send a real drag.
  84  |         const screen = await page.evaluate(({ dx, dz, distance }) => {
  85  |           const camera = (window.__SCENE__ as unknown as { game: Game }).game.view.camera;
  86  |           const e = camera.matrixWorld.elements, l = Math.hypot(e[8], e[10]), fx = -e[8] / l, fz = -e[10] / l;
  87  |           return { x: (-fz * dx + fx * dz) / distance, y: (-fx * dx - fz * dz) / distance };
  88  |         }, { dx, dz, distance });
  89  |         await finger('touchMove', origin.x + screen.x * 60, origin.y + screen.y * 60); await tick(page, 30);
  90  |       } else {
  91  |         // LevelNineBot's pure pursuit, expressed as real key pulses instead of injected frames.
  92  |         const steer = Math.max(-1, Math.min(1, delta * 2)), n = Math.round(Math.abs(steer) * 30), key = steer > 0 ? 'KeyD' : 'KeyA';
  93  |         if (n) { await page.keyboard.down(key); await tick(page, n); await page.keyboard.up(key); }
  94  |         if (n < 30) await tick(page, 30 - n);
  95  |       }
  96  |       traveled++;
  97  |       peakChunks = Math.max(peakChunks, s.perf.terrain?.resident ?? 0);
  98  |       if (i % 60 === 0) samples.push({ tick: i * 30, at: s.p, hp: s.hp, chunks: s.perf.terrain });
  99  |       expect(s.hp).toBeLessThanOrEqual(previousHP); previousHP = s.hp;
  100 |       if (!hp) { expect(s.hp).toBe(0); expect(s.speed).toBeLessThanOrEqual(10.8 * 1.02); }
  101 |       if (i === 90) { await page.evaluate(() => window.__SS__!.screenshotReady()); await page.screenshot({ path: `${out}/${name}-route.png` }); }
  102 |     }
  103 |     if (touch) await finger('touchEnd'); else { await page.keyboard.up('KeyW'); await page.mouse.up(); }
  104 |     expect(traveled).toBeGreaterThan(100);
  105 |     expect(index).toBe(route.length - 1);
  106 |     expect(peakChunks).toBeLessThanOrEqual(touch ? 9 : 25);
  107 |     expect(await page.evaluate(() => window.__SS__!.getState().l9!.phase)).toBe('approach');
  108 |     const recording = await page.evaluate(() => window.__SS__!.input.stopRecording());
  109 |     writeFileSync(`${out}/${name}.ssrec`, Recorder.serialize(recording));
  110 |     writeFileSync(`${out}/${name}-route.json`, JSON.stringify(samples, null, 2));
  111 |     expect(recording.frames.some(f => touch ? f.aimSource === 'touch' : f.drive?.throttle === 1)).toBe(true);
  112 |     const before = await page.evaluate(() => ({ events: window.__SS__!.events(), audio: window.__SS__!.audio.snapshot() }));
  113 |     writeFileSync(`${out}/${name}-audio.json`, JSON.stringify(before.audio, null, 2));
  114 |     expect(before.events.filter(e => e.type === 'vehicle.exploded' || e.type === 'vehicle.exited')).toHaveLength(0);
  115 |     expect(before.audio.cues.some(c => c.cue === 'vehicle.engine-low')).toBe(true);
  116 |     expect(before.audio.voiceLimit).toBe(touch ? 16 : 32);
  117 |     if (!hp) expect(before.audio.cues.some(c => c.cue === 'vehicle.sputter')).toBe(true);
  118 |     await tick(page, 301);
  119 |     expect(await page.evaluate(() => window.__SS__!.getState().l9!.phase)).toBe('impact');
  120 |     await expect(page.getByTestId('mission-subtitle')).toContainText('bridge gave way');
  121 |     const impact = await page.evaluate(id => ({ car: window.__SS__!.getEntity(id)!, events: window.__SS__!.events(), audio: window.__SS__!.audio.snapshot() }), carId);
  122 |     expect(impact.events.filter(e => e.type === 'vehicle.exploded')).toHaveLength(1);
  123 |     expect(impact.car.vehicle).toMatchObject({ damage: 'exploded', driver: null });
  124 |     expect(impact.audio.cues.some(c => c.cue === 'vehicle.crash')).toBe(true);
  125 |     await expect.poll(() => page.evaluate(() => window.__SS__!.audio.emitters().filter(v => v.loop && (v.cue.startsWith('vehicle.engine-') || v.cue === 'vehicle.sputter')).length)).toBe(0);
  126 |     await page.screenshot({ path: `${out}/${name}-impact.png` });
  127 |     await page.evaluate(() => window.__SS__!.audio.clearLog());
  128 |     await tick(page, 250);
  129 |     expect(await page.evaluate(() => window.__SS__!.getState().player!.survivor!.scriptedClip)).toBe('crawl');
  130 |     expect(await page.evaluate(() => window.__SS__!.audio.snapshot().cues.some(c => c.sourceId === 1 && c.cue.startsWith('footstep.survivor.')))).toBe(true);
  131 |     await page.screenshot({ path: `${out}/${name}-crawl.png` });
  132 |     const crawlRead = await l9Readability(page, `${out}/${name}-crawl-readability`, true);
  133 |     expect.soft(crawlRead.pairs.length).toBeGreaterThanOrEqual(3);
  134 |     expect.soft(crawlRead.navigation).toBeGreaterThanOrEqual(3);
  135 |     expect.soft(crawlRead.playerPixels).toBeGreaterThan(100);
  136 |     expect.soft(crawlRead.playerContrast).toBeGreaterThanOrEqual(3);
  137 |     await tick(page, 400);
  138 |     await expect.poll(() => page.evaluate(() => window.__SS__!.getState().scenario), { timeout: 120_000 }).toBe('L10');
  139 |     await page.evaluate(async () => { window.__SS__!.pause(); await window.__SS__!.step(1); });
  140 |     const end = await page.evaluate(() => ({ state: window.__SS__!.getState(), save: window.__SS__!.campaign.state() }));
  141 |     expect(end.save!.ownedActions.filter(id => id.startsWith('weapon.'))).toEqual(['weapon.fire-axe']);
  142 |     expect(end.save!.ownedActions.filter(id => !id.startsWith('weapon.'))).toEqual(save.ownedActions.filter(id => !id.startsWith('weapon.')));
  143 |     expect(end.save!.upgrades).toEqual(save.upgrades);
  144 |     expect(end.save!.crossingHandover).toMatchObject({ applied: true, checkpoint: 'cure-crash' });
  145 |     expect(end.save!.crossingHandover!.lostWeapons.length).toBeGreaterThan(0);
  146 |     expect(end.save!.pending).toBeUndefined();
  147 |     expect(end.state.entities.some(e => e.companion && e.health.current > 0)).toBe(true);
  148 |     for (const side of ['LEFT', 'RIGHT'] as const) expect(end.state.player!.weapons![side].rack.map(s => s.id)).toEqual(['weapon.fire-axe']);
  149 |     expect(end.state.player!.hidden).not.toBe(true);
  150 |     expect(await page.evaluate(() => (window.__SCENE__ as unknown as { game: Game }).game.world.vehicles!.active)).toBeNull();
  151 |     expect(end.state.player!.health.current).toBe(end.state.player!.health.max);
  152 |     await homeClear(page);
  153 |     await expect(page.getByTestId('weapon-active')).toHaveAttribute('data-weapon', 'weapon.fire-axe');
  154 |     await page.evaluate(() => window.__SS__!.screenshotReady()); await page.screenshot({ path: `${out}/${name}-axe.png` });
  155 |     // The narrow mouse layout reported by Q2 is exercised independently of touch media queries.
  156 |     if (!touch) { await page.setViewportSize({ width: 390, height: 844 }); await tick(page); await homeClear(page); await page.screenshot({ path: `${out}/${name}-narrow.png` }); }
  157 |     await cdp.detach();
```