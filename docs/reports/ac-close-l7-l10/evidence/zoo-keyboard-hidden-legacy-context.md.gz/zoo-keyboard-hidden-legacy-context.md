# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/levels/L8.spec.ts >> T-E30-18 @E30-AC18 real keyboard exploration, tunnel breach and complete APC escape into L9
- Location: tests/e2e/levels/L8.spec.ts:12:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('.mission-tracker')
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" locator('.mission-tracker') with timeout 5000ms
  - waiting for locator('.mission-tracker')
    14 × locator resolved to <div aria-live="polite" class="mission-tracker" data-objective="escape" data-testid="mission-tracker" data-distance="97.73485076164187">Bring the survivors to the armored vehicle and bo…</div>
       - unexpected value "hidden"

```

```yaml
- text: ➜
- button "Pause": Ⅱ
- button "Home"
- text: 1 2 3 4 5 6 7
- meter "health": 100 / 100
- 'button "Active weapon: bat, 0.0s"'
- text: Corgi · following N ▲
- status: ☀ Clear
- text: Bring the survivors to the armored vehicle and board · 98 m
```

# Test source

```ts
  1   | import { mkdirSync, writeFileSync } from 'node:fs';
  2   | import { boot, expect, test } from '../fixtures';
  3   | import type { Page } from '@playwright/test';
  4   | const out = 'test-results/epics/E30';
  5   | /** The campaign handoff resumes the new level; await it instead of stepping the retired zoo. */
  6   | const stepZoo = (page: Page, n: number) => page.evaluate(async n => {
  7   |   const a = window.__SS__!;
  8   |   if (a.getState().scenario !== 'L8' || a.missions.state()?.phase === 'progression') { await a.screenshotReady(); a.pause(); return; }
  9   |   a.pause(); await a.step(n);
  10  | }, n);
  11  | 
  12  | test('T-E30-18 @E30-AC18 real keyboard exploration, tunnel breach and complete APC escape into L9', async ({ page }) => {
  13  |   test.setTimeout(900_000); mkdirSync(out, { recursive: true });
  14  |   await boot(page, '/?test=1&renderer=webgl&dpr=1&quality=high&audio=muted&ui=1');
  15  |   await page.evaluate(async () => { const a = window.__SS__!; await a.loadLevel('L8', { seed: 1, progression: 'L8-default' }); a.pause(); });
  16  |   await page.getByRole('button', { name: 'Begin mission' }).click(); await page.evaluate(() => window.__SS__!.pause());
  17  |   const step = (n: number) => stepZoo(page, n);
  18  |   const shot = async (name: string) => { await page.evaluate(async () => { window.__SS__!.camera.follow(); await window.__SS__!.screenshotReady(); }); await page.screenshot({ path: `${out}/${name}.png` }); };
  19  |   await shot('real-calm');
  20  |   const initial = await page.evaluate(() => window.__SS__!.getState().player!.transform);
  21  |   const initialCorgi = await page.evaluate(() => window.__SS__!.getState().entities.find(e => e.companion));
  22  |   expect(initialCorgi, 'the protected campaign corgi arrives at the zoo').toBeDefined();
  23  |   await page.keyboard.down('w'); await page.keyboard.down('d'); await step(120); await page.keyboard.up('w'); await page.keyboard.up('d');
  24  |   const explored = await page.evaluate(() => window.__SS__!.getState());
  25  |   expect(Math.hypot(explored.player!.transform.x - initial.x, explored.player!.transform.z - initial.z)).toBeGreaterThan(3);
  26  |   // PO #90 (batch13g) deliberately exposes the boarding goal immediately.
  27  |   // Keep the sixty-second incident-free clock; the older no-objective assertion is obsolete.
  28  |   expect(await page.evaluate(() => window.__SS__!.missions.state()!.marker)).toBe('exit');
> 29  |   await expect(page.locator('.mission-tracker')).toBeVisible();
      |                                                  ^ Error: expect(locator).toBeVisible() failed
  30  |   await expect(page.locator('.mission-tracker')).toContainText('Bring the survivors to the armored vehicle');
  31  |   // The protected dog now travels through L7/L8; this must describe the real
  32  |   // follower rather than the obsolete phantom "awaiting rescue" prompt.
  33  |   const corgi = explored.entities.find(e => e.id === initialCorgi!.id)!;
  34  |   expect(corgi, 'the same corgi remains present during calm exploration').toBeDefined();
  35  |   expect(corgi.companion?.state).toBe('follow'); expect(corgi.hidden).not.toBe(true);
  36  |   expect(corgi.health.current).toBe(corgi.health.max);
  37  |   expect(corgi.infected).toBeUndefined(); expect(corgi.infection).toBeUndefined();
  38  |   await expect(page.locator('.hud-companion')).toBeVisible();
  39  |   await expect(page.locator('.hud-companion')).toHaveText('Corgi · following');
  40  |   await expect(page.locator('.hud-pin-objective')).toBeVisible(); await expect(page.locator('.hud-pin-home')).toBeHidden();
  41  |   // The real Begin click can advance a few frames before pause reaches the page.
  42  |   // Measure the exact boundary from the live clock rather than assuming tick 120.
  43  |   const calmClock = await page.evaluate(() => { const s = window.__SS__!.getState(); return { tick: s.tick, start: s.l8!.startedAt }; });
  44  |   const breachTick = calmClock.start + 3600;
  45  |   expect(breachTick).toBe(3600); expect(calmClock.tick).toBeLessThan(breachTick - 1);
  46  |   await step(breachTick - 1 - calmClock.tick);
  47  |   expect(await page.evaluate(() => window.__SS__!.getState().tick)).toBe(breachTick - 1);
  48  |   expect(await page.evaluate(() => window.__SS__!.getState().l8!.breachedAt)).toBe(0);
  49  |   await step(1); const breach = await page.evaluate(() => window.__SS__!.getState().l8!);
  50  |   expect(breach.breachedAt).toBe(3600); expect(new Set(breach.arrivals.map(a => a.outlet)).size).toBe(4);
  51  |   // Physical key movement is computed from the same isometric axes as other real-input campaign gates.
  52  |   for (let i = 0; i < 1500; i++) {
  53  |     const obs = await page.evaluate(() => {
  54  |       const a = window.__SS__!, state = a.getState(), p = state.player!.transform;
  55  |       if (state.scenario !== 'L8') return null;
  56  |       const car = a.getEntity(state.l8!.carId)!, yaw = car.transform.yaw, def = { doorX: .71, width: 2.95 };
  57  |       const door = { x: car.transform.x + Math.cos(yaw) * def.doorX + Math.sin(yaw) * (def.width / 2 + .55), z: car.transform.z - Math.sin(yaw) * def.doorX + Math.cos(yaw) * (def.width / 2 + .55) };
  58  |       const friends = state.l8!.roster.map(id => a.getEntity(id)!).filter(e => e.health.current > 0 && !e.infected && e.passengerOf === undefined);
  59  |       const enemy = a.query({}).filter(e => e.infected && !e.hidden && !e.emerging && e.health.current > 0 && a.input.visible(e.transform) && Math.hypot(e.transform.x - p.x, e.transform.z - p.z) < 15).sort((a,b) => Math.hypot(a.transform.x - p.x,a.transform.z - p.z) - Math.hypot(b.transform.x - p.x,b.transform.z - p.z))[0];
  60  |       return { p, door, car: car.transform, carHP: car.health.current, hp: state.player!.health.current, phase: a.missions.state()!.phase, weapons: state.player!.weapons, tick: state.tick, active: car.vehicle!.driver === 1, friends: friends.map(e => e.transform), enemy: enemy?.transform };
  61  |     });
  62  |     if (!obs) break;
  63  |     if (i % 100 === 0) writeFileSync(`${out}/real-progress.json`, JSON.stringify(obs, null, 2));
  64  |     if (obs.enemy) {
  65  |       const ndc = await page.evaluate(at => window.__SS__!.camera.project(at.x, at.y, at.z), obs.enemy), view = page.viewportSize()!;
  66  |       await page.mouse.move((ndc[0] + 1) * view.width / 2, (1 - ndc[1]) * view.height / 2);
  67  |       await page.keyboard.down('Shift'); await page.keyboard.press('2'); await page.keyboard.up('Shift'); await step(1);
  68  |       await page.mouse.down(); await step(20); await page.mouse.up(); continue;
  69  |     }
  70  |     if (obs.active || (Math.hypot(obs.p.x - obs.door.x, obs.p.z - obs.door.z) > 10 && obs.friends.some(p => Math.hypot(p.x - obs.p.x, p.z - obs.p.z) > 12))) { await step(12); continue; }
  71  |     const target = Math.hypot(obs.p.x - obs.door.x, obs.p.z - obs.door.z) < 10 && obs.p.z < obs.door.z - .5 ? { x: obs.p.x, z: obs.door.z + 1 } : obs.door;
  72  |     const dx = target.x - obs.p.x, dz = target.z - obs.p.z;
  73  |     if (Math.hypot(obs.door.x - obs.p.x, obs.door.z - obs.p.z) < .6) { await shot('real-escape'); await page.keyboard.press('e'); await step(12); continue; }
  74  |     const keys = Math.abs(dx) > Math.abs(dz) ? dx > 0 ? ['s','d'] : ['w','a'] : dz > 0 ? ['s','a'] : ['w','d'];
  75  |     for (const key of keys) await page.keyboard.down(key);
  76  |     await step(Math.min(12, Math.max(2, Math.floor(Math.max(Math.abs(dx), Math.abs(dz)) * 10))));
  77  |     for (const key of keys) await page.keyboard.up(key);
  78  |   }
  79  |   await page.waitForFunction(() => window.__SS__!.getState().scenario === 'L9', undefined, { timeout: 120_000 });
  80  |   await page.evaluate(() => window.__SS__!.pause());
  81  |   const destination = await page.evaluate(() => window.__SS__!.getState());
  82  |   expect(destination.entities.find(e => e.id === breach.carId)!.vehicle!.driver).toBe(1);
  83  |   expect(destination.progression!.campaign!.results!.L8.rescued).toBeGreaterThanOrEqual(8);
  84  |   const carriedCorgi = destination.entities.find(e => e.id === initialCorgi!.id)!;
  85  |   expect(carriedCorgi, 'the same protected dog arrives aboard the crossing APC').toBeDefined();
  86  |   expect(carriedCorgi.companion).toBeDefined(); expect(carriedCorgi.passengerOf).toBe(breach.carId);
  87  |   expect(carriedCorgi.health.current).toBe(carriedCorgi.health.max);
  88  |   expect(carriedCorgi.infected).toBeUndefined(); expect(carriedCorgi.infection).toBeUndefined();
  89  |   writeFileSync(`${out}/real-input.json`, JSON.stringify(destination, null, 2)); await shot('real-l9-arrival');
  90  | });
  91  | 
  92  | test('T-E30-19 @E30-AC19 game camera calm, internal breach and same-id animal turn captures', async ({ page }) => {
  93  |   test.setTimeout(600_000); mkdirSync(out, { recursive: true }); await boot(page);
  94  |   await page.evaluate(async () => { const a = window.__SS__!; await a.loadLevel('L8', { seed: 1, progression: 'L8-default' }); a.pause(); a.cheats.god(true); a.missions.begin(); });
  95  |   const capture = async (name: string, pos: { x: number; z: number }) => {
  96  |     await page.evaluate(async pos => { const a = window.__SS__!; a.teleport(1, pos); await a.step(1); a.camera.cinematic({ position: [pos.x + 19, 23, pos.z + 19], target: [pos.x, .5, pos.z] }, true); await a.screenshotReady(); }, pos);
  97  |     await page.screenshot({ path: `${out}/${name}.png` });
  98  |   };
  99  |   await capture('calm', { x: -60, z: -20 });
  100 |   const animals = await page.evaluate(() => window.__SS__!.getState().l8!.animals);
  101 |   await page.evaluate(() => window.__SS__!.step(3635)); await capture('breach', { x: -99, z: 32 }); await page.evaluate(() => window.__SS__!.teleport(1, { x: 0, z: 70 }));
  102 |   let converting = 0;
  103 |   for (let i = 0; i < 300; i++) {
  104 |     const state = await page.evaluate(ids => ids.map(id => window.__SS__!.getEntity(id)!), animals);
  105 |     const animal = state.find(e => e.infection);
  106 |     if (animal) { converting = animal.id; await capture('animal-turning', animal.transform); writeFileSync(`${out}/animal-turning.json`, JSON.stringify(animal, null, 2)); break; }
  107 |     await page.evaluate(() => window.__SS__!.step(30));
  108 |   }
  109 |   expect(converting).toBeGreaterThan(0);
  110 |   await page.evaluate(() => window.__SS__!.step(240));
  111 |   const infected = await page.evaluate(id => window.__SS__!.getEntity(id)!, converting);
  112 |   expect(infected.infected).toBeTruthy(); await capture('animal-infected', infected.transform);
  113 |   writeFileSync(`${out}/animal-infected.json`, JSON.stringify(infected, null, 2));
  114 | });
  115 | 
  116 | test.describe('phone escape input', () => {
  117 |   test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  118 |   test('T-E30-18-mobile @E30-AC18 touch stick reaches the APC ACTION with no HUD overflow', async ({ page, context }) => {
  119 |     test.setTimeout(600_000); await boot(page, '/?test=1&renderer=webgl&dpr=1&quality=low&audio=muted&ui=1');
  120 |     await page.evaluate(async () => { const a = window.__SS__!; await a.loadLevel('L8', { seed: 1, progression: 'L8-default' }); a.pause(); a.missions.begin(); await a.step(3600); });
  121 |     const cdp = await context.newCDPSession(page);
  122 |     for (let i = 0; i < 300; i++) {
  123 |       const obs = await page.evaluate(() => {
  124 |         const a = window.__SS__!, state = a.getState(); if (state.scenario !== 'L8') return null;
  125 |         const p = state.player!.transform, car = a.getEntity(state.l8!.carId)!, yaw = car.transform.yaw;
  126 |         const door = { x: car.transform.x + Math.cos(yaw) * .71 + Math.sin(yaw) * 2.025, z: car.transform.z - Math.sin(yaw) * .71 + Math.cos(yaw) * 2.025 };
  127 |         const dx = door.x - p.x, dz = door.z - p.z, distance = Math.hypot(dx, dz), next = distance > 1 ? { x: p.x + dx / distance * 3, z: p.z + dz / distance * 3 } : door;
  128 |         const origin = a.input.project(p), target = a.input.project(next);
  129 |         return { distance, screen: { x: target.x - origin.x, y: target.y - origin.y }, active: car.vehicle!.driver === 1 };
```