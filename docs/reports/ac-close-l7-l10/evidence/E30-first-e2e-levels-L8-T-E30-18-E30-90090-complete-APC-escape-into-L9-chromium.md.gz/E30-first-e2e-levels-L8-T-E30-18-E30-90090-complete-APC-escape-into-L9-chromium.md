# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/levels/L8.spec.ts >> T-E30-18 @E30-AC18 real keyboard exploration, tunnel breach and complete APC escape into L9
- Location: tests/e2e/levels/L8.spec.ts:12:1

# Error details

```
Error: expect(received).toBeNull()

Received: "exit"
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - generic:
      - text: N ▲
      - generic "Objective direction": ➜
    - button "Pause" [ref=e4] [cursor=pointer]: Ⅱ
    - button "Home" [ref=e5] [cursor=pointer]
    - generic:
      - generic "Carried weapons and number keys":
        - generic "unarmed · 1": "1"
        - generic "bat · 2": "2"
        - generic "fire axe · 3": "3"
        - generic "Handgun · 4": "4"
        - generic "Machine gun · 5": "5"
        - generic "shotgun · 6": "6"
        - generic "rocket launcher · 7": "7"
      - generic:
        - generic "Survivor portrait"
        - generic:
          - meter "health":
            - generic: 100 / 100
        - 'button "Active weapon: bat, 0.0s" [ref=e8] [cursor=pointer]'
      - generic: Corgi · following
      - generic:
        - generic "North-up minimap, range 30 meters":
          - generic "zoo-carried-0"
          - generic "zoo-carried-1"
          - generic "zoo-carried-2"
          - generic "zoo-carried-3"
          - generic "zoo-carried-4"
          - generic "zoo-carried-5"
          - generic "zoo-carried-6"
          - generic "zoo-carried-7"
          - generic "zoo-carried-8"
          - generic "zoo-carried-9"
          - generic "zoo-carried-10"
          - generic "zoo-carried-11"
          - generic: "N"
          - generic: ▲
        - status: ☀ Clear
        - generic: Bring the survivors to the armored vehicle and board · 98 m
  - text: ⚔ ✦ Ⅱ
```

# Test source

```ts
  1   | import { mkdirSync, writeFileSync } from 'node:fs';
  2   | import { boot, expect, test } from '../fixtures';
  3   | import type { Page } from '@playwright/test';
  4   | const out = 'test-results/epics/E30';
  5   | /** The campaign handoff resumes the new level; await it instead of stepping the retired zoo. */
  6   | const stepZoo = (page: Page, n: number) => page.evaluate(async n => {
  7   |   const a = window.__SS__!;
  8   |   if (a.getState().scenario !== 'L8' || a.missions.state()?.phase === 'progression') { await a.screenshotReady(); a.pause(); return; }
  9   |   a.pause(); await a.step(n);
  10  | }, n);
  11  | 
  12  | test('T-E30-18 @E30-AC18 real keyboard exploration, tunnel breach and complete APC escape into L9', async ({ page }) => {
  13  |   test.setTimeout(900_000); mkdirSync(out, { recursive: true });
  14  |   await boot(page, '/?test=1&renderer=webgl&dpr=1&quality=high&audio=muted&ui=1');
  15  |   await page.evaluate(async () => { const a = window.__SS__!; await a.loadLevel('L8', { seed: 1, progression: 'L8-default' }); a.pause(); });
  16  |   await page.getByRole('button', { name: 'Begin mission' }).click(); await page.evaluate(() => window.__SS__!.pause());
  17  |   const step = (n: number) => stepZoo(page, n);
  18  |   const shot = async (name: string) => { await page.evaluate(async () => { window.__SS__!.camera.follow(); await window.__SS__!.screenshotReady(); }); await page.screenshot({ path: `${out}/${name}.png` }); };
  19  |   await shot('real-calm');
  20  |   const initial = await page.evaluate(() => window.__SS__!.getState().player!.transform);
  21  |   const initialCorgi = await page.evaluate(() => window.__SS__!.getState().entities.find(e => e.companion));
  22  |   expect(initialCorgi, 'the protected campaign corgi arrives at the zoo').toBeDefined();
  23  |   await page.keyboard.down('w'); await page.keyboard.down('d'); await step(120); await page.keyboard.up('w'); await page.keyboard.up('d');
  24  |   const explored = await page.evaluate(() => window.__SS__!.getState());
  25  |   expect(Math.hypot(explored.player!.transform.x - initial.x, explored.player!.transform.z - initial.z)).toBeGreaterThan(3);
> 26  |   expect(await page.evaluate(() => window.__SS__!.missions.state()!.marker)).toBeNull(); await expect(page.locator('.mission-tracker')).toBeHidden();
      |                                                                              ^ Error: expect(received).toBeNull()
  27  |   // The protected dog now travels through L7/L8; this must describe the real
  28  |   // follower rather than the obsolete phantom "awaiting rescue" prompt.
  29  |   const corgi = explored.entities.find(e => e.id === initialCorgi!.id)!;
  30  |   expect(corgi, 'the same corgi remains present during calm exploration').toBeDefined();
  31  |   expect(corgi.companion?.state).toBe('follow'); expect(corgi.hidden).not.toBe(true);
  32  |   expect(corgi.health.current).toBe(corgi.health.max);
  33  |   expect(corgi.infected).toBeUndefined(); expect(corgi.infection).toBeUndefined();
  34  |   await expect(page.locator('.hud-companion')).toBeVisible();
  35  |   await expect(page.locator('.hud-companion')).toHaveText('Corgi · following');
  36  |   await expect(page.locator('.hud-pin-objective')).toBeHidden(); await expect(page.locator('.hud-pin-home')).toBeHidden();
  37  |   // The real Begin click can advance a few frames before pause reaches the page.
  38  |   // Measure the exact boundary from the live clock rather than assuming tick 120.
  39  |   const calmClock = await page.evaluate(() => { const s = window.__SS__!.getState(); return { tick: s.tick, start: s.l8!.startedAt }; });
  40  |   const breachTick = calmClock.start + 3600;
  41  |   expect(breachTick).toBe(3600); expect(calmClock.tick).toBeLessThan(breachTick - 1);
  42  |   await step(breachTick - 1 - calmClock.tick);
  43  |   expect(await page.evaluate(() => window.__SS__!.getState().tick)).toBe(breachTick - 1);
  44  |   expect(await page.evaluate(() => window.__SS__!.getState().l8!.breachedAt)).toBe(0);
  45  |   await step(1); const breach = await page.evaluate(() => window.__SS__!.getState().l8!);
  46  |   expect(breach.breachedAt).toBe(3600); expect(new Set(breach.arrivals.map(a => a.outlet)).size).toBe(4);
  47  |   // Physical key movement is computed from the same isometric axes as other real-input campaign gates.
  48  |   for (let i = 0; i < 1500; i++) {
  49  |     const obs = await page.evaluate(() => {
  50  |       const a = window.__SS__!, state = a.getState(), p = state.player!.transform;
  51  |       if (state.scenario !== 'L8') return null;
  52  |       const car = a.getEntity(state.l8!.carId)!, yaw = car.transform.yaw, def = { doorX: .71, width: 2.95 };
  53  |       const door = { x: car.transform.x + Math.cos(yaw) * def.doorX + Math.sin(yaw) * (def.width / 2 + .55), z: car.transform.z - Math.sin(yaw) * def.doorX + Math.cos(yaw) * (def.width / 2 + .55) };
  54  |       const friends = state.l8!.roster.map(id => a.getEntity(id)!).filter(e => e.health.current > 0 && !e.infected && e.passengerOf === undefined);
  55  |       const enemy = a.query({}).filter(e => e.infected && !e.hidden && !e.emerging && e.health.current > 0 && a.input.visible(e.transform) && Math.hypot(e.transform.x - p.x, e.transform.z - p.z) < 15).sort((a,b) => Math.hypot(a.transform.x - p.x,a.transform.z - p.z) - Math.hypot(b.transform.x - p.x,b.transform.z - p.z))[0];
  56  |       return { p, door, car: car.transform, carHP: car.health.current, hp: state.player!.health.current, phase: a.missions.state()!.phase, weapons: state.player!.weapons, tick: state.tick, active: car.vehicle!.driver === 1, friends: friends.map(e => e.transform), enemy: enemy?.transform };
  57  |     });
  58  |     if (!obs) break;
  59  |     if (i % 100 === 0) writeFileSync(`${out}/real-progress.json`, JSON.stringify(obs, null, 2));
  60  |     if (obs.enemy) {
  61  |       const ndc = await page.evaluate(at => window.__SS__!.camera.project(at.x, at.y, at.z), obs.enemy), view = page.viewportSize()!;
  62  |       await page.mouse.move((ndc[0] + 1) * view.width / 2, (1 - ndc[1]) * view.height / 2);
  63  |       await page.keyboard.down('Shift'); await page.keyboard.press('2'); await page.keyboard.up('Shift'); await step(1);
  64  |       await page.mouse.down(); await step(20); await page.mouse.up(); continue;
  65  |     }
  66  |     if (obs.active || (Math.hypot(obs.p.x - obs.door.x, obs.p.z - obs.door.z) > 10 && obs.friends.some(p => Math.hypot(p.x - obs.p.x, p.z - obs.p.z) > 12))) { await step(12); continue; }
  67  |     const target = Math.hypot(obs.p.x - obs.door.x, obs.p.z - obs.door.z) < 10 && obs.p.z < obs.door.z - .5 ? { x: obs.p.x, z: obs.door.z + 1 } : obs.door;
  68  |     const dx = target.x - obs.p.x, dz = target.z - obs.p.z;
  69  |     if (Math.hypot(obs.door.x - obs.p.x, obs.door.z - obs.p.z) < .6) { await shot('real-escape'); await page.keyboard.press('e'); await step(12); continue; }
  70  |     const keys = Math.abs(dx) > Math.abs(dz) ? dx > 0 ? ['s','d'] : ['w','a'] : dz > 0 ? ['s','a'] : ['w','d'];
  71  |     for (const key of keys) await page.keyboard.down(key);
  72  |     await step(Math.min(12, Math.max(2, Math.floor(Math.max(Math.abs(dx), Math.abs(dz)) * 10))));
  73  |     for (const key of keys) await page.keyboard.up(key);
  74  |   }
  75  |   await page.waitForFunction(() => window.__SS__!.getState().scenario === 'L9', undefined, { timeout: 120_000 });
  76  |   await page.evaluate(() => window.__SS__!.pause());
  77  |   const destination = await page.evaluate(() => window.__SS__!.getState());
  78  |   expect(destination.entities.find(e => e.id === breach.carId)!.vehicle!.driver).toBe(1);
  79  |   expect(destination.progression!.campaign!.results!.L8.rescued).toBeGreaterThanOrEqual(8);
  80  |   const carriedCorgi = destination.entities.find(e => e.id === initialCorgi!.id)!;
  81  |   expect(carriedCorgi, 'the same protected dog arrives aboard the crossing APC').toBeDefined();
  82  |   expect(carriedCorgi.companion).toBeDefined(); expect(carriedCorgi.passengerOf).toBe(breach.carId);
  83  |   expect(carriedCorgi.health.current).toBe(carriedCorgi.health.max);
  84  |   expect(carriedCorgi.infected).toBeUndefined(); expect(carriedCorgi.infection).toBeUndefined();
  85  |   writeFileSync(`${out}/real-input.json`, JSON.stringify(destination, null, 2)); await shot('real-l9-arrival');
  86  | });
  87  | 
  88  | test('T-E30-19 @E30-AC19 game camera calm, internal breach and same-id animal turn captures', async ({ page }) => {
  89  |   test.setTimeout(600_000); mkdirSync(out, { recursive: true }); await boot(page);
  90  |   await page.evaluate(async () => { const a = window.__SS__!; await a.loadLevel('L8', { seed: 1, progression: 'L8-default' }); a.pause(); a.cheats.god(true); a.missions.begin(); });
  91  |   const capture = async (name: string, pos: { x: number; z: number }) => {
  92  |     await page.evaluate(async pos => { const a = window.__SS__!; a.teleport(1, pos); await a.step(1); a.camera.cinematic({ position: [pos.x + 19, 23, pos.z + 19], target: [pos.x, .5, pos.z] }, true); await a.screenshotReady(); }, pos);
  93  |     await page.screenshot({ path: `${out}/${name}.png` });
  94  |   };
  95  |   await capture('calm', { x: -60, z: -20 });
  96  |   const animals = await page.evaluate(() => window.__SS__!.getState().l8!.animals);
  97  |   await page.evaluate(() => window.__SS__!.step(3635)); await capture('breach', { x: -99, z: 32 }); await page.evaluate(() => window.__SS__!.teleport(1, { x: 0, z: 70 }));
  98  |   let converting = 0;
  99  |   for (let i = 0; i < 300; i++) {
  100 |     const state = await page.evaluate(ids => ids.map(id => window.__SS__!.getEntity(id)!), animals);
  101 |     const animal = state.find(e => e.infection);
  102 |     if (animal) { converting = animal.id; await capture('animal-turning', animal.transform); writeFileSync(`${out}/animal-turning.json`, JSON.stringify(animal, null, 2)); break; }
  103 |     await page.evaluate(() => window.__SS__!.step(30));
  104 |   }
  105 |   expect(converting).toBeGreaterThan(0);
  106 |   await page.evaluate(() => window.__SS__!.step(240));
  107 |   const infected = await page.evaluate(id => window.__SS__!.getEntity(id)!, converting);
  108 |   expect(infected.infected).toBeTruthy(); await capture('animal-infected', infected.transform);
  109 |   writeFileSync(`${out}/animal-infected.json`, JSON.stringify(infected, null, 2));
  110 | });
  111 | 
  112 | test.describe('phone escape input', () => {
  113 |   test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  114 |   test('T-E30-18-mobile @E30-AC18 touch stick reaches the APC ACTION with no HUD overflow', async ({ page, context }) => {
  115 |     test.setTimeout(600_000); await boot(page, '/?test=1&renderer=webgl&dpr=1&quality=low&audio=muted&ui=1');
  116 |     await page.evaluate(async () => { const a = window.__SS__!; await a.loadLevel('L8', { seed: 1, progression: 'L8-default' }); a.pause(); a.missions.begin(); await a.step(3600); });
  117 |     const cdp = await context.newCDPSession(page);
  118 |     for (let i = 0; i < 300; i++) {
  119 |       const obs = await page.evaluate(() => {
  120 |         const a = window.__SS__!, state = a.getState(); if (state.scenario !== 'L8') return null;
  121 |         const p = state.player!.transform, car = a.getEntity(state.l8!.carId)!, yaw = car.transform.yaw;
  122 |         const door = { x: car.transform.x + Math.cos(yaw) * .71 + Math.sin(yaw) * 2.025, z: car.transform.z - Math.sin(yaw) * .71 + Math.cos(yaw) * 2.025 };
  123 |         const dx = door.x - p.x, dz = door.z - p.z, distance = Math.hypot(dx, dz), next = distance > 1 ? { x: p.x + dx / distance * 3, z: p.z + dz / distance * 3 } : door;
  124 |         const origin = a.input.project(p), target = a.input.project(next);
  125 |         return { distance, screen: { x: target.x - origin.x, y: target.y - origin.y }, active: car.vehicle!.driver === 1 };
  126 |       });
```