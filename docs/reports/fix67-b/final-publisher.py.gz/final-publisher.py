import json,gzip,hashlib,pathlib,subprocess,shutil
root=pathlib.Path('docs/reports/fix67-b');source='1bf35209e3871fea6acf6f754941fd41f22f544460fce6b031b7459776d93214';commit=subprocess.check_output(['git','rev-parse','dd26478'],text=True).strip()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text())
def receipt(level,tier,policy):
 p=f'docs/reports/fix51-verify/receipts/{level}-{tier}-{policy}.json';r=load(p);assert r['sourceHash']==source;return p,r
reports={l:load(f'docs/reports/fix51-verify/{l}.json')for l in ['L4','L5','L6']};assert all(r['sourceHash']==source for r in reports.values())
extra=load(root/'final-placement-rechecks.json');assert extra['sourceHash']==source and not extra['failures'];art={a['kind']:a for a in extra['artifacts']}
def raw(kind):return json.load(gzip.open(art[kind]['file'],'rt'))
coh=[{'tier':r['tier'],'cohorts':len(r['cohorts']),'admitted':sum(len(c['actors'])for c in r['cohorts']),'minimum':r['smallest'],'maximum':r['largest'],'nativeHash':r['finalHash'],'canonicalHash':r['canonicalHash']}for r in raw('cohorts')['rows']]
tank=[]
for r in raw('tank')['rows']:
 war=[s for s in r['shots']if s['phase']=='war'];intervals=[(b['tick']-a['tick'])/60 for a,b in zip(war,war[1:])];assert all(8<=s<=12 for s in intervals)
 tank.append({'tier':r['tier'],'minimumClearanceM':min(a['distance']for s in r['shots']for a in s['protected']),'forcedClearanceM':min(a['distance']for s in r['shots']if s['phase']=='collapse'for a in s['protected']),'intervalsSeconds':intervals,'nativeHash':r['finalHash'],'canonicalHash':r['canonicalHash']})
holds=[];r7=next(r for r in reports['L4']['rows']if r['id']=='L4-07');windows=[];rescue=[];entries=[]
for t in ['low','high']:
 p,r=receipt('L4',t,'stationary');h=r['highHold'];assert h['holdComplete']and h['aliveAtFirstBreach']>=60 and h['minPlazaAliveAfter45Seconds']>=40 and 30<=h['firstBreachLevelSeconds']<=60;holds.append({'tier':t,'receipt':p,'sha256':sha(p),'hold':h})
 p,r=receipt('L4',t,'complete');s=r['observation']['final']['mission']['l4'];assert len(s['glass'])>=10;windows.append({'tier':t,'glass':len(s['glass']),'fires':s['fires'],'receipt':p,'sha256':sha(p)})
 p,r=receipt('L6',t,'complete');s=r['observation']['final']['mission'];result=s['result'];roster=s['l6']['survivors'];out=sum(a['status']=='out'for a in roster);assert out==result['rescued']==1 and len(roster)==result['survivorsIn']==29;rescue.append({'tier':t,'out':out,'atStart':len(roster),'lost':result['survivorsLost'],'percent':out/len(roster)*100,'nativeHash':r['nativeStateHash'],'receipt':p,'sha256':sha(p)})
 w=[w for w in r['threat']['waves']if w['key'].startswith('entry-')];assert len(w)==6 and all(w['spawned']==len(w['members'])==3 for w in w);entries.append({'tier':t,'receipt':p,'sha256':sha(p),'waves':[{'key':a['key'],'spawned':a['spawned'],'members':a['members']}for a in w]})
qual={'sourceHash':source,'codeCommit':commit,'artifacts':extra['artifacts'],'L4-05':{'status':'SCOPED PASS','rows':coh,'remaining':'Wall crossing and forbidden-source clauses.'},'L4-06':{'status':'PASS','rows':holds},'L4-07':{'status':'NOT CHECKED','note':'Previous bounded-reachability counterexample resolved. Every unchanged numeric check passes; high complete legal-route proof remains incomplete. No universal no-permanent-trap PASS.','checks':r7['checks']},'L4-10':{'status':'SCOPED PASS','rows':tank,'remaining':'Current renderer/wall/HMG/helicopter compound clauses; PO north-road blast framing.'},'L4-11':{'status':'SCOPED PASS','maximumSeconds':max(r['seconds']for r in raw('riot')['rows']),'rows':len(raw('riot')['rows']),'remaining':'Full flank/HP-bar/chip/recoil/PO feel review.'},'L4-14':{'status':'SCOPED PASS','note':'Fuel shockwave glass reach48→60m restores the≥10 actual window-ledger count after the truck relocation. Other visual clauses remain unqualified.','rows':windows},'L6-06':{'status':'FAIL','targetPerEntry':2,'rows':entries},'L6-11':{'status':'FAIL','targetMinimumPercent':60,'rows':rescue},'L6-01':{'status':'PASS at reviewed commit; final native replay PASS','native':art['carry'],'qualification':'docs/reports/fix67-b/L6-01-qualification.json'},'L6-12':{'status':'PASS in explicit reviewed exit fixture; final capsule replay PASS','native':art['gate'],'qualification':'docs/reports/fix67-b/L6-12-qualification.json'}}
p=root/'final-qualification.json';p.write_text(json.dumps(qual,indent=2)+'\n')
# Preserve superseded reviews as history. Their old commits remain unchanged;
# current native incomplete clauses still prevent row PASS.
archive=root/'superseded-reviews';archive.mkdir(exist_ok=True)
for row in ['L4-05','L4-07','L4-10','L4-11']:
 old=pathlib.Path(f'docs/qa/reviews/{row}.json')
 if old.exists():shutil.copyfile(old,archive/(row+'.json'));# Original review remains commit-scoped; current coverage stays native NOT CHECKED.
notes={'L4-06':('PASS','Final source: both stationary policies complete190s. First breach52.716667s,61 low/66 high alive; sustained plaza minima66/66. Original low59 fails≥60. Alarm9→18; caps/timers/criteria unchanged.'),'L6-06':('FAIL','Final-source actual birth identities:3 at each of6 entries at both tiers,18 total, versus unchanged2 per entry. Count establishes FAIL. Floor/visual clauses are not inferred and no count reduction or redistribution was made.'),'L6-11':('FAIL','Final-source ordinary mortal canonical complete saves1/29=3.448276% at both tiers, below60%; final identity statuses and mission result agree. Evade-only is not inferred from protected stationary policy. Earlier range trace and reverted trials remain diagnosis.')}
for row,(status,note)in notes.items():
 q=pathlib.Path(f'docs/qa/reviews/{row}.json');x=load(q);x.update({'status':status,'reviewer':'Codex/fix67-b','date':'2026-11-06','commit':commit});x['clauses'][0].update({'verdict':status,'note':note});x['evidence']=[{'file':str(p),'sha256':sha(p),'what':note}];q.write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'sourceHash':source,'cohorts':coh,'tank':tank,'windows':windows,'qualificationSha256':sha(p)}))
