(() => {
  const audit=window.__finalBCueAudit={calls:[],samples:[],violation:null},bound=new WeakSet();
  const sounds={dale:'impact.body.metal',rosa:'door.wood',okafor:'bark.male.effort',mia:'dialogue.radio',sam:'ui.switch'};
  const pinState=()=>{const p=document.querySelector('[data-testid=minimap-cue]');return{visible:!!p&&!p.hidden&&p.getClientRects().length>0&&getComputedStyle(p).visibility!=='hidden',key:p?.getAttribute('data-survivor'),text:p?.textContent}};
  let last=0;
  const loop=now=>{requestAnimationFrame(loop);const g=window.__SCENE__?.game,w=g?.world;if(!w?.missions||w.scenario!=='L5')return;
    if(!bound.has(w)){bound.add(w);w.events.on('l5.cue',e=>queueMicrotask(()=>{const snapshot=g.audio.snapshot(),call={key:e.key,tick:e.tick,distance:e.distance,position:e.position,contextState:g.audio.context.state,audioTime:g.audio.context.currentTime,muted:snapshot.muted,unlocked:snapshot.unlocked,voices:[]};
      for(const v of g.audio.graph.active.values())if(v.cue===sounds[e.key]&&v.position&&Math.hypot(v.position.x-e.position.x,v.position.z-e.position.z)<1e-6){const row={id:v.id,cue:v.cue,gain:v.gain.gain.value,baseGain:v.baseGain,rate:v.rate,bufferDuration:v.source.buffer?.duration,ended:null};call.voices.push(row);v.source.addEventListener('ended',()=>{row.ended={tick:w.tick,audioTime:g.audio.context.currentTime,contextState:g.audio.context.state,pin:pinState()}})}audit.calls.push(call)}));}
    if(now-last<100)return;last=now;const s=w.missions.state.l5,pin=pinState(),call=[...audit.calls].reverse().find(c=>c.key===pin.key);if(!call)return;
    const sample={tick:w.tick,audioTime:g.audio.context.currentTime,contextState:g.audio.context.state,pin,until:s?.cue?.until??null,callTick:call.tick,voices:call.voices.map(v=>({id:v.id,stillInGraph:g.audio.graph.active.has(v.id),ended:v.ended}))};audit.samples.push(sample);
    if(!audit.violation&&call.contextState==='running'&&!call.muted&&call.unlocked&&call.voices.length&&call.voices.every(v=>v.gain>0&&v.ended?.contextState==='running')&&pin.visible&&pin.key===call.key&&s?.cue?.until>w.tick){const endedAt=Math.max(...call.voices.map(v=>v.ended.audioTime));if(sample.audioTime-endedAt>=.75)audit.violation={call:JSON.parse(JSON.stringify(call)),sample,secondsAfterAllVoicesEnded:sample.audioTime-endedAt};}
  };requestAnimationFrame(loop);
})();
