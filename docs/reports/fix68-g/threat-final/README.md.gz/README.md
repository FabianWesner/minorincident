# Threat calibration

Runtime main: `6f5b0ebb3c762689cba843a8744396e5f5fbe644`; harness base: `d485990ec401ff306ff18a53b21b702b96cec8c2`. Runtime source matches main: **false**. Seed 1, skilled and passive native routes, **low** population set before mission preparation. Sequential simulation only; 419.20 seconds, budget 600 seconds. Result: **14 acceptance fail flags**.

[Raw audit receipts](audit.json).

## Measurement contract

Every active mission step is measured, including simultaneous objectives and instant completions; controller phases have separate rows. These overlapping views must not be summed. L1 combat starts in controller `spread`, after the instantaneous escape milestone. L2 ambush combat starts in controller `collapse`, after the doors open; the earlier door-forcing objective is retained without a combat tag. Duration is actual active fixed ticks (cinematics/results excluded). Spawn counts count successful spawns and civilian conversions, with a fresh generation for each reused pool record; “at start” is the first-tick living population. Observed/path/contact counts are unique generations seen during that phase. Contact means ever within 2.5 m of the moving player. Attacks and first-attack times count targeted attack telegraphs (including interrupted windups), physical civilian grabs and synchronous escort strikes. Support roars, screams and revives are excluded; resolved hits are never counted again. Player and following-party targets have separate counters.

Path queries use an independent copy of the native infected AI grid, with identical walls, mask, live blockers and radius rules; the Mega uses its native pursuit grid. Live resumable searches are never advanced by the audit. Queries run every two simulated seconds and on phase changes. All active living infected count in the denominator, including hidden/pending arrivals; pending admission is unreachable until admitted. Contact requires visible admission. A threat phase fails if >30% remain unreachable for >20 seconds across consecutive samples. Evidence records positions and the player position at that time. Later recovery does not erase a flag. The table also gives the last measured reachable/alive snapshot.

Followers include civilian survivor groups, allied followers, escorts and the companion (never the courier). Each follower’s median uses moving samples plus stationary samples while lagging behind a moving leader. The group min/median compare those individual medians. Leader walking/stationary time uses resolved position changes, never a stale requested velocity. Parked formation shuffling, incapacitated actors and cinematic locks do not count as walking. G-13 flags any follower below 0.95× the group median; the moving native route also measures all stationary courier ticks with any active follower >10 m away, including combat stands, as a conservative upper bound on the ≤10% waiting-share criterion. Raw per-follower values/sample counts are retained in JSON. A pace median needs ten walking samples (five seconds at 2 Hz); the named L5/L7/L8 followers must each have that coverage in the moving native route, so a stationary passive route cannot produce a false PASS. A dash means no walking sample, not zero speed.

Announced waves use native clocks/events and actual cohort ledgers. G-22 is measured by a cohort member making a real attack windup against the player within 20 s; the baseline 10 s proximity heuristic was removed. Only explicit threat announcements and first breach cohorts are gating; recurring reinforcement clocks without an acceptance threshold remain informational. Reachability is judged on the passive snapshot. The skilled route also gates zero windups in every inventoried combat phase, L2 bridge ≥2/min, L5 search ≥3/min, L10 hold ≥8/min and L6 mortal damage ≥30 HP. Passive caps are 70 s for L3, 250 s for L4, 110 s for L6, and 60 s of the L10 hold. A `tick-budget` passive outcome means the window cap ended the native route, not that the measured window is missing.

## Run coverage

| Level | Skilled outcome | Skilled sim s | Passive outcome / furthest step | Passive sim s | Phase rows | Announced waves | Wall seconds | Flags |
|---|---|---:|---:|---:|---:|---:|
| L1 | complete | 115.08 | complete / firestation | 115.08 | 11 | 0 | 13.89 | 0 |
| L2 | complete | 156.12 | complete / bridge | 188.33 | 15 | 1 | 24.96 | 0 |
| L3 | complete | 190.97 | tick-budget / checkpoint | 70.00 | 6 | 3 | 55.50 | 1 |
| L4 | complete | 355.43 | tick-budget / hide | 248.50 | 8 | 26 | 129.62 | 0 |
| L5 | complete | 186.68 | tick-budget / look | 1200.00 | 5 | 0 | 97.11 | 0 |
| L6 | complete | 289.43 | tick-budget / retreat | 110.00 | 6 | 2 | 15.55 | 1 |
| L7 | complete | 104.45 | complete / bus-departure | 103.97 | 7 | 0 | 18.20 | 12 |
| L8 | complete | 95.38 | complete / depart | 144.58 | 6 | 20 | 22.13 | 0 |
| L9 | complete | 128.13 | complete / reach-outskirts | 128.13 | 8 | 0 | 8.13 | 0 |
| L10 | complete | 1168.53 | tick-budget / hold | 1062.70 | 12 | 1 | 34.10 | 0 |

## Acceptance criteria matrix

| Criterion | Passive measured | Skilled measured | Expected | Verdict |
|---|---:|---:|---|---|
| L1-08 | 25.09 | — | ≥ 3/min | PASS |
| L2-07 | 49.18 (12.20 s) | — | ≥ 4/min | SHORT WINDOW |
| L2-07 reach | 100.00% | — | ≥ 90% | PASS |
| L2-12 | — | 10.38 | ≥ 2 and ≤ 20/min | PASS |
| L3-03 | 149.56 | — | ≥ 4/min | PASS |
| L3-03 reach | 100.00% | — | ≥ 90% | PASS |
| L4-07 | 950.84 | — | ≥ 6/min | PASS |
| L4-07 reach | 100.00% | — | ≥ 90% | PASS |
| L5-05 | 601.99 + 1.21 group | — | ≥ 3/min | PASS |
| L6-05 | 265.50 | — | ≥ 4/min | PASS |
| L6-05 reach | 100.00% | — | ≥ 95% | PASS |
| L6-06 | 100.00% | — | ≥ 95% | PASS |
| L7-05 | 158.56 + 24.50 group | — | ≥ 6/min | PASS |
| L8-06 | 244.19 + 8.23 group | — | ≥ 4/min | PASS |
| L10-11 | 1091.17 | — | ≥ 8/min | PASS |
| G-13 | 62 (42% of group median), 63 (60% of group median), 67 (80% of group median), 70 (50% of group median), 71 (52% of group median), 74 (87% of group median) | L5/28: 95.3% (42 samples); L5/31: 99.4% (128 samples); L7/60: 100.0% (166 samples); L7/63: 100.0% (169 samples); L8/354: 99.8% (31 samples); L8/359: 99.9% (32 samples); L8/362: 100.0% (32 samples); L8/363: 100.6% (32 samples); L8/364: 99.9% (32 samples); L8/365: 100.0% (32 samples); L8/366: 100.0% (32 samples); wait upper bounds: L5: 0.00%, L7: 1.92%, L8: 4.90% | every follower ≥ 95% of group median; ≥10 walking samples for each named follower; stationary >10m lag ≤10% of escort time | FAIL |
| L3-02 cohorts | 15/15, 30/30, 50/50 | 15/15, 30/30, 48/50 | 15/30/50 actual members on low tier | FAIL |
| L3-02 stream | 16.73 s scheduled; 15 admitted; 16.57 s scheduled; 30 admitted; 17.08 s scheduled; 50 admitted | — | every cohort admitted within its ≤18 s stream | PASS |
| L3-02 alarm frame | 5/15 | — | ≥25% of opening wave on screen within 2 s | PASS |
| L3-03 first attack | 2.95 s | — | ≤10 s | PASS |
| L4-07 first attack | 9.32 s | — | ≤10 s | PASS |
| L3-06 squad counts/losses | — | 4 → army s1:3/s2:0/s3:0 (2/3 ≤2); bite | 3–4 at fallback; ≤2 at army (seeds 1–3: ≥2 valid, ≥2 of them ≤2); every loss a bite/kill/separation | PASS |
| L3-11 native competent rate | — | 5.39/min; 22 damage; 0 deaths | 3–25 player attacks/min | PASS |
| L4-05 directions/groups | 6 edges; ≥60°: true; max group 5 | — | ≥3 edges ≥60° apart; groups ≤5 at each source | PASS |
| L4-06 first breach | 52.72 s level / +19.90 s alarm; 64 alive | — | level clock 30–60 s; ≥60 alive at first breach | PASS |
| L4-06 sustained horde | minimum 71; 8760 observations; line break 190.00 s | — | ≥40 living in authored plaza from alarm +45 s through line break | PASS |
| L6-03/04 | Breach cohorts: see L6 wave table | — | breach 1 ≥6; breach 2 ≥10 | See wave flags |
| L8-04 | 12/12 across 4 outlets [3, 3, 3, 3] | — | ≥3 outlets ≥20m apart, ≥6/3 each (high/low); no pop-in | LEDGER PASS; visual pending |
| G-22 | See announced-wave table below | Informational | first attack ≤ 20 s; several reachable infected at start | See wave flags |
| L9-03 | Not measured by this harness | Not measured | ≥ 1 group/wanderer in camera frame per 60 s, each route | NOT TESTED (harness gap) |

## L1

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/pickup — pickup: Pick up the package at the courier depot | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-38.79, -34.84) | — |
| phase/morning — controller: morning | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (64.53, -9.88) | — |
| step/deliver — deliver: Deliver the package to the Medical Annex | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/handover — controller: handover | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/calm — controller: calm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/accident — controller: accident | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.31, -9.54) | — |
| step/escape — escape: Get away from the facility | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 5/5 | 5/5 | (65.31, -9.54) | — |
| phase/spread — controller: spread | L1-08 | 25.09 player + 0.00 group/min; 12.67 s | 25.09 player + 0.00 group/min; 12.67 s | 24/24 | 24/24 | (-73.91, 40.46) | — |
| step/weapon — weapon: Find something to defend yourself | — | 18.65 player + 0.00 group/min; 12.65 s | 18.65 player + 0.00 group/min; 12.65 s | 20/20 | 20/20 | (23.26, 37.31) | — |
| step/firestation — firestation: Get inside the fire station | — | 29.33 player + 0.00 group/min; 0.42 s | 29.33 player + 0.00 group/min; 0.42 s | 24/24 | 24/24 | (-73.91, 40.46) | — |
| phase/run-out — level-end run-out | — | 144.00 player + 0.00 group/min; 1.13 s | 144.00 player + 0.00 group/min; 1.13 s | 28/28 | 28/28 | (-76.04, 41.15) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L2

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/calm — calm: Take the fire axe | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| step/axe — axe: Take the fire axe | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.20, 45.20) | — |
| phase/calm — controller: calm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| step/board — board: Get on the fire truck | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| phase/alarm — controller: alarm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-70.82, 41.50) | — |
| step/ride — ride: Ride with Engine 3 to Grove Market | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-42.84, -32.00) | — |
| phase/ride — controller: ride | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-42.84, -32.00) | — |
| step/doors — doors: Cover the firefighters while they force the doors | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| phase/arrived — controller: arrived | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| phase/doors — controller: doors | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| step/bridge — bridge: Reach the police checkpoint at the bridge | — | 177.02 player + 0.00 group/min; 3.28 s | 10.38 player + 0.00 group/min; 3.28 s | 0/4 | 0/27 | (81.40, 32.96) | — |
| phase/collapse — controller: collapse | L2-07 | 49.18 player + 0.00 group/min; 3.28 s | 32.47 player + 0.00 group/min; 3.28 s | 30/30 | 30/30 | (-65.50, -22.95) | — |
| phase/escape — controller: escape | L2-12 | 195.39 player + 0.00 group/min; 3.37 s | 7.01 player + 0.00 group/min; 3.07 s | 5/5 | 27/27 | (81.42, 37.84) | — |
| phase/checkpoint — controller: checkpoint | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/4 | 0/27 | (81.40, 32.96) | — |
| phase/run-out — level-end run-out | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/5 | 0/28 | (81.95, 32.30) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| market-ambush | l2.doorsOpen | 58.60 | 129.73 | 24 | 24 | — | 3.28 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/bridge`, `phase/checkpoint` at 150.52 s, 27/27 unreachable: `185@2` (12.48, -29.63); `191@5` (-57.58, -26.71); `201@10` (5.37, -4.30); `209@14` (-26.00, 4.33); `217@18` (-54.84, 37.51); `219@19` (-51.98, 14.70); `233@27` (-68.89, 2.96); `235@28` (-67.10, 14.46); `237@29` (-68.03, 15.21); `239@30` (-64.68, -4.16); `241@31` (-24.81, 48.63); `243@32` (-55.09, 30.42); `245@33` (-54.27, 28.31); `247@34` (-66.95, 18.10); `249@35` (33.55, -27.02); `251@36` (36.46, -28.36); `253@37` (39.15, -31.46); `255@38` (42.67, -32.91); `257@39` (-7.12, 48.03); `259@40` (81.28, 42.18); `261@41` (-33.74, -15.82); `263@42` (-34.41, 2.05); `265@43` (-28.97, 18.44); `267@44` (-11.50, 28.34); `269@45` (7.74, 26.23); `271@46` (26.46, 27.04); `275@48` (45.80, 29.70). Player (81.40, 32.96).
- `phase/run-out` at 155.12 s, 28/28 unreachable: `185@2` (14.12, -29.74); `191@5` (-51.82, -26.74); `201@10` (5.76, -2.14); `209@14` (-26.26, 9.63); `217@18` (-51.68, 34.25); `219@19` (-46.67, 14.45); `233@27` (-67.10, 4.04); `235@28` (-68.77, 14.92); `237@29` (-68.59, 13.75); `239@30` (-66.04, 1.27); `241@31` (-26.57, 49.06); `243@32` (-56.92, 31.55); `245@33` (-56.65, 33.25); `247@34` (-66.33, 20.95); `249@35` (36.86, -29.06); `251@36` (37.19, -30.64); `253@37` (39.96, -33.46); `255@38` (38.42, -30.40); `257@39` (-5.62, 48.58); `261@41` (-33.94, -14.42); `263@42` (-35.94, 3.47); `265@43` (-26.43, 17.04); `267@44` (-11.18, 26.48); `269@45` (6.27, 28.29); `271@46` (25.45, 26.63); `275@48` (46.15, 34.18); `297@59` (81.36, 39.56); `175@60` (5.89, -4.95). Player (81.95, 32.30).

## L3

Threat steps explicitly selected from the loaded mission definition:

- `defend` — Help defend the station (combat; L3-03).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/armory — armory: Take a handgun from the armory | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-139.91, -6.85) | — |
| phase/yard — controller: yard | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-134.95, 0.61) | — |
| step/defend — defend: Help defend the station | L3-03 | 149.56 player + 0.00 group/min; 2.95 s | 23.48 player + 0.00 group/min; 2.95 s | 32/32 | 24/24 | (-134.95, 0.61) | — |
| phase/attack — controller: attack | — | 149.56 player + 0.00 group/min; 2.95 s | 23.48 player + 0.00 group/min; 2.95 s | 32/32 | 24/24 | (-134.95, 0.61) | — |
| step/checkpoint — checkpoint: Get inside the army checkpoint | — | 943.04 player + 80.46 group/min; 0.12 s | 5.39 player + 6.16 group/min; 0.77 s | 77/77 | 0/36 | (-134.95, 0.61) | — |
| phase/fallback — controller: fallback | — | 943.04 player + 80.46 group/min; 0.12 s | 54.09 player + 78.13 group/min; 0.77 s | 77/77 | 11/11 | (-134.95, 0.61) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| station-0 | L3 scheduled wave.at (before admission) | 9.45 | 60.55 | 15 | 15 | — | 2.95 | — |
| station-1 | L3 scheduled wave.at (before admission) | 29.45 | 40.55 | 30 | 30 | — | 2.97 | — |
| station-2 | L3 scheduled wave.at (before admission) | 49.45 | 20.55 | 50 | 50 | — | 4.47 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/checkpoint`, `phase/corridor` at 188.98 s, 36/36 unreachable: `2192@1016` (143.76, 1.62); `2194@1017` (192.57, 0.56); `2196@1018` (149.91, 3.02); `2198@1019` (183.77, 2.45); `2200@1020` (152.23, 2.11); `2362@1094` (196.10, -2.76); `2464@1140` (152.88, 1.73); `2466@1141` (170.63, -0.58); `2468@1142` (153.91, 1.04); `2470@1143` (179.88, 0.95); `2472@1144` (132.22, 3.74); `2636@1218` (194.71, -1.52); `2770@1279` (196.76, -3.07); `2772@1280` (192.32, 1.22); `2774@1281` (193.72, -0.25); `2776@1282` (193.16, 0.16); `2778@1283` (195.43, -2.99); `2940@1356` (185.60, 3.05); `2942@1357` (188.50, 1.78); `2944@1358` (188.07, 2.51); `2946@1359` (184.90, 2.89); `2948@1360` (186.88, 2.80); `3110@1433` (169.93, -0.66); `3112@1434` (172.47, -0.79); `3114@1435` (173.55, -0.56); `3116@1436` (175.95, -0.34); `3118@1437` (175.20, -0.54); `3224@1484` (76.64, 3.60); `3226@1485` (79.50, 24.00); `3228@1486` (59.22, 24.00); `3230@1487` (71.89, 32.00); `3232@1488` (69.38, 24.00); `3234@1489` (91.46, 32.00); `3236@1490` (91.57, 24.00); `3238@1491` (110.72, 24.00); `3240@1492` (108.67, 32.00). Player (224.99, 0.20).
- `phase/done` at 190.97 s, 36/36 unreachable: `2192@1016` (148.38, 2.90); `2194@1017` (197.37, -3.24); `2196@1018` (155.84, -0.06); `2198@1019` (189.62, 2.47); `2200@1020` (157.94, -1.47); `2464@1140` (158.58, -1.87); `2466@1141` (177.31, -0.06); `2468@1142` (159.64, -2.50); `2470@1143` (186.22, 2.98); `2472@1144` (128.21, 4.11); `2772@1280` (196.73, -2.98); `2776@1282` (198.05, -3.05); `2940@1356` (189.35, 1.37); `2942@1357` (191.84, -1.03); `2944@1358` (192.86, 0.59); `2946@1359` (190.38, 0.93); `2948@1360` (191.39, -1.88); `3110@1433` (176.64, -0.17); `3112@1434` (179.04, 0.63); `3114@1435` (180.05, 1.02); `3116@1436` (182.30, 1.88); `3118@1437` (181.58, 1.59); `3280@1510` (167.34, -0.94); `3282@1511` (169.32, -0.23); `3284@1512` (164.84, -2.65); `3286@1513` (165.73, -1.30); `3288@1514` (166.54, -1.10); `3314@1525` (76.64, 3.60); `3316@1526` (91.46, 32.00); `3318@1527` (71.89, 32.00); `3320@1528` (79.50, 24.00); `3322@1529` (100.61, 32.00); `3324@1530` (110.72, 24.00); `3326@1531` (118.73, 32.00); `3328@1532` (118.74, 24.00); `3330@1533` (91.57, 24.00). Player (224.99, 0.20).

## L4

Threat steps explicitly selected from the loaded mission definition:

- `hold` — Hold the plaza with the army (combat; L4-07).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/ride — ride: Ride into Fairhaven with the convoy | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| phase/convoy — controller: convoy | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/quartermaster — quartermaster: Report to the quartermaster | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| phase/plaza — controller: plaza | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/hold — hold: Hold the plaza with the army | L4-07 | 950.84 player + 0.00 group/min; 9.32 s | 189.09 player + 0.00 group/min; 17.92 s | 80/80 | 80/80 | (-22.85, 0.74) | — |
| phase/war — controller: war | — | 950.84 player + 0.00 group/min; 9.32 s | 189.09 player + 0.00 group/min; 17.92 s | 80/80 | 80/80 | (-22.85, 0.74) | — |
| step/hide — hide: Run to the cellar via Lakeshore, Metro Road and Harbor Street | — | 635.43 player + 0.00 group/min; 0.15 s | 85.43 player + 0.00 group/min; 0.10 s | 67/67 | 77/77 | (-5.37, 16.47) | — |
| phase/collapse — controller: collapse | — | 635.43 player + 0.00 group/min; 0.15 s | 85.43 player + 0.00 group/min; 0.10 s | 67/67 | 77/77 | (-5.37, 16.47) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| war-0@1969 | l4.wave | 32.82 | 215.68 | 24 | 24 | — | 9.32 | — |
| war-1@2629 | l4.wave | 43.82 | 204.68 | 36 | 36 | — | 12.80 | — |
| breach-west | L4 breach.openAt | 52.72 | 195.78 | — | 109 | — | 4.62 | — |
| war-2@3289 | l4.wave | 54.82 | 193.68 | 48 | 37 | — | 53.35 | — |
| war-3@3949 | l4.wave | 65.82 | 182.68 | 54 | 17 | — | 139.00 | — |
| war--1@4009 | l4.wave | 66.82 | 181.68 | 15 | 2 | — | 154.05 | — |
| war-4@4609 | l4.wave | 76.82 | 171.68 | 54 | 0 | — | — | — |
| war-5@5269 | l4.wave | 87.82 | 160.68 | 54 | 0 | — | — | — |
| war-6@5929 | l4.wave | 98.82 | 149.68 | 54 | 0 | — | — | — |
| war-7@6589 | l4.wave | 109.82 | 138.68 | 54 | 0 | — | — | — |
| war-8@7249 | l4.wave | 120.82 | 127.68 | 54 | 0 | — | — | — |
| war-9@7909 | l4.wave | 131.82 | 116.68 | 54 | 0 | — | — | — |
| breach-north | L4 breach.openAt | 138.13 | 110.37 | — | 27 | — | 7.25 | — |
| war-10@8569 | l4.wave | 142.82 | 105.68 | 54 | 0 | — | — | — |
| war-11@9229 | l4.wave | 153.82 | 94.68 | 54 | 0 | — | — | — |
| war-12@9889 | l4.wave | 164.82 | 83.68 | 54 | 0 | — | — | — |
| war-13@10549 | l4.wave | 175.82 | 72.68 | 54 | 0 | — | — | — |
| war-14@11209 | l4.wave | 186.82 | 61.68 | 54 | 0 | — | — | — |
| opening-alarm | L4 opening pending street cohorts | 32.82 | 215.68 | — | 0 | — | — | — |
| breach-south | L4 breach.openAt | 194.95 | 53.55 | — | 13 | — | 7.72 | — |
| war-15@11869 | l4.wave | 197.82 | 50.68 | 54 | 0 | — | — | — |
| war-16@12529 | l4.wave | 208.82 | 39.68 | 54 | 0 | — | — | — |
| war-17@13189 | l4.wave | 219.82 | 28.68 | 54 | 0 | — | — | — |
| collapse-0@13609 | l4.wave | 226.82 | 21.68 | 6 | 0 | — | — | — |
| collapse-1@14149 | l4.wave | 235.82 | 12.68 | 6 | 0 | — | — | — |
| collapse-2@14689 | l4.wave | 244.82 | 3.68 | 6 | 0 | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/bar` at 347.27 s, 77/77 unreachable: `347@170` (-71.19, 44.13); `349@172` (-70.48, 44.22); `351@174` (-70.21, 43.16); `380@201` (-73.68, 44.69); `384@205` (-71.90, 44.07); `405@225` (-74.95, 43.47); `417@236` (-74.45, 42.79); `418@237` (-72.61, 44.08); `423@242` (-72.99, 44.64); `424@243` (-72.30, 44.69); `428@246` (-71.60, 44.68); `433@251` (-19.29, 10.65); `435@253` (-71.48, 43.50); `437@255` (-74.29, 45.03); `443@261` (-72.16, 43.41); `464@277` (-66.94, -40.13); `473@286` (-14.17, 23.35); `485@296` (-29.06, 26.68); `488@299` (-14.75, 24.92); `492@302` (-7.86, 8.43); `493@303` (-71.02, 42.82); `495@305` (-71.85, 42.80); `497@307` (-70.91, 44.77); `504@314` (-73.33, 43.94); `508@318` (-72.86, 43.43); `512@322` (-70.77, 43.59); `516@326` (-75.15, 42.79); `519@328` (-72.61, 42.79); `524@333` (-74.04, 44.09); `525@334` (2.47, 22.28); `528@337` (-74.75, 44.26); `530@339` (-74.12, 43.41); `531@340` (-73.57, 45.55); `532@341` (-72.69, 45.44); `535@344` (-73.57, 42.79); `537@346` (-9.58, 11.82); `556@347` (11.41, 34.65); `589@354` (-70.19, -40.35); `591@356` (-13.94, 5.62); `592@357` (-69.25, -38.62); `593@358` (-19.56, 7.45); `596@361` (-72.36, -41.15); `597@362` (-71.56, -40.71); `598@363` (-70.13, -38.26); `599@364` (-70.99, -39.92); `600@365` (-48.88, -39.27); `602@367` (-71.28, -38.20); `603@368` (-70.86, -39.01); `604@369` (-67.36, -37.05); `605@370` (15.39, -22.09); `606@371` (-73.04, -40.54); `608@373` (-68.56, -38.02); `609@374` (-74.89, -40.80); `610@375` (-73.95, -40.63); `612@377` (-20.30, 3.11); `613@378` (42.92, -35.29); `614@379` (50.86, 21.30); `615@380` (52.00, 18.33); `616@381` (50.78, 13.98); `617@382` (52.28, 17.39); `618@383` (49.51, -4.89); `619@384` (53.23, 23.84); `620@385` (25.57, 41.25); `621@386` (29.09, 41.25); `622@387` (50.08, -14.69); `623@388` (51.32, -16.13); `624@389` (2.04, -38.37); `625@390` (-0.23, -37.04); `626@391` (-8.05, -37.23); `627@392` (-6.85, -39.30); `631@396` (-19.47, 8.68); `632@397` (-20.84, 8.91); `635@400` (-31.13, 27.29); `636@401` (-31.43, 26.41); `637@402` (-32.70, 26.03); `638@403` (-39.82, 23.70); `639@404` (-42.34, 21.61). Player (75.30, -6.40).
- `phase/cellar`, `step/wait` at 354.43 s, 79/79 unreachable: `347@170` (-71.30, 44.14); `349@172` (-70.60, 44.10); `351@174` (-70.32, 43.28); `380@201` (-73.69, 44.60); `384@205` (-72.03, 44.15); `405@225` (-74.84, 43.96); `417@236` (-74.47, 42.79); `418@237` (-72.71, 43.98); `423@242` (-72.99, 44.61); `424@243` (-72.32, 44.78); `428@246` (-71.64, 44.75); `433@251` (-19.94, 10.73); `435@253` (-71.68, 43.55); `437@255` (-73.73, 45.28); `443@261` (-72.34, 43.40); `464@277` (-68.40, -40.64); `473@286` (-14.17, 23.35); `485@296` (-30.22, 30.67); `488@299` (-14.75, 24.92); `492@302` (-7.86, 8.43); `493@303` (-71.10, 42.82); `495@305` (-71.92, 42.84); `497@307` (-70.94, 44.73); `504@314` (-73.41, 43.97); `508@318` (-73.06, 43.39); `512@322` (-70.98, 43.52); `516@326` (-74.96, 43.27); `519@328` (-72.69, 42.80); `524@333` (-74.15, 44.07); `525@334` (-1.25, 21.90); `528@337` (-74.53, 44.86); `530@339` (-74.09, 43.38); `531@340` (-72.93, 45.47); `532@341` (-72.03, 45.56); `535@344` (-73.63, 42.86); `537@346` (-8.38, 11.52); `556@347` (13.94, 36.18); `589@354` (-71.14, -40.88); `592@357` (-70.26, -39.22); `593@358` (-20.09, 2.78); `595@360` (-19.94, 3.68); `596@361` (-73.49, -41.81); `597@362` (-72.70, -41.35); `598@363` (-71.36, -39.16); `599@364` (-72.05, -40.70); `600@365` (-50.04, -39.47); `601@366` (14.45, -19.41); `602@367` (-72.23, -38.86); `603@368` (-72.12, -39.79); `604@369` (-68.35, -37.68); `605@370` (16.29, -23.32); `606@371` (-74.19, -41.22); `608@373` (-69.56, -38.64); `609@374` (-76.05, -41.82); `610@375` (-75.11, -41.34); `611@376` (-18.30, -3.97); `613@378` (42.92, -35.29); `614@379` (55.84, 19.53); `615@380` (51.70, 13.99); `616@381` (48.53, 18.04); `617@382` (52.10, 21.70); `618@383` (49.74, -2.01); `619@384` (62.10, 24.05); `620@385` (25.57, 41.25); `621@386` (29.09, 41.25); `622@387` (49.43, -12.58); `623@388` (51.53, -11.86); `624@389` (16.70, -28.04); `625@390` (10.06, -34.33); `626@391` (1.73, -34.78); `627@392` (-12.56, -38.09); `630@395` (-31.34, 29.74); `631@396` (-18.00, 9.08); `632@397` (-18.89, 8.85); `635@400` (-27.47, 31.60); `636@401` (-32.08, 31.92); `637@402` (-29.91, 32.19); `638@403` (-31.16, 31.95); `639@404` (-36.31, 32.26). Player (74.65, -2.13).
- `phase/done` at 355.43 s, 79/79 unreachable: `347@170` (-71.31, 44.13); `349@172` (-70.59, 44.11); `351@174` (-70.31, 43.27); `380@201` (-73.71, 44.60); `384@205` (-72.07, 44.13); `405@225` (-74.85, 43.98); `417@236` (-74.47, 42.79); `418@237` (-72.73, 43.97); `423@242` (-73.00, 44.61); `424@243` (-72.32, 44.79); `428@246` (-71.64, 44.75); `433@251` (-19.87, 10.67); `435@253` (-71.68, 43.53); `437@255` (-73.72, 45.28); `443@261` (-72.36, 43.39); `464@277` (-68.40, -40.64); `473@286` (-14.17, 23.35); `485@296` (-30.23, 30.71); `488@299` (-14.75, 24.92); `492@302` (-7.86, 8.43); `493@303` (-71.10, 42.87); `495@305` (-71.94, 42.86); `497@307` (-70.94, 44.72); `504@314` (-73.42, 43.99); `508@318` (-73.07, 43.38); `512@322` (-70.96, 43.54); `516@326` (-74.95, 43.29); `519@328` (-72.69, 42.80); `524@333` (-74.16, 44.08); `525@334` (-1.74, 22.98); `528@337` (-74.53, 44.87); `530@339` (-74.09, 43.38); `531@340` (-72.93, 45.48); `532@341` (-72.02, 45.56); `535@344` (-73.63, 42.85); `537@346` (-8.18, 10.75); `556@347` (14.85, 36.72); `589@354` (-71.14, -40.88); `592@357` (-70.26, -39.22); `593@358` (-21.23, 3.80); `595@360` (-19.16, 3.37); `596@361` (-73.49, -41.81); `597@362` (-72.70, -41.35); `598@363` (-71.36, -39.16); `599@364` (-72.05, -40.70); `600@365` (-50.04, -39.47); `601@366` (14.45, -19.41); `602@367` (-72.23, -38.86); `603@368` (-72.12, -39.79); `604@369` (-68.35, -37.68); `605@370` (16.53, -23.91); `606@371` (-74.19, -41.22); `608@373` (-69.56, -38.64); `609@374` (-76.05, -41.82); `610@375` (-75.11, -41.34); `611@376` (-18.16, -3.96); `613@378` (42.92, -35.29); `614@379` (56.23, 19.32); `615@380` (51.77, 12.61); `616@381` (48.08, 19.37); `617@382` (52.59, 20.87); `618@383` (49.66, -0.63); `619@384` (63.34, 24.08); `620@385` (25.57, 41.25); `621@386` (29.09, 41.25); `622@387` (49.86, -13.29); `623@388` (51.51, -10.69); `624@389` (17.26, -29.76); `625@390` (13.41, -29.76); `626@391` (5.49, -34.75); `627@392` (-13.61, -37.87); `630@395` (-31.43, 30.17); `631@396` (-18.35, 9.23); `632@397` (-18.96, 8.22); `635@400` (-24.55, 33.97); `636@401` (-31.61, 32.71); `637@402` (-29.88, 32.04); `638@403` (-30.98, 32.03); `639@404` (-36.43, 33.76). Player (74.65, -2.13).

## L5

Threat steps explicitly selected from the loaded mission definition:

- `look` — Look for anyone still alive (combat; L5-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/emerge — emerge: Unbar the cellar door | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/100 | 0/100 | (75.30, -5.39) | — |
| phase/cellar — controller: cellar | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/100 | 0/100 | (74.66, -1.77) | — |
| phase/emerged — controller: emerged | — | 30.00 player + 0.00 group/min; 6.23 s | 30.00 player + 0.00 group/min; 6.23 s | 100/100 | 100/100 | (-79.30, -44.28) | — |
| step/look — look: Look for anyone still alive | L5-05 | 601.99 player + 1.21 group/min; 0.05 s | 4.47 player + 0.00 group/min; 0.05 s | 100/100 | 40/40 | (37.72, -49.84) | — |
| phase/search — controller: search | — | 601.99 player + 1.21 group/min; 0.05 s | 4.47 player + 0.00 group/min; 0.05 s | 100/100 | 40/40 | (37.72, -49.84) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/emerge` at 0.02 s, 100/100 unreachable: `84@3` (-20.00, -37.60); `86@4` (-17.50, -36.10); `88@5` (-22.00, 10.00); `90@1` (46.00, 36.00); `91@6` (22.00, -37.40); `93@7` (-26.00, 40.00); `95@8` (-23.50, 41.50); `97@2` (-40.00, -37.40); `98@9` (2.00, 43.60); `100@10` (14.00, -2.00); `102@11` (-12.00, 18.00); `104@12` (44.00, -36.40); `106@13` (46.50, -34.90); `108@14` (-6.00, -37.40); `110@15` (10.00, 13.00); `112@16` (-46.00, -37.50); `114@17` (36.00, -37.40); `116@18` (-12.00, 43.60); `118@19` (14.00, -24.00); `120@20` (-60.00, 43.00); `122@21` (-4.00, 28.00); `124@22` (-40.00, -20.00); `126@23` (-8.90, 2.60); `128@24` (0.10, 2.60); `130@25` (53.50, 41.30); `132@26` (62.50, 41.30); `134@27` (-29.00, -2.70); `136@28` (-25.87, -44.40); `138@29` (-49.50, 50.00); `140@30` (-40.50, 50.00); `142@31` (68.00, -37.40); `144@32` (48.00, -12.00); `146@33` (40.00, 43.60); `148@34` (4.00, -37.40); `150@35` (0.00, -12.00); `152@36` (-4.00, 14.00); `154@37` (-16.00, -12.00); `156@38` (-28.00, -37.40); `158@39` (-32.00, -12.00); `160@40` (-36.00, 14.00); `162@41` (-60.00, -37.40); `164@42` (-72.00, 43.60); `166@43` (64.00, 2.00); `168@44` (60.00, 28.00); `170@45` (48.00, 2.00); `172@46` (4.00, -24.00); `174@47` (-16.00, 2.00); `176@48` (-32.00, 2.00); `178@49` (-36.00, 28.00); `180@50` (56.00, -37.40); `182@51` (52.00, -12.00); `184@52` (48.00, 14.00); `186@53` (12.00, 43.60); `188@54` (8.00, -37.40); `190@55` (0.00, 14.00); `192@56` (-28.00, -12.00); `194@57` (-36.00, 43.60); `196@58` (-52.00, 43.60); `198@59` (-56.00, -37.40); `200@60` (-68.00, 43.60); `202@61` (64.00, 28.00); `204@62` (52.00, 2.00); `206@63` (48.00, 28.00); `208@64` (-16.00, 28.00); `210@65` (-28.00, 2.00); `212@66` (-32.00, 28.00); `214@67` (60.00, -37.40); `216@68` (52.00, 14.00); `218@69` (48.00, 43.60); `220@70` (32.00, 43.60); `222@71` (16.00, 43.60); `224@72` (12.00, -37.40); `226@73` (-8.00, -12.00); `228@74` (-24.00, -12.00); `230@75` (-40.00, -12.00); `232@76` (-48.00, 43.60); `234@77` (68.00, 28.00); `236@78` (56.00, 2.00); `238@79` (52.00, 28.00); `240@80` (-12.00, 28.00); `242@81` (-20.00, -24.00); `244@82` (-24.00, 2.00); `246@83` (-28.00, 28.00); `248@84` (68.00, 43.60); `250@85` (64.00, -37.40); `252@86` (36.00, 43.60); `254@87` (12.00, -12.00); `256@88` (-4.00, -12.00); `258@89` (-20.00, -12.00); `260@90` (-32.00, -37.40); `262@91` (-36.00, -12.00); `264@92` (-40.00, 14.00); `266@93` (-44.00, 43.60); `268@94` (-64.00, -37.40); `270@95` (-76.00, 43.60); `272@96` (60.00, 2.00); `274@97` (56.00, 28.00); `276@98` (48.00, -24.00); `278@99` (0.00, -24.00); `280@100` (-20.00, 2.00). Player (75.30, -5.39).
- `phase/cellar` at 1.00 s, 100/100 unreachable: `84@3` (-20.00, -37.60); `86@4` (-17.30, -36.15); `88@5` (-21.79, 9.95); `90@1` (46.00, 36.00); `91@6` (21.56, -37.50); `93@7` (-26.00, 40.00); `95@8` (-23.54, 41.62); `97@2` (-40.00, -37.40); `98@9` (2.30, 43.54); `100@10` (13.96, -1.67); `102@11` (-12.00, 18.02); `104@12` (44.18, -36.40); `106@13` (46.31, -35.00); `108@14` (-5.70, -37.42); `110@15` (10.01, 12.98); `112@16` (-45.87, -37.55); `114@17` (36.12, -37.62); `116@18` (-12.02, 43.63); `118@19` (13.92, -24.32); `120@20` (-59.98, 42.86); `122@21` (-4.05, 27.91); `124@22` (-39.89, -19.80); `126@23` (-8.69, 2.47); `128@24` (0.07, 2.56); `130@25` (53.78, 41.29); `132@26` (62.49, 41.32); `134@27` (-28.94, -2.77); `136@28` (-25.87, -44.40); `138@29` (-49.58, 49.96); `140@30` (-40.83, 49.94); `142@31` (68.43, -37.61); `144@32` (48.04, -11.61); `146@33` (40.02, 43.64); `148@34` (4.29, -37.38); `150@35` (-0.01, -12.00); `152@36` (-4.04, 13.99); `154@37` (-16.04, -11.90); `156@38` (-27.82, -37.50); `158@39` (-31.77, -11.82); `160@40` (-36.01, 13.99); `162@41` (-60.16, -37.49); `164@42` (-72.22, 43.71); `166@43` (64.00, 2.00); `168@44` (59.86, 28.08); `170@45` (47.99, 1.50); `172@46` (3.72, -23.88); `174@47` (-16.01, 1.98); `176@48` (-32.00, 2.00); `178@49` (-36.10, 27.98); `180@50` (56.12, -37.42); `182@51` (51.96, -11.92); `184@52` (48.01, 14.00); `186@53` (11.51, 43.65); `188@54` (8.17, -37.30); `190@55` (-0.00, 14.00); `192@56` (-27.99, -12.00); `194@57` (-36.01, 43.64); `196@58` (-52.03, 43.55); `198@59` (-55.97, -37.40); `200@60` (-67.90, 43.72); `202@61` (63.63, 28.21); `204@62` (52.00, 2.00); `206@63` (48.07, 28.41); `208@64` (-15.98, 27.98); `210@65` (-28.00, 1.97); `212@66` (-32.11, 27.82); `214@67` (59.95, -37.39); `216@68` (51.77, 14.24); `218@69` (48.03, 43.62); `220@70` (32.04, 44.10); `222@71` (15.82, 43.69); `224@72` (11.76, -37.58); `226@73` (-7.99, -11.98); `228@74` (-23.98, -11.89); `230@75` (-40.00, -12.00); `232@76` (-48.00, 43.60); `234@77` (68.00, 28.00); `236@78` (55.97, 1.98); `238@79` (51.99, 27.97); `240@80` (-11.90, 27.80); `242@81` (-20.00, -24.00); `244@82` (-23.91, 2.30); `246@83` (-28.35, 27.68); `248@84` (67.93, 43.62); `250@85` (63.88, -37.39); `252@86` (35.90, 43.65); `254@87` (11.93, -11.75); `256@88` (-4.06, -11.74); `258@89` (-20.34, -11.70); `260@90` (-31.88, -37.46); `262@91` (-36.15, -12.28); `264@92` (-39.99, 14.06); `266@93` (-44.36, 43.63); `268@94` (-64.00, -37.40); `270@95` (-76.14, 43.65); `272@96` (59.63, 1.80); `274@97` (55.69, 27.90); `276@98` (48.00, -23.97); `278@99` (-0.07, -23.96); `280@100` (-19.77, 2.27). Player (74.66, -1.77).
- `step/metro`, `phase/shelter` at 185.68 s, 25/25 unreachable: `90@1` (49.70, 39.85); `91@6` (23.56, -38.11); `93@7` (-21.60, 47.19); `97@2` (-41.70, -42.08); `106@13` (54.39, -40.46); `108@14` (-12.46, -40.09); `118@19` (12.96, -33.14); `132@26` (49.96, 44.61); `138@29` (-60.21, 44.41); `142@31` (73.11, -41.84); `148@34` (5.49, -37.90); `162@41` (-67.98, -40.92); `172@46` (12.36, -18.17); `186@53` (7.09, 44.59); `188@54` (13.11, -26.59); `192@56` (-22.50, -8.51); `224@72` (12.29, -27.73); `226@73` (-2.68, -3.87); `234@77` (71.36, 29.19); `240@80` (-13.99, 22.37); `246@83` (-36.86, 22.33); `248@84` (77.20, 51.47); `250@85` (74.29, -37.71); `254@87` (12.58, -11.54); `278@99` (-0.51, -19.15). Player (38.19, -50.04).
- `phase/done` at 186.68 s, 25/25 unreachable: `90@1` (49.70, 39.85); `91@6` (24.88, -38.54); `93@7` (-21.60, 47.19); `97@2` (-41.70, -42.08); `106@13` (53.37, -40.10); `108@14` (-12.73, -40.54); `118@19` (12.20, -33.52); `132@26` (49.81, 45.65); `138@29` (-61.28, 44.21); `142@31` (73.21, -40.73); `148@34` (6.62, -37.94); `162@41` (-67.99, -40.92); `172@46` (12.49, -17.04); `186@53` (7.13, 45.69); `188@54` (12.68, -26.44); `192@56` (-21.95, -9.38); `224@72` (11.72, -26.89); `226@73` (-2.17, -4.83); `234@77` (71.36, 29.19); `240@80` (-14.27, 23.47); `246@83` (-36.83, 22.13); `248@84` (77.29, 51.41); `250@85` (74.46, -36.70); `254@87` (12.29, -10.48); `278@99` (-0.42, -18.11). Player (38.19, -50.04).

## L6

Threat steps explicitly selected from the loaded mission definition:

- `stop` — Stop the infected (combat; L6-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/shelter — shelter: Look around the shelter | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (0.33, 3.56) | — |
| phase/shelter — controller: shelter | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (0.33, 3.56) | — |
| step/stop — stop: Stop the infected | L6-05 | 265.50 player + 88.50 group/min; 5.77 s | 0.00 player + 37.11 group/min; — s | 20/20 | 3/3 | (0.33, 3.56) | — |
| phase/first — controller: first | — | 265.50 player + 88.50 group/min; 5.77 s | 0.00 player + 37.11 group/min; — s | 20/20 | 3/3 | (0.33, 3.56) | — |
| step/retreat — retreat: Cover the retreat through the tunnel | — | 724.95 player + 109.71 group/min; 0.05 s | 12.76 player + 67.00 group/min; 34.22 s | 21/21 | 9/9 | (0.33, 3.56) | — |
| phase/retreat — controller: retreat | — | 724.95 player + 109.71 group/min; 0.05 s | 12.76 player + 67.00 group/min; 34.22 s | 21/21 | 9/9 | (0.33, 3.56) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| l6.breach1 | l6.breach1 | 33.20 | 76.80 | 8 | 8 | — | 5.77 | — |
| l6.breach2 | l6.breach2 | 54.22 | 55.78 | 10 | 1 | — | 11.02 | WAVE_FEWER_THAN_THREE_COHORT_MEMBERS |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L7

Threat steps explicitly selected from the loaded mission definition:

- `corridor` — Bring the group to the evacuation corridor (combat; L7-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/rocket — rocket: Recover the rocket launcher beside the exit | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 98/98 | (273.01, 15.00) | — |
| phase/pickup — controller: pickup | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 98/98 | (273.01, 15.00) | — |
| step/corridor — corridor: Bring the group to the evacuation corridor | L7-05 | 158.56 player + 24.50 group/min; 0.07 s | 11.18 player + 0.00 group/min; 0.68 s | 99/99 | 61/61 | (-18.95, 47.93) | SLOW_FOLLOWER:62, SLOW_FOLLOWER:63, SLOW_FOLLOWER:67, SLOW_FOLLOWER:70, SLOW_FOLLOWER:71, SLOW_FOLLOWER:74 |
| phase/encounters — controller: encounters | — | 186.21 player + 21.53 group/min; 0.07 s | 9.70 player + 0.00 group/min; 0.68 s | 93/93 | 0/0 | (-57.88, 47.26) | SLOW_FOLLOWER:62, SLOW_FOLLOWER:63, SLOW_FOLLOWER:67, SLOW_FOLLOWER:70, SLOW_FOLLOWER:71, SLOW_FOLLOWER:74 |
| step/departure — departure: Get everyone aboard the bus | — | 216.76 player + 0.00 group/min; 0.52 s | 0.00 player + 0.00 group/min; — s | 98/98 | 0/0 | (35.94, 47.00) | — |
| phase/departing — controller: departing | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 0/0 | (35.94, 47.00) | — |
| phase/done — controller: done | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 0/0 | (40.00, 47.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L8

Threat steps explicitly selected from the loaded mission definition:

- `escape` — Bring the survivors to the armored vehicle and board (breach combat; L8-06).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/escape — escape: Bring the survivors to the armored vehicle and board | L8-06 | 244.19 player + 8.23 group/min; 63.82 s | 1.91 player + 0.00 group/min; 61.97 s | 83/83 | 78/78 | (94.07, 77.20) | — |
| phase/sanctuary — controller: sanctuary | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (23.14, 64.15) | — |
| phase/breached — controller: breached | — | 430.63 player + 14.51 group/min; 3.82 s | 5.24 player + 0.00 group/min; 1.97 s | 83/83 | 78/78 | (94.07, 77.20) | — |
| step/depart — depart: Wait for everyone to board the armored vehicle | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 81/81 | 78/78 | (96.00, 74.00) | — |
| phase/boarding — controller: boarding | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 81/81 | 79/79 | (96.00, 74.00) | — |
| phase/run-out — level-end run-out | — | 24.00 player + 0.00 group/min; 2.65 s | — | 82/82 | — | (96.00, 74.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| tunnel-breach | L8 breachedAt/story.say | 60.00 | 84.58 | 12 | 12 | 3, 3, 3, 3 | 3.82 | — |
| tunnel-reinforcement@4200 | L8 nextWave clock | 70.00 | 74.58 | 16 | 16 | — | 2.98 | — |
| tunnel-reinforcement@4440 | L8 nextWave clock | 74.00 | 70.58 | 16 | 16 | — | 4.08 | — |
| tunnel-reinforcement@4680 | L8 nextWave clock | 78.00 | 66.58 | 16 | 16 | — | 2.92 | — |
| tunnel-reinforcement@4920 | L8 nextWave clock | 82.00 | 62.58 | 16 | 16 | — | 2.87 | — |
| tunnel-reinforcement@5160 | L8 nextWave clock | 86.00 | 58.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5400 | L8 nextWave clock | 90.00 | 54.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5640 | L8 nextWave clock | 94.00 | 50.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5880 | L8 nextWave clock | 98.00 | 46.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6120 | L8 nextWave clock | 102.00 | 42.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6360 | L8 nextWave clock | 106.00 | 38.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6600 | L8 nextWave clock | 110.00 | 34.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6840 | L8 nextWave clock | 114.00 | 30.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7080 | L8 nextWave clock | 118.00 | 26.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7320 | L8 nextWave clock | 122.00 | 22.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7560 | L8 nextWave clock | 126.00 | 18.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7800 | L8 nextWave clock | 130.00 | 14.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8040 | L8 nextWave clock | 134.00 | 10.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8280 | L8 nextWave clock | 138.00 | 6.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8520 | L8 nextWave clock | 142.00 | 2.58 | 16 | 0 | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L9

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/approach — approach: Drive toward the city | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (466.34, 3.29) | — |
| phase/driving — controller: driving | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (466.34, 3.29) | — |
| phase/approach — controller: approach | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 4/4 | 4/4 | (494.74, 1.14) | — |
| phase/fall — controller: fall | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (508.00, 0.00) | — |
| step/reach-outskirts — reach-outskirts: Get clear of the wreck | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (540.50, 0.87) | — |
| phase/impact — controller: impact | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (527.50, 2.60) | — |
| phase/crawl — controller: crawl | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (540.50, 0.87) | — |
| phase/done — controller: done | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (547.00, 0.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L10

Threat steps explicitly selected from the loaded mission definition:

- `hold` — Charge the dispersal system (assault combat; L10-11).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/crash — crash: Leave the wreck on foot | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/residential-fringe — residential-fringe: Recover the handgun at the checkpoint | — | 156.52 player + 0.00 group/min; 5.32 s | 8.24 player + 0.00 group/min; 5.32 s | 7/7 | 5/5 | (763.90, 25.00) | — |
| step/industrial-area — industrial-area: Recover the shotgun at the checkpoint | — | 382.65 player + 0.00 group/min; 0.18 s | 7.68 player + 0.00 group/min; 28.43 s | 18/19 | 7/8 | (1253.25, 25.00) | — |
| step/military-zone — military-zone: Recover the machine gun at the checkpoint | — | 528.85 player + 0.00 group/min; 0.10 s | 8.36 player + 0.00 group/min; 36.52 s | 33/34 | 4/5 | (1849.67, 25.01) | — |
| step/research-campus — research-campus: Reach the research campus | — | 304.24 player + 0.00 group/min; 0.13 s | 14.25 player + 0.00 group/min; 11.45 s | 7/8 | 4/5 | (2461.00, -5.14) | — |
| step/research — research: Play the research recording | — | 338.87 player + 0.00 group/min; 2.67 s | 46.08 player + 0.00 group/min; 9.75 s | 54/55 | 28/29 | (2703.11, 41.37) | — |
| step/cure — cure: Pack the cure canister | — | 585.00 player + 0.00 group/min; 0.02 s | 0.00 player + 0.00 group/min; — s | 54/55 | 15/16 | (2705.13, 41.31) | — |
| step/research-exit — research-exit: Get the cure out of the laboratory | — | 860.45 player + 0.00 group/min; 0.02 s | 0.00 player + 0.00 group/min; — s | 52/53 | 1/2 | (2800.42, 44.74) | — |
| step/destroyed-corridor — destroyed-corridor: Carry the cure down the corridor and grab the rocket launcher | — | 934.52 player + 0.00 group/min; 0.07 s | 21.36 player + 0.00 group/min; 9.50 s | 54/55 | 19/20 | (2930.18, -4.99) | — |
| step/dispersal-complex — dispersal-complex: Bring the cure to the dispersal complex | — | 215.19 player + 0.00 group/min; 0.18 s | 5.54 player + 0.00 group/min; 43.53 s | 8/8 | 1/1 | (3691.37, -24.93) | — |
| step/install — install: Install the cure in the dispersal device | — | 243.61 player + 0.00 group/min; 0.90 s | 7.16 player + 0.00 group/min; 8.60 s | 19/20 | 0/1 | (4002.51, -37.12) | — |
| step/hold — hold: Charge the dispersal system | L10-11 | 1091.17 player + 0.00 group/min; 0.10 s | 70.23 player + 0.00 group/min; 6.77 s | 95/95 | 36/36 | (4002.79, -28.73) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| dispersal-assault | L10 charge-active (not first spawn) | 1002.72 | 59.98 | — | 75 | — | 4.65 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/industrial-area` at 190.28 s, 1/8 unreachable: `119@17` (1029.80, 80.00). Player (1252.90, 25.00).
- `step/military-zone` at 355.02 s, 1/5 unreachable: `119@17` (1496.54, 100.00). Player (1850.05, 25.01).
- `step/research-campus` at 528.15 s, 1/5 unreachable: `119@17` (1948.72, -75.00). Player (2462.27, -5.11).
- `step/research` at 590.77 s, 1/29 unreachable: `119@17` (2175.55, -75.00). Player (2697.03, 41.56).
- `step/cure` at 592.57 s, 1/16 unreachable: `119@17` (2182.07, -75.00). Player (2705.13, 41.31).
- `step/research-exit` at 614.02 s, 1/2 unreachable: `119@17` (2259.77, -75.00). Player (2801.59, 44.79).
- `step/destroyed-corridor` at 652.78 s, 1/20 unreachable: `119@17` (2527.00, 24.05). Player (2929.14, -4.99).
- `step/dispersal-complex` at 786.12 s, 1/1 unreachable: `119@17` (3233.73, 70.51). Player (3432.02, 94.90).
- `step/install` at 944.57 s, 1/1 unreachable: `119@17` (3797.00, -36.30). Player (3999.20, -35.56).

## Every fail flag

- L3/criterion/L3-02 cohorts:FAIL
- L6/wave/l6.breach2:WAVE_FEWER_THAN_THREE_COHORT_MEMBERS
- L7/step/corridor:SLOW_FOLLOWER:62
- L7/step/corridor:SLOW_FOLLOWER:63
- L7/step/corridor:SLOW_FOLLOWER:67
- L7/step/corridor:SLOW_FOLLOWER:70
- L7/step/corridor:SLOW_FOLLOWER:71
- L7/step/corridor:SLOW_FOLLOWER:74
- L7/phase/encounters:SLOW_FOLLOWER:62
- L7/phase/encounters:SLOW_FOLLOWER:63
- L7/phase/encounters:SLOW_FOLLOWER:67
- L7/phase/encounters:SLOW_FOLLOWER:70
- L7/phase/encounters:SLOW_FOLLOWER:71
- L7/phase/encounters:SLOW_FOLLOWER:74

## Flag-to-criterion mapping

| Flag | Acceptance criterion |
|---|---|
| L3/criterion/L3-02 cohorts:FAIL | see level-specific threat criterion |
| L6/wave/l6.breach2:WAVE_FEWER_THAN_THREE_COHORT_MEMBERS | see level-specific threat criterion |
| L7/step/corridor:SLOW_FOLLOWER:62 | G-13 |
| L7/step/corridor:SLOW_FOLLOWER:63 | G-13 |
| L7/step/corridor:SLOW_FOLLOWER:67 | G-13 |
| L7/step/corridor:SLOW_FOLLOWER:70 | G-13 |
| L7/step/corridor:SLOW_FOLLOWER:71 | G-13 |
| L7/step/corridor:SLOW_FOLLOWER:74 | G-13 |
| L7/phase/encounters:SLOW_FOLLOWER:62 | G-13 |
| L7/phase/encounters:SLOW_FOLLOWER:63 | G-13 |
| L7/phase/encounters:SLOW_FOLLOWER:67 | G-13 |
| L7/phase/encounters:SLOW_FOLLOWER:70 | G-13 |
| L7/phase/encounters:SLOW_FOLLOWER:71 | G-13 |
| L7/phase/encounters:SLOW_FOLLOWER:74 | G-13 |

Absolute targets come from `docs/qa/level-acceptance.md`. L4 high-tier census supplements the low-tier passive contact/reachability run; its plaza uses the authored `l4.map.plaza` bounds. Both level and alarm clocks are reported; first breach must occur at level time 30–60 s with ≥60 alive. L3’s scheduled 18 s streams retain unspawned entries under the strict live cap (E21 §5.6); actual admissions within 18 s are shown separately, and the complete native route must produce every authored member. Armory visibility, actual squad attrition, competent damage and mortal input completion require the playtest report.

## Defect triage provenance

Historical failures and the original handoff are in `docs/reports/threat-calibrate/README.md`. They are baseline evidence, not current-run findings. Current failures are listed above with criterion mappings.

Run `npm run qa:threat -- --maxWorkers=2` for current JSON/Markdown receipts in `test-results/qa-threat/`. To refresh this baseline deliberately, add `--report docs/reports/threat-audit/README.md`. Remote: `sh tools/remote/run.sh "$PWD" --pull test-results/qa-threat -- npm run qa:threat -- --maxWorkers=2`. `npm run qa:threat -- --proof` proves the fail thresholds using deliberately broken fixtures without adding registered unit cases. `npm run qa:threat -- --passive-from test-results/qa-threat/audit.json` repeats the same policies without instrumentation and checks complete state hashes; add the same `--report` option to save proof with the baseline.
