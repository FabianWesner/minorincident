import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { preset } from '../../../src/sim/progression/Campaign';
import { stateHash } from '../../../src/sim/world/stateHash';
import { runLevel } from '../../sim-runner/levels';
import { provenance } from './probe';
import { atomicJson } from './report';
const identity = provenance(), rows = [], root = 'docs/reports/sweep-c5/L8-10'; mkdirSync(root, { recursive: true });
for (const tier of ['low', 'high'] as const) {
  const campaign = preset('L8-default'); campaign.settings.quality = tier;
  const controlPath = `docs/reports/fix51-verify/receipts/L8-${tier}-complete.json`, control = JSON.parse(readFileSync(controlPath, 'utf8'));
  const finalTick = control.observation.final.tick;
  let seed: object | null = null, finalHash = '';
  const run = await runLevel('L8', 'complete', 1, undefined, 'auto', campaign, undefined, 0, { quality: tier,
    beforeBegin: world => {
      const update = world.update.bind(world);
      world.update = () => {
        const m = world.missions!, remaining = finalTick - world.tick;
        if (!seed && remaining > 0 && remaining <= 120 && m.state.phase === 'playing' && m.state.steps.escape.status === 'completed') seed = { campaign: structuredClone(campaign), resume: m.saveResume(), remainingTicks: remaining };
        update();
      };
    }, beforeDispose: world => { finalHash = stateHash(world.getState()); },
  });
  assert(run.completed && seed); assert.equal(control.sourceHash, identity.sourceHash); assert.equal(control.observerHash, identity.observerHash); assert.equal(finalHash, control.nativeStateHash);
  const path = `${root}/${tier}-predeparture.json.gz`, bytes = gzipSync(JSON.stringify(seed)); writeFileSync(path, bytes);
  rows.push({ tier, path, sha256: createHash('sha256').update(bytes).digest('hex'), nativeStateHash: finalHash, controlPath, controlIdentical: true });
  console.log(tier, 'natural predeparture Resume retained; canonical control identical');
}
atomicJson(`${root}/native-seeds.json`, { ...identity, toolSha256: createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'),
  method: 'Read-only canonical L8 routes at both tiers; retain one production Resume at most120ticks before canonical completion after the courier has boarded, during natural group boarding/departure or action run-out. No actor/input/objective edits. Full final state equals independent canonical control. Browser separately restores this normal production snapshot before rendering and observes the automatic L8→L9 seam.', rows });
