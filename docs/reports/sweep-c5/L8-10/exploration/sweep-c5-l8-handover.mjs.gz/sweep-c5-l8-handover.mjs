import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:net';
import { spawn } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { launchBrowser } from '../../browser-pool/client.ts';
import { provenance } from './probe.ts';
import { browserHash } from './browser.ts';

const tier = process.argv[2]; assert(['low', 'high'].includes(tier));
const identity = provenance(), hash = browserHash(), sha = bytes => createHash('sha256').update(bytes).digest('hex');
const build=JSON.parse(readFileSync('dist/.qa-accept-build.json','utf8')); assert.equal(build.sourceHash,identity.sourceHash); assert.equal(build.browserHash,hash);
const root = 'docs/reports/sweep-c5/L8-10', nativePath = `${root}/native-seeds.json`, nativeBytes = readFileSync(nativePath), native = JSON.parse(nativeBytes);
assert.equal(native.sourceHash, identity.sourceHash); assert.equal(native.toolSha256, sha(readFileSync('tools/qa/accept/l8-handover-save.ts')));
const source = native.rows.find(row => row.tier === tier); assert(source.controlIdentical);
const seedBytes = readFileSync(source.path); assert.equal(sha(seedBytes), source.sha256); const seed = JSON.parse(gunzipSync(seedBytes).toString());
const out = resolve(`test-results/sweep-c5/L8-10-${tier}-${Date.now()}`); mkdirSync(out, { recursive: true });
const socket = createServer(); await new Promise(r => socket.listen(0, '127.0.0.1', r)); const port = socket.address().port; await new Promise(r => socket.close(r)); assert.notEqual(port, 3300);
const server = spawn(process.execPath, [resolve('node_modules/vite/bin/vite.js'), 'preview', '--host', '127.0.0.1', '--port', String(port), '--strictPort', '--configLoader', 'runner'], { stdio: 'ignore' });
const browser = await launchBrowser({ headless: true, args: ['--use-angle=metal', '--enable-gpu', '--ignore-gpu-blocklist'] });
const errors = [], captures = []; let setup, result;
try {
  for (let i=0;i<100;i++) { try { if ((await fetch(`http://127.0.0.1:${port}`)).ok) break; } catch {} await delay(100); }
  const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
  try {
    const page = await context.newPage(); page.setDefaultTimeout(120000); page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type()==='error') errors.push(m.text()); });
    await page.addInitScript('window.__name=f=>f'); await page.goto(`http://127.0.0.1:${port}/?test=1&ui=1&scenelab=1&renderer=webgl&quality=${tier}&audio=muted&preload=0&dpr=1`);
    await page.waitForFunction(() => !!window.__SS__ && !!window.__SCENE__);
    setup = await page.evaluate(async ({ seed, tier }) => {
      const a=window.__SS__, g=window.__SCENE__.game; await a.ready; a.pause(); a.campaign.restore(seed.campaign);
      await a.loadLevel('L8', { seed:1, record:true, setup: world => { world.missions.loadResume(seed.resume); g.clock.pause(); } });
      a.pause(); g.driver=null; g.ui.show(null); g.input.release(); g.world.clearInput();
      const w=g.world; window.__handover={ installed:performance.now(), before:null };
      w.events.on('level.completed', event => { if(event.id==='L8') { const car=w.entities.get(w.missions.l8.state.carId); window.__handover.before={tick:w.tick,at:performance.now(),car:structuredClone(car),transport:structuredClone(g.campaign.transport)}; } });
      return { level:w.scenario,tick:w.tick,phase:w.missions.state.phase,runOutUntil:w.missions.state.runOutUntil,backend:a.perf().backend,quality:a.getState().render.quality };
    }, { seed, tier });
    assert.equal(setup.level,'L8'); assert.equal(setup.phase,'playing');
    const capture = async stage => { await page.evaluate(() => window.__SS__.screenshotReady()); const file=resolve(out,`${tier}-${stage}.jpg`);await page.screenshot({path:file,type:'jpeg',quality:88});captures.push({file,sha256:sha(readFileSync(file)),stage}); };
    await capture('before'); await page.evaluate(() => window.__SS__.resume());
    await page.waitForFunction(() => window.__SCENE__.game.world.scenario==='L9' && !window.__SCENE__.game.loading && performance.getEntriesByName('transition:L9:complete-to-first-frame').some(e=>e.startTime>=window.__handover.installed), null, { timeout:120000 });
    result=await page.evaluate(() => {
      const a=window.__SS__,g=window.__SCENE__.game,w=g.world;a.pause();const car=w.entities.get(w.missions.l9.state.carId);
      const measure=performance.getEntriesByName('transition:L9:complete-to-first-frame').filter(e=>e.startTime>=window.__handover.installed).at(-1);
      return { before:window.__handover.before,after:{level:w.scenario,tick:w.tick,car:structuredClone(car),active:w.vehicles.active,transport:structuredClone(g.campaign.transport)},ms:measure.duration,measureStart:measure.startTime,backend:a.perf().backend,quality:a.getState().render.quality,loading:!document.querySelector('[data-testid="level-transition"]').hidden };
    });
    await capture('after'); console.log(tier,{ms:result.ms,before:result.before.car.id,after:result.after.car.id,hp:[result.before.car.health.current,result.after.car.health.current],errors});
  } finally { await context.close(); }
} catch(error) { errors.push(String(error)); }
finally { await browser.close();server.kill('SIGTERM');writeFileSync(`${root}/${tier}-handover.json`,JSON.stringify({...identity,browserHash:hash,toolSha256:sha(readFileSync(new URL(import.meta.url))),native:{file:nativePath,sha256:sha(nativeBytes)},seed:{file:source.path,sha256:source.sha256},out,setup,result,captures,errors,
  method:'Shared headless Metal WebGL2. Exact naturally reached predeparture production Resume installed before asset preparation; no actor/objective/HP/input edits. Normal production clock finishes boarded L8 and CampaignUI automatically loads L9. Read-only actual level.completed APC/transport and incoming live APC; existing production complete-to-first-frame clock only, no frame profiler or performance-budget changes.'},null,2)+'\n'); }
process.exitCode=errors.length?1:0;
