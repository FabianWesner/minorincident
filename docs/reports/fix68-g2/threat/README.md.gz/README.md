# Threat calibration

Runtime main: `b93ada0e176fc8811f94e27b1e7abb211b3dc4f0`; harness base: `28dad2b8ef41ad86b172db6444bc077ffc3f0470`. Runtime source matches main: **false**. Seed 1, skilled and passive native routes, **low** population set before mission preparation. Sequential simulation only; 505.54 seconds, budget 600 seconds. Result: **0 acceptance fail flags**.

[Raw audit receipts](audit.json).

## Measurement contract

Every active mission step is measured, including simultaneous objectives and instant completions; controller phases have separate rows. These overlapping views must not be summed. L1 combat starts in controller `spread`, after the instantaneous escape milestone. L2 ambush combat starts in controller `collapse`, after the doors open; the earlier door-forcing objective is retained without a combat tag. Duration is actual active fixed ticks (cinematics/results excluded). Spawn counts count successful spawns and civilian conversions, with a fresh generation for each reused pool record; “at start” is the first-tick living population. Observed/path/contact counts are unique generations seen during that phase. Contact means ever within 2.5 m of the moving player. Attacks and first-attack times count targeted attack telegraphs (including interrupted windups), physical civilian grabs and synchronous escort strikes. Support roars, screams and revives are excluded; resolved hits are never counted again. Player and following-party targets have separate counters.

Path queries use an independent copy of the native infected AI grid, with identical walls, mask, live blockers and radius rules; the Mega uses its native pursuit grid. Live resumable searches are never advanced by the audit. Queries run every two simulated seconds and on phase changes. All active living infected count in the denominator, including hidden/pending arrivals; pending admission is unreachable until admitted. Contact requires visible admission. A threat phase fails if >30% remain unreachable for >20 seconds across consecutive samples. Evidence records positions and the player position at that time. Later recovery does not erase a flag. The table also gives the last measured reachable/alive snapshot.

Followers include civilian survivor groups, allied followers, escorts and the companion (never the courier). Each follower’s median uses moving samples plus stationary samples while lagging behind a moving leader. The group min/median compare those individual medians. Leader walking/stationary time uses resolved position changes, never a stale requested velocity. Parked formation shuffling, incapacitated actors and cinematic locks do not count as walking. G-13 flags any follower below 0.95× the group median; the moving native route also measures all stationary courier ticks with any active follower >10 m away, including combat stands, as a conservative upper bound on the ≤10% waiting-share criterion. Raw per-follower values/sample counts are retained in JSON. A pace median needs ten walking samples (five seconds at 2 Hz); the named L5/L7/L8 followers must each have that coverage in the moving native route, so a stationary passive route cannot produce a false PASS. A dash means no walking sample, not zero speed.

Announced waves use native clocks/events and actual cohort ledgers. G-22 is measured by a cohort member making a real attack windup against the player within 20 s; the baseline 10 s proximity heuristic was removed. Only explicit threat announcements and first breach cohorts are gating; recurring reinforcement clocks without an acceptance threshold remain informational. Reachability is judged on the passive snapshot. The skilled route also gates zero windups in every inventoried combat phase, L2 bridge ≥2/min, L5 search ≥3/min, L10 hold ≥8/min and L6 mortal damage ≥30 HP. Passive caps are 70 s for L3, 250 s for L4, 110 s for L6, and 60 s of the L10 hold. A `tick-budget` passive outcome means the window cap ended the native route, not that the measured window is missing.

## Run coverage

| Level | Skilled outcome | Skilled sim s | Passive outcome / furthest step | Passive sim s | Phase rows | Announced waves | Wall seconds | Flags |
|---|---|---:|---:|---:|---:|---:|
| L1 | complete | 115.08 | complete / firestation | 115.08 | 11 | 0 | 15.21 | 0 |
| L2 | complete | 156.12 | complete / bridge | 188.33 | 15 | 1 | 25.66 | 0 |
| L3 | complete | 190.97 | tick-budget / checkpoint | 70.00 | 6 | 3 | 64.50 | 0 |
| L4 | complete | 372.12 | tick-budget / hide | 248.50 | 8 | 26 | 181.45 | 0 |
| L5 | complete | 193.37 | tick-budget / look | 1200.00 | 5 | 0 | 116.46 | 0 |
| L6 | complete | 264.47 | tick-budget / retreat | 110.00 | 6 | 2 | 9.60 | 0 |
| L7 | complete | 106.33 | complete / bus-departure | 103.52 | 7 | 0 | 19.01 | 0 |
| L8 | complete | 95.38 | complete / depart | 144.58 | 6 | 20 | 25.33 | 0 |
| L9 | complete | 128.13 | complete / reach-outskirts | 128.13 | 8 | 0 | 9.31 | 0 |
| L10 | complete | 1168.53 | tick-budget / hold | 1062.70 | 12 | 1 | 38.97 | 0 |

## Acceptance criteria matrix

| Criterion | Passive measured | Skilled measured | Expected | Verdict |
|---|---:|---:|---|---|
| L1-08 | 25.09 | — | ≥ 3/min | PASS |
| L2-07 | 49.18 (12.20 s) | — | ≥ 4/min | SHORT WINDOW |
| L2-07 reach | 100.00% | — | ≥ 90% | PASS |
| L2-12 | — | 10.38 | ≥ 2 and ≤ 20/min | PASS |
| L3-03 | 149.56 | — | ≥ 4/min | PASS |
| L3-03 reach | 100.00% | — | ≥ 90% | PASS |
| L4-07 | 1000.11 | — | ≥ 6/min | PASS |
| L4-07 reach | 100.00% | — | ≥ 90% | PASS |
| L5-05 | 599.87 + 0.86 group | — | ≥ 3/min | PASS |
| L6-05 | 265.50 | — | ≥ 4/min | PASS |
| L6-05 reach | 100.00% | — | ≥ 95% | PASS |
| L6-06 | 100.00% | — | ≥ 95% | PASS |
| L7-05 | 160.87 + 25.36 group | — | ≥ 6/min | PASS |
| L8-06 | 244.19 + 8.23 group | — | ≥ 4/min | PASS |
| L10-11 | 1091.17 | — | ≥ 8/min | PASS |
| G-13 | none | L5/28: 101.2% (43 samples); L5/31: 96.3% (129 samples); L7/60: 100.0% (166 samples); L7/63: 100.0% (166 samples); L8/354: 99.8% (31 samples); L8/359: 99.9% (32 samples); L8/362: 100.0% (32 samples); L8/363: 100.6% (32 samples); L8/364: 99.9% (32 samples); L8/365: 100.0% (32 samples); L8/366: 100.0% (32 samples); wait upper bounds: L5: 0.00%, L7: 5.60%, L8: 4.90% | every follower ≥ 95% of group median; ≥10 walking samples for each named follower; stationary >10m lag ≤10% of escort time | PASS |
| L3-02 cohorts | 15/15, 30/30, 50/50 | 15/15, 30/30, 50/50 | 15/30/50 actual members on low tier | PASS |
| L3-02 stream | 16.73 s scheduled; 15 admitted; 16.57 s scheduled; 30 admitted; 17.08 s scheduled; 50 admitted | — | every cohort admitted within its ≤18 s stream | PASS |
| L3-02 alarm frame | 5/15 | — | ≥25% of opening wave on screen within 2 s | PASS |
| L3-03 first attack | 2.95 s | — | ≤10 s | PASS |
| L4-07 first attack | 8.30 s | — | ≤10 s | PASS |
| L3-06 squad counts/losses | — | 4 → army s1:3/s2:0/s3:0 (2/3 ≤2); bite | 3–4 at fallback; ≤2 at army (seeds 1–3: ≥2 valid, ≥2 of them ≤2); every loss a bite/kill/separation | PASS |
| L3-11 native competent rate | — | 5.39/min; 22 damage; 0 deaths | 3–25 player attacks/min | PASS |
| L4-05 directions/groups | 6 edges; ≥60°: true; max group 5 | — | ≥3 edges ≥60° apart; groups ≤5 at each source | PASS |
| L4-06 first breach | 52.72 s level / +19.90 s alarm; 61 alive | — | level clock 30–60 s; ≥60 alive at first breach | PASS |
| L4-06 sustained horde | minimum 65; 8711 observations; line break 189.18 s | — | ≥40 living in authored plaza from alarm +45 s through line break | PASS |
| L6-03/04 | Breach cohorts: see L6 wave table | — | breach 1 ≥6; breach 2 ≥10 | See wave flags |
| L8-04 | 12/12 across 4 outlets [3, 3, 3, 3] | — | ≥3 outlets ≥20m apart, ≥6/3 each (high/low); no pop-in | LEDGER PASS; visual pending |
| G-22 | See announced-wave table below | Informational | first attack ≤ 20 s; several reachable infected at start | See wave flags |
| L9-03 | Not measured by this harness | Not measured | ≥ 1 group/wanderer in camera frame per 60 s, each route | NOT TESTED (harness gap) |

## L1

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/pickup — pickup: Pick up the package at the courier depot | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-38.79, -34.84) | — |
| phase/morning — controller: morning | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (64.53, -9.88) | — |
| step/deliver — deliver: Deliver the package to the Medical Annex | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/handover — controller: handover | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/calm — controller: calm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/accident — controller: accident | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.31, -9.54) | — |
| step/escape — escape: Get away from the facility | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 5/5 | 5/5 | (65.31, -9.54) | — |
| phase/spread — controller: spread | L1-08 | 25.09 player + 0.00 group/min; 12.67 s | 25.09 player + 0.00 group/min; 12.67 s | 24/24 | 24/24 | (-73.91, 40.46) | — |
| step/weapon — weapon: Find something to defend yourself | — | 18.65 player + 0.00 group/min; 12.65 s | 18.65 player + 0.00 group/min; 12.65 s | 20/20 | 20/20 | (23.26, 37.31) | — |
| step/firestation — firestation: Get inside the fire station | — | 29.33 player + 0.00 group/min; 0.42 s | 29.33 player + 0.00 group/min; 0.42 s | 24/24 | 24/24 | (-73.91, 40.46) | — |
| phase/run-out — level-end run-out | — | 144.00 player + 0.00 group/min; 1.13 s | 144.00 player + 0.00 group/min; 1.13 s | 28/28 | 28/28 | (-76.04, 41.15) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L2

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/calm — calm: Take the fire axe | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| step/axe — axe: Take the fire axe | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.20, 45.20) | — |
| phase/calm — controller: calm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| step/board — board: Get on the fire truck | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| phase/alarm — controller: alarm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-70.82, 41.50) | — |
| step/ride — ride: Ride with Engine 3 to Grove Market | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-42.84, -32.00) | — |
| phase/ride — controller: ride | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-42.84, -32.00) | — |
| step/doors — doors: Cover the firefighters while they force the doors | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| phase/arrived — controller: arrived | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| phase/doors — controller: doors | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| step/bridge — bridge: Reach the police checkpoint at the bridge | — | 177.02 player + 0.00 group/min; 3.28 s | 10.38 player + 0.00 group/min; 3.28 s | 0/4 | 0/27 | (81.40, 32.96) | — |
| phase/collapse — controller: collapse | L2-07 | 49.18 player + 0.00 group/min; 3.28 s | 32.47 player + 0.00 group/min; 3.28 s | 30/30 | 30/30 | (-65.50, -22.95) | — |
| phase/escape — controller: escape | L2-12 | 195.39 player + 0.00 group/min; 3.37 s | 7.01 player + 0.00 group/min; 3.07 s | 5/5 | 27/27 | (81.42, 37.84) | — |
| phase/checkpoint — controller: checkpoint | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/4 | 0/27 | (81.40, 32.96) | — |
| phase/run-out — level-end run-out | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/5 | 0/28 | (81.95, 32.30) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| market-ambush | l2.doorsOpen | 58.60 | 129.73 | 24 | 24 | — | 3.28 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/bridge`, `phase/checkpoint` at 150.52 s, 27/27 unreachable: `185@2` (12.48, -29.63); `191@5` (-57.58, -26.71); `201@10` (5.37, -4.30); `209@14` (-26.00, 4.33); `217@18` (-54.84, 37.51); `219@19` (-51.98, 14.70); `233@27` (-68.89, 2.96); `235@28` (-67.10, 14.46); `237@29` (-68.03, 15.21); `239@30` (-64.68, -4.16); `241@31` (-24.81, 48.63); `243@32` (-55.09, 30.42); `245@33` (-54.27, 28.31); `247@34` (-66.95, 18.10); `249@35` (33.55, -27.02); `251@36` (36.46, -28.36); `253@37` (39.15, -31.46); `255@38` (42.67, -32.91); `257@39` (-7.12, 48.03); `259@40` (81.28, 42.18); `261@41` (-33.74, -15.82); `263@42` (-34.41, 2.05); `265@43` (-28.97, 18.44); `267@44` (-11.50, 28.34); `269@45` (7.74, 26.23); `271@46` (26.46, 27.04); `275@48` (45.80, 29.70). Player (81.40, 32.96).
- `phase/run-out` at 155.12 s, 28/28 unreachable: `185@2` (14.12, -29.74); `191@5` (-51.82, -26.74); `201@10` (5.76, -2.14); `209@14` (-26.26, 9.63); `217@18` (-51.68, 34.25); `219@19` (-46.67, 14.45); `233@27` (-67.10, 4.04); `235@28` (-68.77, 14.92); `237@29` (-68.59, 13.75); `239@30` (-66.04, 1.27); `241@31` (-26.57, 49.06); `243@32` (-56.92, 31.55); `245@33` (-56.65, 33.25); `247@34` (-66.33, 20.95); `249@35` (36.86, -29.06); `251@36` (37.19, -30.64); `253@37` (39.96, -33.46); `255@38` (38.42, -30.40); `257@39` (-5.62, 48.58); `261@41` (-33.94, -14.42); `263@42` (-35.94, 3.47); `265@43` (-26.43, 17.04); `267@44` (-11.18, 26.48); `269@45` (6.27, 28.29); `271@46` (25.45, 26.63); `275@48` (46.15, 34.18); `297@59` (81.36, 39.56); `175@60` (5.89, -4.95). Player (81.95, 32.30).

## L3

Threat steps explicitly selected from the loaded mission definition:

- `defend` — Help defend the station (combat; L3-03).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/armory — armory: Take a handgun from the armory | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-139.91, -6.85) | — |
| phase/yard — controller: yard | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-134.95, 0.61) | — |
| step/defend — defend: Help defend the station | L3-03 | 149.56 player + 0.00 group/min; 2.95 s | 23.48 player + 0.00 group/min; 2.95 s | 32/32 | 24/24 | (-134.95, 0.61) | — |
| phase/attack — controller: attack | — | 149.56 player + 0.00 group/min; 2.95 s | 23.48 player + 0.00 group/min; 2.95 s | 32/32 | 24/24 | (-134.95, 0.61) | — |
| step/checkpoint — checkpoint: Get inside the army checkpoint | — | 943.04 player + 80.46 group/min; 0.12 s | 5.39 player + 6.16 group/min; 0.77 s | 77/77 | 0/36 | (-134.95, 0.61) | — |
| phase/fallback — controller: fallback | — | 943.04 player + 80.46 group/min; 0.12 s | 54.09 player + 78.13 group/min; 0.77 s | 77/77 | 11/11 | (-134.95, 0.61) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| station-0 | L3 scheduled wave.at (before admission) | 9.45 | 60.55 | 15 | 15 | — | 2.95 | — |
| station-1 | L3 scheduled wave.at (before admission) | 29.45 | 40.55 | 30 | 30 | — | 2.97 | — |
| station-2 | L3 scheduled wave.at (before admission) | 49.45 | 20.55 | 50 | 50 | — | 4.47 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/checkpoint`, `phase/corridor` at 188.98 s, 36/36 unreachable: `2192@1018` (143.76, 1.62); `2194@1019` (192.57, 0.56); `2196@1020` (149.91, 3.02); `2198@1021` (183.77, 2.45); `2200@1022` (152.23, 2.11); `2362@1096` (196.10, -2.76); `2464@1142` (152.88, 1.73); `2466@1143` (170.63, -0.58); `2468@1144` (153.91, 1.04); `2470@1145` (179.88, 0.95); `2472@1146` (132.22, 3.74); `2636@1220` (194.71, -1.52); `2770@1281` (196.76, -3.07); `2772@1282` (192.32, 1.22); `2774@1283` (193.72, -0.25); `2776@1284` (193.16, 0.16); `2778@1285` (195.43, -2.99); `2940@1358` (185.60, 3.05); `2942@1359` (188.50, 1.78); `2944@1360` (188.07, 2.51); `2946@1361` (184.90, 2.89); `2948@1362` (186.88, 2.80); `3110@1435` (169.93, -0.66); `3112@1436` (172.47, -0.79); `3114@1437` (173.55, -0.56); `3116@1438` (175.95, -0.34); `3118@1439` (175.20, -0.54); `3224@1486` (76.64, 3.60); `3226@1487` (79.50, 24.00); `3228@1488` (59.22, 24.00); `3230@1489` (71.89, 32.00); `3232@1490` (69.38, 24.00); `3234@1491` (91.46, 32.00); `3236@1492` (91.57, 24.00); `3238@1493` (110.72, 24.00); `3240@1494` (108.67, 32.00). Player (224.99, 0.20).
- `phase/done` at 190.97 s, 36/36 unreachable: `2192@1018` (148.38, 2.90); `2194@1019` (197.37, -3.24); `2196@1020` (155.84, -0.06); `2198@1021` (189.62, 2.47); `2200@1022` (157.94, -1.47); `2464@1142` (158.58, -1.87); `2466@1143` (177.31, -0.06); `2468@1144` (159.64, -2.50); `2470@1145` (186.22, 2.98); `2472@1146` (128.21, 4.11); `2772@1282` (196.73, -2.98); `2776@1284` (198.05, -3.05); `2940@1358` (189.35, 1.37); `2942@1359` (191.84, -1.03); `2944@1360` (192.86, 0.59); `2946@1361` (190.38, 0.93); `2948@1362` (191.39, -1.88); `3110@1435` (176.64, -0.17); `3112@1436` (179.04, 0.63); `3114@1437` (180.05, 1.02); `3116@1438` (182.30, 1.88); `3118@1439` (181.58, 1.59); `3280@1512` (167.34, -0.94); `3282@1513` (169.32, -0.23); `3284@1514` (164.84, -2.65); `3286@1515` (165.73, -1.30); `3288@1516` (166.54, -1.10); `3314@1527` (76.64, 3.60); `3316@1528` (91.46, 32.00); `3318@1529` (71.89, 32.00); `3320@1530` (79.50, 24.00); `3322@1531` (100.61, 32.00); `3324@1532` (110.72, 24.00); `3326@1533` (118.73, 32.00); `3328@1534` (118.74, 24.00); `3330@1535` (91.57, 24.00). Player (224.99, 0.20).

## L4

Threat steps explicitly selected from the loaded mission definition:

- `hold` — Hold the plaza with the army (combat; L4-07).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/ride — ride: Ride into Fairhaven with the convoy | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| phase/convoy — controller: convoy | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/quartermaster — quartermaster: Report to the quartermaster | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| phase/plaza — controller: plaza | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/hold — hold: Hold the plaza with the army | L4-07 | 1000.11 player + 0.00 group/min; 8.30 s | 152.21 player + 0.00 group/min; 8.93 s | 80/80 | 75/80 | (-22.85, 0.74) | — |
| phase/war — controller: war | — | 1000.11 player + 0.00 group/min; 8.30 s | 152.21 player + 0.00 group/min; 8.93 s | 80/80 | 75/80 | (-22.85, 0.74) | — |
| step/hide — hide: Run to the cellar via Lakeshore, Metro Road and Harbor Street | — | 726.54 player + 0.00 group/min; 0.03 s | 40.39 player + 0.00 group/min; 1.48 s | 67/67 | 79/80 | (-3.80, 26.60) | — |
| phase/collapse — controller: collapse | — | 726.54 player + 0.00 group/min; 0.03 s | 40.39 player + 0.00 group/min; 1.48 s | 67/67 | 79/80 | (-3.80, 26.60) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| war-0@1969 | l4.wave | 32.82 | 215.68 | 24 | 24 | — | 8.37 | — |
| war-1@2629 | l4.wave | 43.82 | 204.68 | 36 | 36 | — | 8.33 | — |
| breach-west | L4 breach.openAt | 52.72 | 195.78 | — | 103 | — | 8.27 | — |
| war-2@3289 | l4.wave | 54.82 | 193.68 | 48 | 28 | — | 133.82 | — |
| war-3@3949 | l4.wave | 65.82 | 182.68 | 54 | 9 | — | 130.73 | — |
| war--1@4009 | l4.wave | 66.82 | 181.68 | 15 | 2 | — | 155.22 | — |
| war-4@4609 | l4.wave | 76.82 | 171.68 | 54 | 0 | — | — | — |
| war-5@5269 | l4.wave | 87.82 | 160.68 | 54 | 0 | — | — | — |
| war-6@5929 | l4.wave | 98.82 | 149.68 | 54 | 0 | — | — | — |
| war-7@6589 | l4.wave | 109.82 | 138.68 | 54 | 0 | — | — | — |
| war-8@7249 | l4.wave | 120.82 | 127.68 | 54 | 0 | — | — | — |
| war-9@7909 | l4.wave | 131.82 | 116.68 | 54 | 0 | — | — | — |
| breach-north | L4 breach.openAt | 138.07 | 110.43 | — | 27 | — | 7.70 | — |
| war-10@8569 | l4.wave | 142.82 | 105.68 | 54 | 0 | — | — | — |
| war-11@9229 | l4.wave | 153.82 | 94.68 | 54 | 0 | — | — | — |
| war-12@9889 | l4.wave | 164.82 | 83.68 | 54 | 0 | — | — | — |
| breach-south | L4 breach.openAt | 168.22 | 80.28 | — | 6 | — | 6.63 | — |
| war-13@10549 | l4.wave | 175.82 | 72.68 | 54 | 0 | — | — | — |
| war-14@11209 | l4.wave | 186.82 | 61.68 | 54 | 0 | — | — | — |
| opening-alarm | L4 opening pending street cohorts | 32.82 | 215.68 | — | 0 | — | — | — |
| war-15@11869 | l4.wave | 197.82 | 50.68 | 54 | 0 | — | — | — |
| war-16@12529 | l4.wave | 208.82 | 39.68 | 54 | 0 | — | — | — |
| war-17@13189 | l4.wave | 219.82 | 28.68 | 54 | 0 | — | — | — |
| collapse-0@13609 | l4.wave | 226.82 | 21.68 | 6 | 0 | — | — | — |
| collapse-1@14149 | l4.wave | 235.82 | 12.68 | 6 | 0 | — | — | — |
| collapse-2@14689 | l4.wave | 244.82 | 3.68 | 6 | 0 | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/hold`, `phase/war` at 220.82 s, 5/80 unreachable: `319@144` (-27.75, -12.23); `374@197` (-15.17, 41.69); `441@260` (-16.85, 18.92); `474@286` (-19.66, -15.58); `483@294` (-17.45, -18.81). Player (-9.41, -5.75).
- `step/hide`, `phase/collapse` at 362.82 s, 1/80 unreachable: `319@144` (-27.75, -10.76). Player (-76.88, -40.88).
- `step/bar` at 363.95 s, 80/80 unreachable: `236@67` (-17.14, 6.71); `237@68` (-42.44, -15.73); `240@71` (-23.56, -8.36); `319@144` (-27.75, -10.76); `350@174` (-39.49, -23.18); `358@181` (-47.86, -23.99); `360@183` (-40.83, -15.70); `374@197` (-6.40, 41.76); `378@200` (-48.72, -23.78); `387@209` (-42.62, -20.24); `389@211` (-42.84, -23.48); `393@214` (-46.04, -23.99); `402@223` (-49.30, -23.10); `406@226` (-54.66, -24.23); `411@231` (-41.42, -21.32); `415@235` (-45.12, -23.94); `416@236` (-47.48, -22.16); `417@237` (-56.02, -23.22); `418@238` (-42.99, -21.06); `424@243` (-43.15, -21.94); `426@245` (-49.60, -23.99); `434@253` (-41.90, -17.17); `435@254` (-41.17, -22.19); `436@255` (-45.93, -23.08); `437@256` (-15.26, -15.32); `439@258` (-13.29, -16.78); `441@260` (-31.85, -19.75); `442@261` (-42.28, -21.63); `443@262` (-51.31, -23.47); `444@263` (-51.69, -22.59); `447@266` (-18.67, -5.59); `448@267` (-24.40, -7.97); `450@269` (-46.95, -23.93); `454@273` (-42.68, -14.85); `460@278` (-43.55, -23.99); `461@279` (-42.50, -12.68); `462@280` (-36.15, -18.83); `466@284` (-42.58, -22.63); `474@286` (-42.07, -8.53); `483@294` (-19.83, -4.87); `494@305` (-39.48, -16.77); `500@310` (-43.56, -22.90); `505@315` (-42.19, -18.05); `510@320` (-47.42, -23.14); `511@321` (-53.77, -23.99); `518@328` (-36.09, -13.41); `519@329` (-48.30, -22.86); `521@330` (-55.15, -22.25); `522@331` (-34.11, -17.53); `526@335` (-39.74, -15.53); `527@336` (17.41, -28.09); `528@337` (-46.31, -22.24); `529@338` (-45.40, -22.14); `530@339` (-34.84, -8.93); `533@340` (-44.31, -23.50); `535@341` (-50.51, -23.92); `536@342` (-45.03, -22.96); `537@343` (-44.26, -22.30); `538@344` (-42.31, -11.75); `539@345` (-41.73, -22.91); `540@346` (-56.57, -22.24); `541@347` (-50.78, -22.72); `542@348` (-41.47, -16.36); `544@350` (-41.70, -20.24); `557@351` (-49.02, -22.23); `569@352` (46.65, -1.32); `570@353` (16.35, -29.41); `574@354` (-49.94, -22.15); `587@355` (2.95, 2.41); `588@356` (-41.98, -23.79); `591@357` (35.14, 52.36); `592@358` (44.78, 32.74); `593@359` (53.86, 0.10); `594@360` (50.54, -10.87); `595@361` (49.54, 51.19); `596@362` (55.60, 48.60); `597@363` (59.34, 49.30); `598@364` (16.98, -30.08); `599@365` (16.50, -27.99); `600@366` (-29.91, -17.22). Player (75.30, -6.40).
- `phase/cellar`, `step/wait` at 371.12 s, 80/80 unreachable: `236@67` (-18.97, 6.40); `237@68` (-42.45, -16.14); `240@71` (-23.66, -8.36); `319@144` (-27.75, -10.76); `350@174` (-40.01, -27.06); `358@181` (-50.99, -23.99); `360@183` (-41.06, -15.92); `374@197` (-6.40, 41.76); `378@200` (-52.01, -23.99); `385@207` (-36.70, -19.13); `387@209` (-42.87, -20.50); `389@211` (-43.64, -23.78); `393@214` (-50.06, -23.99); `402@223` (-45.67, -21.89); `406@226` (-67.96, -38.10); `411@231` (-24.80, -19.52); `415@235` (-44.98, -23.15); `416@236` (-48.41, -21.89); `417@237` (-57.08, -23.23); `418@238` (-25.61, -19.62); `424@243` (-40.50, -20.78); `426@245` (-53.35, -23.01); `434@253` (-42.00, -17.49); `435@254` (-40.94, -22.62); `436@255` (-45.55, -23.87); `437@256` (-15.26, -15.32); `439@258` (-13.32, -16.80); `441@260` (-31.44, -19.03); `442@261` (-41.89, -22.70); `443@262` (-62.17, -34.60); `444@263` (-53.01, -22.12); `447@266` (-18.69, -5.61); `448@267` (-24.50, -7.98); `450@269` (-45.81, -22.79); `454@273` (-42.70, -15.26); `460@278` (-49.14, -23.99); `461@279` (-42.53, -13.12); `462@280` (-35.70, -21.61); `466@284` (-42.81, -23.39); `474@286` (-42.07, -8.53); `483@294` (-19.83, -4.87); `494@305` (-39.80, -16.82); `500@310` (-26.50, -19.65); `505@315` (-42.24, -18.38); `510@320` (-44.75, -21.89); `511@321` (-66.72, -38.26); `518@328` (-37.16, -16.58); `519@329` (-49.36, -21.97); `521@330` (-56.36, -22.25); `522@331` (-38.07, -16.65); `526@335` (-39.54, -9.66); `527@336` (17.77, -24.24); `528@337` (-47.49, -21.89); `529@338` (-46.58, -21.89); `530@339` (-27.49, -8.34); `533@340` (-44.54, -23.99); `535@341` (-53.40, -24.03); `536@342` (-44.10, -22.99); `537@343` (-43.84, -21.89); `538@344` (-42.37, -12.20); `539@345` (-42.00, -23.82); `540@346` (-57.98, -22.24); `541@347` (-62.13, -33.01); `542@348` (-41.63, -16.65); `544@350` (-43.27, -22.60); `557@351` (-61.18, -34.10); `569@352` (52.53, -4.72); `570@353` (18.48, -26.58); `574@354` (-51.65, -22.08); `587@355` (5.18, -1.17); `588@356` (-50.23, -23.09); `591@357` (34.85, 48.28); `592@358` (45.88, 33.04); `593@359` (50.59, -5.91); `594@360` (53.82, -14.63); `595@361` (49.64, 46.06); `596@362` (62.73, 44.75); `597@363` (66.81, 46.97); `598@364` (17.80, -27.21); `600@366` (-22.62, -18.64). Player (74.65, -2.13).
- `phase/done` at 372.12 s, 80/80 unreachable: `236@67` (-19.01, 6.38); `237@68` (-42.45, -16.14); `240@71` (-23.66, -8.36); `319@144` (-27.75, -10.76); `350@174` (-39.53, -28.46); `358@181` (-50.99, -23.99); `360@183` (-41.06, -15.92); `374@197` (-6.40, 41.76); `378@200` (-52.01, -23.99); `385@207` (-37.28, -17.86); `387@209` (-42.87, -20.50); `389@211` (-43.45, -23.84); `393@214` (-50.06, -23.99); `402@223` (-45.73, -21.89); `406@226` (-66.79, -37.39); `411@231` (-24.80, -19.29); `415@235` (-45.21, -23.62); `416@236` (-48.49, -21.89); `417@237` (-57.08, -23.23); `418@238` (-25.34, -20.03); `424@243` (-40.50, -20.78); `426@245` (-53.35, -23.01); `434@253` (-42.00, -17.49); `435@254` (-40.94, -22.62); `436@255` (-46.05, -23.99); `437@256` (-15.26, -15.32); `439@258` (-13.32, -16.80); `441@260` (-31.44, -19.03); `442@261` (-41.89, -22.70); `443@262` (-61.52, -33.77); `444@263` (-53.01, -22.12); `447@266` (-18.69, -5.61); `448@267` (-24.50, -7.98); `450@269` (-45.02, -22.74); `454@273` (-42.70, -15.26); `460@278` (-49.13, -23.99); `461@279` (-42.53, -13.12); `462@280` (-35.98, -21.52); `466@284` (-42.69, -23.32); `474@286` (-42.07, -8.53); `483@294` (-19.83, -4.87); `494@305` (-39.80, -16.82); `500@310` (-26.06, -19.45); `505@315` (-42.24, -18.38); `510@320` (-44.74, -21.89); `511@321` (-65.83, -37.46); `518@328` (-37.44, -17.17); `519@329` (-49.40, -21.97); `521@330` (-56.36, -22.25); `522@331` (-37.53, -15.82); `526@335` (-39.02, -9.91); `527@336` (17.46, -23.63); `528@337` (-47.57, -21.89); `529@338` (-46.65, -21.89); `530@339` (-26.46, -8.27); `533@340` (-44.37, -23.99); `535@341` (-53.40, -24.03); `536@342` (-44.22, -23.12); `537@343` (-43.82, -21.89); `538@344` (-42.37, -12.20); `539@345` (-41.94, -23.86); `540@346` (-57.98, -22.24); `541@347` (-61.51, -32.12); `542@348` (-41.63, -16.65); `544@350` (-43.39, -22.73); `557@351` (-60.49, -33.20); `569@352` (52.58, -4.75); `570@353` (18.46, -26.85); `574@354` (-51.65, -22.08); `587@355` (5.84, 0.13); `588@356` (-48.88, -23.09); `591@357` (34.84, 48.20); `592@358` (46.23, 34.37); `593@359` (50.40, -5.60); `594@360` (53.84, -14.63); `595@361` (49.37, 44.86); `596@362` (62.73, 44.75); `597@363` (66.81, 46.97); `598@364` (17.60, -26.34); `600@366` (-22.16, -19.50). Player (74.65, -2.13).

## L5

Threat steps explicitly selected from the loaded mission definition:

- `look` — Look for anyone still alive (combat; L5-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/emerge — emerge: Unbar the cellar door | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/100 | 0/100 | (75.30, -5.39) | — |
| phase/cellar — controller: cellar | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/100 | 0/100 | (74.66, -1.77) | — |
| phase/emerged — controller: emerged | — | 138.00 player + 0.00 group/min; 2.78 s | 72.00 player + 0.00 group/min; 2.78 s | 100/100 | 100/100 | (-79.30, -44.28) | — |
| step/look — look: Look for anyone still alive | L5-05 | 599.87 player + 0.86 group/min; 0.18 s | 4.38 player + 0.00 group/min; 12.15 s | 100/100 | 45/45 | (37.61, -49.28) | — |
| phase/search — controller: search | — | 599.87 player + 0.86 group/min; 0.18 s | 4.38 player + 0.00 group/min; 12.15 s | 100/100 | 45/45 | (37.61, -49.28) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/emerge` at 0.02 s, 100/100 unreachable: `84@3` (-20.00, -37.60); `86@4` (-17.50, -36.10); `88@5` (-22.00, 10.00); `90@1` (46.00, 36.00); `91@6` (22.00, -37.40); `93@7` (-26.00, 40.00); `95@8` (-23.50, 41.50); `97@2` (-42.00, -41.50); `98@9` (2.00, 43.60); `100@10` (14.00, -2.00); `102@11` (-12.00, 18.00); `104@12` (44.00, -36.40); `106@13` (46.50, -34.90); `108@14` (-6.00, -37.40); `110@15` (10.00, 13.00); `112@16` (-46.00, -37.50); `114@17` (36.00, -37.40); `116@18` (-12.00, 43.60); `118@19` (14.00, -24.00); `120@20` (-60.00, 43.00); `122@21` (-4.00, 28.00); `124@22` (-40.00, -20.00); `126@23` (-8.90, 2.60); `128@24` (0.10, 2.60); `130@25` (53.50, 41.30); `132@26` (62.50, 41.30); `134@27` (-29.00, -2.70); `136@28` (-25.87, -44.40); `138@29` (-49.50, 50.00); `140@30` (-40.50, 50.00); `142@31` (68.00, -37.40); `144@32` (48.00, -12.00); `146@33` (40.00, 43.60); `148@34` (16.00, -12.00); `150@35` (4.00, -37.40); `152@36` (0.00, -12.00); `154@37` (-4.00, 14.00); `156@38` (-16.00, -12.00); `158@39` (-28.00, -37.40); `160@40` (-32.00, -12.00); `162@41` (-36.00, 14.00); `164@42` (-60.00, -37.40); `166@43` (-72.00, 43.60); `168@44` (64.00, 2.00); `170@45` (60.00, 28.00); `172@46` (48.00, 2.00); `174@47` (4.00, -24.00); `176@48` (-16.00, 2.00); `178@49` (-32.00, 2.00); `180@50` (-36.00, 28.00); `182@51` (56.00, -37.40); `184@52` (52.00, -12.00); `186@53` (48.00, 14.00); `188@54` (12.00, 43.60); `190@55` (8.00, -37.40); `192@56` (0.00, 14.00); `194@57` (-28.00, -12.00); `196@58` (-36.00, 43.60); `198@59` (-52.00, 43.60); `200@60` (-56.00, -37.40); `202@61` (-68.00, 43.60); `204@62` (64.00, 28.00); `206@63` (52.00, 2.00); `208@64` (48.00, 28.00); `210@65` (-16.00, 28.00); `212@66` (-28.00, 2.00); `214@67` (-32.00, 28.00); `216@68` (60.00, -37.40); `218@69` (52.00, 14.00); `220@70` (48.00, 43.60); `222@71` (32.00, 43.60); `224@72` (16.00, 43.60); `226@73` (12.00, -37.40); `228@74` (-8.00, -12.00); `230@75` (-24.00, -12.00); `232@76` (-40.00, -12.00); `234@77` (-48.00, 43.60); `236@78` (68.00, 28.00); `238@79` (56.00, 2.00); `240@80` (52.00, 28.00); `242@81` (-12.00, 28.00); `244@82` (-20.00, -24.00); `246@83` (-24.00, 2.00); `248@84` (-28.00, 28.00); `250@85` (68.00, 43.60); `252@86` (64.00, -37.40); `254@87` (36.00, 43.60); `256@88` (12.00, -12.00); `258@89` (-4.00, -12.00); `260@90` (-20.00, -12.00); `262@91` (-32.00, -37.40); `264@92` (-36.00, -12.00); `266@93` (-40.00, 14.00); `268@94` (-44.00, 43.60); `270@95` (-64.00, -37.40); `272@96` (-76.00, 43.60); `274@97` (60.00, 2.00); `276@98` (56.00, 28.00); `278@99` (48.00, -24.00); `280@100` (0.00, -24.00). Player (75.30, -5.39).
- `phase/cellar` at 1.00 s, 100/100 unreachable: `84@3` (-20.00, -37.60); `86@4` (-17.67, -36.22); `88@5` (-21.80, 9.90); `90@1` (46.00, 36.00); `91@6` (21.60, -37.20); `93@7` (-26.00, 40.00); `95@8` (-23.44, 41.39); `97@2` (-42.00, -41.50); `98@9` (2.30, 43.54); `100@10` (13.84, -2.29); `102@11` (-12.00, 17.98); `104@12` (43.89, -36.54); `106@13` (46.58, -35.10); `108@14` (-5.73, -37.26); `110@15` (10.01, 12.98); `112@16` (-46.14, -37.48); `114@17` (35.78, -37.29); `116@18` (-12.03, 43.62); `118@19` (13.92, -24.32); `120@20` (-60.11, 43.08); `122@21` (-4.05, 27.91); `124@22` (-40.01, -19.77); `126@23` (-8.90, 2.85); `128@24` (0.09, 2.55); `130@25` (53.22, 41.29); `132@26` (62.48, 41.30); `134@27` (-28.91, -2.70); `136@28` (-25.87, -44.40); `138@29` (-49.58, 49.96); `140@30` (-40.21, 49.83); `142@31` (68.43, -37.61); `144@32` (48.04, -11.61); `146@33` (39.95, 43.61); `148@34` (15.91, -12.28); `150@35` (4.00, -37.41); `152@36` (0.00, -12.04); `154@37` (-4.11, 14.00); `156@38` (-16.00, -11.80); `158@39` (-28.26, -37.27); `160@40` (-31.99, -11.99); `162@41` (-36.04, 14.18); `164@42` (-60.24, -37.41); `166@43` (-72.00, 43.60); `168@44` (64.08, 1.86); `170@45` (59.57, 28.24); `172@46` (48.09, 2.29); `174@47` (3.98, -23.99); `176@48` (-16.00, 2.00); `178@49` (-31.93, 2.07); `180@50` (-35.88, 27.98); `182@51` (55.92, -37.37); `184@52` (51.99, -11.99); `186@53` (48.37, 14.33); `188@54` (12.04, 43.79); `190@55` (8.00, -37.40); `192@56` (-0.01, 13.99); `194@57` (-27.96, -11.99); `196@58` (-35.96, 43.65); `198@59` (-52.03, 43.61); `200@60` (-56.15, -37.44); `202@61` (-68.14, 44.00); `204@62` (64.00, 28.00); `206@63` (51.80, 1.64); `208@64` (48.03, 27.99); `210@65` (-15.97, 28.00); `212@66` (-27.91, 1.81); `214@67` (-32.05, 28.01); `216@68` (60.19, -37.67); `218@69` (52.00, 14.03); `220@70` (48.45, 43.83); `222@71` (31.84, 43.72); `224@72` (15.72, 43.70); `226@73` (12.01, -37.38); `228@74` (-7.98, -11.89); `230@75` (-24.00, -12.00); `232@76` (-40.00, -12.00); `234@77` (-48.00, 43.60); `236@78` (67.97, 28.00); `238@79` (55.97, 1.98); `240@80` (51.92, 28.21); `242@81` (-12.00, 28.00); `244@82` (-20.14, -23.71); `246@83` (-23.66, 1.67); `248@84` (-28.06, 27.95); `250@85` (67.96, 43.71); `252@86` (64.11, -37.40); `254@87` (35.77, 43.72); `256@88` (12.20, -12.18); `258@89` (-3.69, -11.67); `260@90` (-20.03, -11.87); `262@91` (-31.69, -37.47); `264@92` (-36.00, -12.06); `266@93` (-39.85, 13.67); `268@94` (-44.00, 43.60); `270@95` (-64.14, -37.45); `272@96` (-76.17, 43.98); `274@97` (59.72, 1.84); `276@98` (55.97, 28.01); `278@99` (47.96, -24.07); `280@100` (-0.31, -23.83). Player (74.66, -1.77).
- `step/metro`, `phase/shelter` at 192.37 s, 37/37 unreachable: `90@104` (50.28, 39.61); `91@105` (11.26, -35.42); `93@106` (-25.36, 55.12); `97@108` (-41.70, -42.18); `98@109` (10.91, 42.15); `108@114` (-3.95, -41.09); `110@115` (-1.78, 2.28); `118@119` (13.11, -29.67); `120@120` (-63.68, 47.44); `128@124` (-15.51, 5.27); `132@126` (51.03, 44.72); `138@129` (-57.38, 46.25); `142@131` (80.47, -38.04); `146@133` (39.88, 46.90); `148@134` (15.49, -26.82); `150@135` (11.17, -42.88); `158@139` (-32.14, -38.88); `166@143` (-67.13, 45.14); `170@145` (52.61, 41.02); `172@146` (48.04, 4.34); `174@147` (-1.31, -15.55); `188@154` (33.74, 53.50); `190@155` (0.52, -38.79); `198@159` (-57.13, 41.93); `202@161` (-61.14, 47.28); `204@162` (51.29, 30.83); `220@170` (49.17, 45.92); `222@171` (28.39, 49.46); `226@173` (17.80, -28.51); `234@177` (-58.50, 48.36); `236@178` (71.94, 30.06); `240@180` (51.29, 21.93); `250@185` (62.77, 41.56); `252@186` (65.83, -39.31); `256@188` (11.11, -0.83); `272@196` (-66.71, 44.33); `280@200` (-3.96, -13.61). Player (38.28, -50.54).
- `phase/done` at 193.37 s, 38/38 unreachable: `90@104` (50.28, 39.61); `91@105` (11.26, -34.65); `93@106` (-25.36, 55.12); `97@108` (-41.70, -42.18); `98@109` (11.31, 41.02); `108@114` (-4.92, -40.33); `110@115` (-1.79, 2.33); `118@119` (13.66, -30.59); `120@120` (-62.67, 47.41); `128@124` (-16.45, 4.37); `132@126` (51.05, 44.67); `138@129` (-56.38, 45.82); `142@131` (80.47, -38.04); `146@133` (40.84, 47.87); `148@134` (15.04, -28.00); `150@135` (10.09, -42.23); `158@139` (-32.98, -38.07); `166@143` (-68.47, 45.24); `170@145` (51.60, 40.14); `172@146` (48.04, 4.34); `174@147` (-1.31, -15.55); `184@152` (50.97, -14.16); `188@154` (33.66, 53.74); `190@155` (1.54, -39.05); `198@159` (-57.01, 40.76); `202@161` (-61.08, 47.25); `204@162` (51.65, 29.88); `220@170` (48.89, 44.62); `222@171` (28.80, 48.46); `226@173` (18.02, -28.87); `234@177` (-58.50, 48.36); `236@178` (71.94, 30.06); `240@180` (52.41, 22.07); `250@185` (63.05, 42.54); `252@186` (64.80, -39.05); `256@188` (10.46, -0.58); `272@196` (-67.94, 44.41); `280@200` (-3.96, -13.61). Player (38.28, -50.54).

## L6

Threat steps explicitly selected from the loaded mission definition:

- `stop` — Stop the infected (combat; L6-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/shelter — shelter: Look around the shelter | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (0.33, 3.56) | — |
| phase/shelter — controller: shelter | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (0.33, 3.56) | — |
| step/stop — stop: Stop the infected | L6-05 | 265.50 player + 88.50 group/min; 5.77 s | 0.00 player + 28.07 group/min; — s | 20/20 | 8/8 | (0.33, 3.56) | — |
| phase/first — controller: first | — | 265.50 player + 88.50 group/min; 5.77 s | 0.00 player + 11.42 group/min; — s | 20/20 | 4/4 | (0.33, 3.56) | — |
| step/retreat — retreat: Cover the retreat through the tunnel | — | 848.64 player + 168.87 group/min; 0.05 s | 24.13 player + 51.05 group/min; 23.85 s | 30/30 | 20/20 | (0.33, 3.56) | — |
| phase/retreat — controller: retreat | — | 848.64 player + 168.87 group/min; 0.05 s | 24.13 player + 51.05 group/min; 23.85 s | 30/30 | 20/20 | (0.33, 3.56) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| l6.breach1 | l6.breach1 | 33.20 | 76.80 | 8 | 8 | — | 5.77 | — |
| l6.breach2 | l6.breach2 | 54.22 | 55.78 | 10 | 10 | — | 9.73 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L7

Threat steps explicitly selected from the loaded mission definition:

- `corridor` — Bring the group to the evacuation corridor (combat; L7-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/rocket — rocket: Recover the rocket launcher beside the exit | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 98/98 | (273.01, 15.00) | — |
| phase/pickup — controller: pickup | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 98/98 | (273.01, 15.00) | — |
| step/corridor — corridor: Bring the group to the evacuation corridor | L7-05 | 160.87 player + 25.36 group/min; 0.80 s | 7.40 player + 0.00 group/min; 0.58 s | 96/96 | 59/59 | (-20.97, 47.84) | — |
| phase/encounters — controller: encounters | — | 182.00 player + 22.27 group/min; 0.80 s | 6.39 player + 0.00 group/min; 0.58 s | 98/98 | 1/1 | (-57.88, 47.26) | — |
| step/departure — departure: Get everyone aboard the bus | — | 190.40 player + 0.00 group/min; 0.07 s | 0.00 player + 0.00 group/min; — s | 98/98 | 0/0 | (35.94, 47.00) | — |
| phase/departing — controller: departing | — | 6.67 player + 0.00 group/min; 3.58 s | 0.00 player + 0.00 group/min; — s | 98/98 | 0/0 | (35.94, 47.00) | — |
| phase/done — controller: done | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 99/99 | 0/0 | (40.00, 47.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L8

Threat steps explicitly selected from the loaded mission definition:

- `escape` — Bring the survivors to the armored vehicle and board (breach combat; L8-06).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/escape — escape: Bring the survivors to the armored vehicle and board | L8-06 | 244.19 player + 8.23 group/min; 63.82 s | 1.91 player + 0.00 group/min; 61.97 s | 83/83 | 78/78 | (94.07, 77.20) | — |
| phase/sanctuary — controller: sanctuary | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (23.14, 64.15) | — |
| phase/breached — controller: breached | — | 430.63 player + 14.51 group/min; 3.82 s | 5.24 player + 0.00 group/min; 1.97 s | 83/83 | 78/78 | (94.07, 77.20) | — |
| step/depart — depart: Wait for everyone to board the armored vehicle | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 81/81 | 78/78 | (96.00, 74.00) | — |
| phase/boarding — controller: boarding | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 81/81 | 79/79 | (96.00, 74.00) | — |
| phase/run-out — level-end run-out | — | 24.00 player + 0.00 group/min; 2.65 s | — | 82/82 | — | (96.00, 74.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| tunnel-breach | L8 breachedAt/story.say | 60.00 | 84.58 | 12 | 12 | 3, 3, 3, 3 | 3.82 | — |
| tunnel-reinforcement@4200 | L8 nextWave clock | 70.00 | 74.58 | 16 | 16 | — | 2.98 | — |
| tunnel-reinforcement@4440 | L8 nextWave clock | 74.00 | 70.58 | 16 | 16 | — | 4.08 | — |
| tunnel-reinforcement@4680 | L8 nextWave clock | 78.00 | 66.58 | 16 | 16 | — | 2.92 | — |
| tunnel-reinforcement@4920 | L8 nextWave clock | 82.00 | 62.58 | 16 | 16 | — | 2.87 | — |
| tunnel-reinforcement@5160 | L8 nextWave clock | 86.00 | 58.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5400 | L8 nextWave clock | 90.00 | 54.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5640 | L8 nextWave clock | 94.00 | 50.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5880 | L8 nextWave clock | 98.00 | 46.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6120 | L8 nextWave clock | 102.00 | 42.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6360 | L8 nextWave clock | 106.00 | 38.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6600 | L8 nextWave clock | 110.00 | 34.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6840 | L8 nextWave clock | 114.00 | 30.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7080 | L8 nextWave clock | 118.00 | 26.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7320 | L8 nextWave clock | 122.00 | 22.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7560 | L8 nextWave clock | 126.00 | 18.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7800 | L8 nextWave clock | 130.00 | 14.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8040 | L8 nextWave clock | 134.00 | 10.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8280 | L8 nextWave clock | 138.00 | 6.58 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8520 | L8 nextWave clock | 142.00 | 2.58 | 16 | 0 | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L9

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/approach — approach: Drive toward the city | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (466.34, 3.29) | — |
| phase/driving — controller: driving | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (466.34, 3.29) | — |
| phase/approach — controller: approach | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 4/4 | 4/4 | (494.74, 1.14) | — |
| phase/fall — controller: fall | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (508.00, 0.00) | — |
| step/reach-outskirts — reach-outskirts: Get clear of the wreck | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (540.50, 0.87) | — |
| phase/impact — controller: impact | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (527.50, 2.60) | — |
| phase/crawl — controller: crawl | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (540.50, 0.87) | — |
| phase/done — controller: done | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (547.00, 0.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L10

Threat steps explicitly selected from the loaded mission definition:

- `hold` — Charge the dispersal system (assault combat; L10-11).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/crash — crash: Leave the wreck on foot | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/residential-fringe — residential-fringe: Recover the handgun at the checkpoint | — | 156.52 player + 0.00 group/min; 5.32 s | 8.24 player + 0.00 group/min; 5.32 s | 7/7 | 5/5 | (763.90, 25.00) | — |
| step/industrial-area — industrial-area: Recover the shotgun at the checkpoint | — | 382.65 player + 0.00 group/min; 0.18 s | 7.68 player + 0.00 group/min; 28.43 s | 18/19 | 7/8 | (1253.25, 25.00) | — |
| step/military-zone — military-zone: Recover the machine gun at the checkpoint | — | 528.85 player + 0.00 group/min; 0.10 s | 8.36 player + 0.00 group/min; 36.52 s | 33/34 | 4/5 | (1849.67, 25.01) | — |
| step/research-campus — research-campus: Reach the research campus | — | 304.24 player + 0.00 group/min; 0.13 s | 11.82 player + 0.00 group/min; 12.08 s | 7/8 | 4/5 | (2461.00, -5.14) | — |
| step/research — research: Play the research recording | — | 338.87 player + 0.00 group/min; 2.67 s | 45.14 player + 0.00 group/min; 9.75 s | 54/55 | 29/30 | (2703.11, 41.37) | — |
| step/cure — cure: Pack the cure canister | — | 585.00 player + 0.00 group/min; 0.02 s | 0.00 player + 0.00 group/min; — s | 54/55 | 15/16 | (2705.13, 41.31) | — |
| step/research-exit — research-exit: Get the cure out of the laboratory | — | 860.45 player + 0.00 group/min; 0.02 s | 0.00 player + 0.00 group/min; — s | 52/53 | 0/1 | (2800.42, 44.74) | — |
| step/destroyed-corridor — destroyed-corridor: Carry the cure down the corridor and grab the rocket launcher | — | 934.52 player + 0.00 group/min; 0.07 s | 21.36 player + 0.00 group/min; 9.50 s | 54/55 | 18/19 | (2930.18, -4.99) | — |
| step/dispersal-complex — dispersal-complex: Bring the cure to the dispersal complex | — | 215.19 player + 0.00 group/min; 0.18 s | 5.54 player + 0.00 group/min; 43.53 s | 8/8 | 1/1 | (3691.37, -24.93) | — |
| step/install — install: Install the cure in the dispersal device | — | 243.61 player + 0.00 group/min; 0.90 s | 7.16 player + 0.00 group/min; 8.60 s | 19/20 | 0/1 | (4002.51, -37.12) | — |
| step/hold — hold: Charge the dispersal system | L10-11 | 1091.17 player + 0.00 group/min; 0.10 s | 70.23 player + 0.00 group/min; 6.77 s | 95/95 | 36/36 | (4002.79, -28.73) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| dispersal-assault | L10 charge-active (not first spawn) | 1002.72 | 59.98 | — | 75 | — | 4.65 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/industrial-area` at 190.28 s, 1/8 unreachable: `119@17` (1029.80, 80.00). Player (1252.90, 25.00).
- `step/military-zone` at 355.02 s, 1/5 unreachable: `119@17` (1496.54, 100.00). Player (1850.05, 25.01).
- `step/research-campus` at 528.15 s, 1/5 unreachable: `119@17` (1948.72, -75.00). Player (2462.27, -5.11).
- `step/research` at 590.77 s, 1/30 unreachable: `119@17` (2175.55, -75.00). Player (2697.03, 41.56).
- `step/cure` at 592.57 s, 1/16 unreachable: `119@17` (2182.07, -75.00). Player (2705.13, 41.31).
- `step/research-exit` at 614.02 s, 1/1 unreachable: `119@17` (2259.77, -75.00). Player (2801.59, 44.79).
- `step/destroyed-corridor` at 652.78 s, 1/19 unreachable: `119@17` (2527.00, 24.05). Player (2929.14, -4.99).
- `step/dispersal-complex` at 786.12 s, 1/1 unreachable: `119@17` (3233.73, 70.51). Player (3432.02, 94.90).
- `step/install` at 944.57 s, 1/1 unreachable: `119@17` (3797.00, -36.30). Player (3999.20, -35.56).

## Every fail flag

- None.

## Flag-to-criterion mapping

| Flag | Acceptance criterion |
|---|---|

Absolute targets come from `docs/qa/level-acceptance.md`. L4 high-tier census supplements the low-tier passive contact/reachability run; its plaza uses the authored `l4.map.plaza` bounds. Both level and alarm clocks are reported; first breach must occur at level time 30–60 s with ≥60 alive. L3’s scheduled 18 s streams retain unspawned entries under the strict live cap (E21 §5.6); actual admissions within 18 s are shown separately, and the complete native route must produce every authored member. Armory visibility, actual squad attrition, competent damage and mortal input completion require the playtest report.

## Defect triage provenance

Historical failures and the original handoff are in `docs/reports/threat-calibrate/README.md`. They are baseline evidence, not current-run findings. Current failures are listed above with criterion mappings.

Run `npm run qa:threat -- --maxWorkers=2` for current JSON/Markdown receipts in `test-results/qa-threat/`. To refresh this baseline deliberately, add `--report docs/reports/threat-audit/README.md`. Remote: `sh tools/remote/run.sh "$PWD" --pull test-results/qa-threat -- npm run qa:threat -- --maxWorkers=2`. `npm run qa:threat -- --proof` proves the fail thresholds using deliberately broken fixtures without adding registered unit cases. `npm run qa:threat -- --passive-from test-results/qa-threat/audit.json` repeats the same policies without instrumentation and checks complete state hashes; add the same `--report` option to save proof with the baseline.
