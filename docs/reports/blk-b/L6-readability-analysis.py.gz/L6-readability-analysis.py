"""Evaluate lossless source-bound masks; close only the measured eye counterexample."""
from pathlib import Path
import gzip,hashlib,json,subprocess
import numpy as np
from PIL import Image,ImageFilter
root=Path('docs/reports/blk-b');base=Path('test-results/blk-b');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:np.asarray(Image.open(p).convert('RGB'))
def linear_luminance(rgb):
    a=rgb.astype(float)/255
    a=np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
    return (a*np.array([.2126,.7152,.0722])).sum(2)
def analyze(folder):
    path=base/folder;data=json.loads((path/'ledger.json').read_text())
    assert not data['errors'] and not data['state']['god'];assert data['state']['tier']==data['state']['renderTier']
    assert data['state']['flashlight'] and data['state']['emergency'] and not data['state']['mainPower']
    for c in data['captures']:assert sha(c['file'])==c['sha256']
    img=lambda name:read(path/f'captures/{name}.png')
    native=img('native');black=img('actor-black').astype(int)
    body=(img('actor-body').astype(int).sum(2)-black.sum(2))>10
    eyes=(img('actor-eyes').astype(int).sum(2)-black.sum(2))>10
    courier=img('courier-id');courier=(courier[:,:,0]>150)&(courier[:,:,1]<70)&(courier[:,:,2]>150)
    lum=linear_luminance(native);ring=[];ring_samples=[]
    for q in data['state']['ring']:
        x=round(q['screen']['x']);y=round(q['screen']['y']);patch=lum[y-3:y+4,x-3:x+4];keep=~(courier|body)[y-3:y+4,x-3:x+4]
        if patch.shape!=(7,7)or keep.sum()<25:continue
        ring.extend(patch[keep].tolist());ring_samples.append({'world':q['world'],'screen':q['screen'],'pixels':int(keep.sum()),'median':float(np.median(patch[keep]))})
    assert courier.sum()>100 and len(ring_samples)>32
    c90=float(np.percentile(lum[courier],90));bg=float(np.median(ring))
    result={'tier':data['state']['tier'],'spot':data['state']['spot'],'actor':data['state']['enemy']['id'],'model':data['state']['enemy']['appearance']['asset'],'bodyMaskPixels':int(body.sum()),'eyeMaskPixels':int(eyes.sum()),'courierMaskPixels':int(courier.sum()),'bodyP90':c90,'ringMedian':bg,'contrast02':(c90+.02)/(bg+.02),'contrast05':(c90+.05)/(bg+.05),'ringSamples':ring_samples,'sourceHash':data['sourceHash'],'captures':data['captures']}
    if eyes.sum() and body.sum()>100:
        assert not (eyes&~body).any(), 'eye pixels must belong to the actual actor body'
        dilated=np.asarray(Image.fromarray((eyes*255).astype('uint8')).filter(ImageFilter.MaxFilter(5)))>0
        non_eye=body&~dilated
        y,x=np.unravel_index(np.argmax(np.where(non_eye,lum,-1)),lum.shape)
        eye_max=float(lum[eyes].max());body_max=float(lum[y,x]);yy,xx=np.where(eyes)
        result.update(eyeMax=eye_max,bodyNonEyeMax=body_max,eyesBrightest=eye_max>=body_max,brightBodyPixel={'x':int(x),'y':int(y),'rgb':native[y,x].tolist(),'luminance':body_max,'nearestEyeDistancePixels':float(np.min(np.hypot(xx-x,yy-y)))},eyePixels=[{'x':int(ex),'y':int(ey),'rgb':native[ey,ex].tolist(),'luminance':float(lum[ey,ex])}for ey,ex in zip(yy,xx)])
        if (path/'captures/native-repeat.png').exists():
            repeat=img('native-repeat');changed=int(np.any(native[body]!=repeat[body],axis=1).sum());assert changed==0
            result['repeatedNativeBodyChangedPixels']=changed
    else:result['eyeVerdict']='NOT CHECKED: body/head occluded; no missing-eye failure inferred'
    archive=root/f'{folder}-ledger.json.gz';archive.write_bytes(gzip.compress((path/'ledger.json').read_bytes(),mtime=0));result['ledger']=str(archive);result['ledgerSha256']=sha(archive)
    return result

folders=['L6-readability-low-tunnel-62-repeat','L6-readability-high-tunnel-62-repeat']
values=[analyze(f)for f in folders]
Path('test-results/blk-b/readability-analysis.json').write_text(json.dumps(values,indent=2))
print([(r.get('eyesBrightest'),r.get('eyeMax'),r.get('bodyNonEyeMax'),r['contrast02'])for r in values])
