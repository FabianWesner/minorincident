# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/levels/L5.spec.ts >> L5 Aftermath in the browser >> T-E23-17 @E23 @E23-AC17 @E23-AC18 real-input playthrough: unbar the door, find the five by their signs of life, lead them to the Metro; photo spots; 0 console errors
- Location: tests/e2e/levels/L5.spec.ts:172:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('survivors-found')
Expected substring: "Survivors in"
Received string:    " · Survivors found 5/5"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByTestId('survivors-found') with timeout 5000ms
  - waiting for getByTestId('survivors-found')
    14 × locator resolved to <span hidden="" data-testid="survivors-found"> · Survivors found 5/5</span>
       - unexpected value " · Survivors found 5/5"

```

```yaml
- text: ➜
- status: "That is everyone. The metro station: it has a shutter, and it has a light."
- button "Pause": Ⅱ
- button "Home"
- text: Dale
- meter "survivor-health-dale": 60/60
- text: Rosa
- meter "survivor-health-rosa": 60/60
- text: Mr. Okafor
- meter "survivor-health-okafor": 60/60
- text: Mia
- meter "survivor-health-mia": 60/60
- text: Sam
- meter "survivor-health-sam": 60/60
- text: 1 2 3 4 5
- meter "health": 100 / 100
- 'button "Active weapon: Machine gun, Ready"'
- text: Corgi · following N ▲ ⌂
- status: ≋ Fog
- text: Lead the survivors down into the Metro · Survivors in 0/5 · 66 m
```

# Test source

```ts
  109 |     for (let i = 0; i < 2400; i++) {
  110 |       await step(4);
  111 |       // Stop when the group has crossed and closure begins, preserving the photograph window.
  112 |       if (enterMetro && (await mission()).l5!.shutterAt) return;
  113 |       const p = (await player()).transform;
  114 |       if (Math.hypot(target.x - p.x, target.z - p.z) <= stop) return;
  115 |       const lag = await page.evaluate(() => { const a = window.__SS__!, p = a.getState().player!.transform; return a.query({ kind: 'civilian' }).some(e => e.civilian?.survivor && !e.hidden && e.health.current > 0 && Math.hypot(e.transform.x - p.x, e.transform.z - p.z) > 6); });
  116 |       // Keep guarding the followers; a nine-second fighting hiatus exceeds their grab/turn window.
  117 |       if ((await player()).health.current > 0 && await fightNearby(Math.max(18, range))) {
  118 |         // Attacking stops movement. Keep guarding a lagging group instead of
  119 |         // reissuing the route while its followers are pinned in cover.
  120 |         if (!lag) await click();
  121 |       }
  122 |       else if (lag && lagWait < 300) { await page.keyboard.down('w'); await step(1); await page.keyboard.up('w'); await step(12); lagWait += 12; await click(); }
  123 |       else {
  124 |         if (!lag) lagWait = 0;
  125 |         // An ordinary destination click persists while navigation builds and follows its route.
  126 |         // Re-click only after the command is consumed/cancelled (including a respawn):
  127 |         // unconditional retries restart the long Sam-to-Mia flood before the corner is cleared.
  128 |         if (i % 4 === 3 && !await page.evaluate(() => window.__SS__!.getState().controls?.moveTarget)) await click();
  129 |       }
  130 |     }
  131 |     const diagnostic = await page.evaluate(() => {
  132 |       const a = window.__SS__!, s = a.getState();
  133 |       return { tick: s.tick, player: s.player, controls: s.controls, input: s.input, pick: a.input.lastPick(),
  134 |         survivors: a.missions.state()?.l5?.survivors, infected: a.query({ kind: 'infected' }).filter(e => e.health.current > 0) };
  135 |     });
  136 |     writeFileSync(`${output}/travel-progress.json`, JSON.stringify({ target, ...diagnostic }, null, 1));
  137 |     await page.screenshot({ path: `${output}/travel-progress.png` });
  138 | 
  139 |     throw new Error(`Could not travel to ${JSON.stringify(target)} from ${JSON.stringify((await player()).transform)}`);
  140 |   };
  141 |   const interact = async () => { await page.keyboard.down('e'); await step(3); await page.keyboard.up('e'); await step(2); };
  142 |   /** Wait (looking after the group) until every living follower is within 8 m, at most `maxS` seconds. */
  143 |   const regroup = async (maxS = 9) => {
  144 |     const until = await page.evaluate(() => window.__SS__!.getState().tick) + maxS * 60;
  145 |     while (await page.evaluate(() => window.__SS__!.getState().tick) < until) {
  146 |       const far = await page.evaluate(() => {
  147 |         const a = window.__SS__!, p = a.getState().player!.transform, m = a.missions.state()!.l5!;
  148 |         return m.survivors.filter(r => r.status === 'following').some(r => { const e = a.getState().entities.find(x => x.id === r.id); return !e || Math.hypot(e.transform.x - p.x, e.transform.z - p.z) > 6.5; });
  149 |       });
  150 |       if (!far) return; await fightNearby(18); await step(4);
  151 |     }
  152 |   };
  153 |   return { step, mission, player, snap, shots, go, fightNearby, interact, regroup };
  154 | }
  155 | const begin = async (page: Page, level = 'L5', progression: string | undefined = 'L5-default') => {
  156 |   await boot(page, `${testUrl}&ui=1`);
  157 |   await page.evaluate(({ level, progression }) => window.__SS__!.loadLevel(level, { seed: 1, ...(progression ? { progression: progression as 'L5-default' } : {}) }), { level, progression });
  158 |   await page.evaluate(() => window.__SS__!.pause());
  159 |   // Pause in the same event turn as the real button click, before wall-clock scheduling adds sim ticks.
  160 |   await page.evaluate(() => {
  161 |     const button = [...document.querySelectorAll('button')].find(b => b.textContent === 'Begin mission')!;
  162 |     button.addEventListener('click', () => queueMicrotask(() => window.__SS__!.pause()), { once: true });
  163 |   });
  164 |   await page.getByRole('button', { name: 'Begin mission' }).click();
  165 |   await page.evaluate(() => window.__SS__!.pause());
  166 |   // Begin starts streamed scene preparation. Settle the interaction geometry
  167 |   // before paused input runs advance the escort faster than asset loading.
  168 |   await page.evaluate(() => window.__SS__!.screenshotReady());
  169 | };
  170 | 
  171 | test.describe('L5 Aftermath in the browser', () => {
  172 |   test('T-E23-17 @E23 @E23-AC17 @E23-AC18 real-input playthrough: unbar the door, find the five by their signs of life, lead them to the Metro; photo spots; 0 console errors', async ({ page }) => {
  173 |     test.setTimeout(2_400_000); page.setDefaultTimeout(120_000); mkdirSync(output, { recursive: true });
  174 |     const errors: string[] = []; page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); }); page.on('pageerror', e => errors.push(String(e)));
  175 |     await begin(page);
  176 |     const h = helpers(page), { step, mission, player, snap, go, interact, fightNearby, regroup } = h;
  177 |     // The cellar: the courier starts in the walled yard (the L4 end loadout in hand), the door is barred.
  178 |     expect((await player()).weapons!.RIGHT.rack.map(r => r.id)).toEqual(['weapon.army-mg', 'weapon.handgun', 'weapon.kick']);
  179 |     await expect(page.getByTestId('survivors-found')).toBeHidden();
  180 |     await go(brace(), .4);
  181 |     for (let i = 0; i < 14 && (await mission()).l5!.phase === 'cellar'; i++) { await interact(); await step(20); }
  182 |     expect((await mission()).l5!.phase).toBe('emerged');
  183 |     // Silence, then the objective; every pair camera and the exit.
  184 |     await snap('l5-basement-exit'); await step(60 * 11);
  185 |     expect((await mission()).l5!.phase).toBe('search');
  186 |     await expect(page.getByTestId('survivors-found')).toContainText('0/5');
  187 |     await page.keyboard.down('Alt');
  188 |     for (const name of ['pair-kessler-lane', 'pair-plaza', 'pair-harbor-street', 'pair-metro-entrance']) await snap(name);
  189 |     // The search: the cheapest tour of the five hiding places; each sign of life is heard (cue event) before the survivor is found.
  190 |     const heard = new Set<string>(); let signShot = false;
  191 |     await page.evaluate(() => { (window as unknown as { __cues: string[] }).__cues = []; });
  192 |     for (const key of ['rosa', 'sam', 'mia', 'okafor', 'dale']) {
  193 |       const target = ring(key);
  194 |       if (!signShot && key === 'sam') {
  195 |         // Stay outside the stand-to-interact ring until this bus's sign is captured.
  196 |         await go({ x: target.x + 10, z: target.z - 4 }, 1.2, 11);
  197 |         const fresh = () => page.evaluate(() => { const a = window.__SS__!; return a.events().some(e => e.type === 'l5.cue' && e.key === 'sam' && e.tick >= a.getState().tick - 60); });
  198 |         for (let wait = 0; wait < 24 && !await fresh(); wait++) if (!await fightNearby(18)) await step(20);
  199 |         expect(await fresh(), 'Sam sign of life at his bus').toBe(true);
  200 |         await snap('l5-sign-of-life'); signShot = true;
  201 |       }
  202 |       await go({ x: target.x, z: target.z }, 1.6, 11);
  203 |       for (let guard = 0; guard < 40 && await fightNearby(18); guard++) { /* clear nearby threats before opening the hiding place */ }
  204 |       const cues = await page.evaluate(() => window.__SS__!.events().filter(e => e.type === 'l5.cue').map(e => (e as { key: string }).key));
  205 |       for (const c of cues) heard.add(c);
  206 |       for (let i = 0; i < 12 && !(await mission()).l5!.survivors.find(r => r.key === key && r.status !== 'hidden'); i++) { await interact(); await step(20); }
  207 |       expect((await mission()).l5!.survivors.find(r => r.key === key)!.status, key).not.toBe('hidden');
  208 |       const found = (await mission()).l5!.found;
> 209 |       await expect(page.getByTestId('survivors-found')).toContainText(found === 5 ? 'Survivors in' : `${found}/5`);
      |                                                         ^ Error: expect(locator).toContainText(expected) failed
  210 |       for (let guard = 0; guard < 40 && await fightNearby(18); guard++) { /* protect the newly found survivor */ }
  211 |       await regroup();
  212 |       writeFileSync(`${output}/real-input-after-${key}.json`, JSON.stringify(await mission(), null, 1));
  213 |     }
  214 |     expect((await mission()).l5!.found).toBe(5); expect([...heard].sort()).toEqual(['dale', 'mia', 'okafor', 'rosa', 'sam']);
  215 |     // Protect all five through the group photo, then enter the Metro: the group photo, then the shutter.
  216 |     expect((await mission()).steps.metro.status).toBe('active');
  217 |     // Approach from the west, keeping the entrance trigger out of the route until after the photo.
  218 |     await go({ x: -20, z: -37.6 }, 1.6, 11);
  219 |     await go({ x: 10, z: -37.6 }, 1.6, 11);
  220 |     await go({ x: 10, z: -42.4 }, 1.6, 11); await regroup(); await step(30); await snap('l5-group-of-five');
  221 |     expect((await mission()).l5!.survivors.filter(r => r.status === 'following')).toHaveLength(5);
  222 |     await go(metroFoot(), .4, 11);
  223 |     let last = await mission();
  224 |     for (let i = 0; i < 80 && last.phase === 'playing'; i++) {
  225 |       if (last.l5!.shutterAt) {
  226 |         const remaining = last.l5!.shutterAt + 120 - await page.evaluate(() => window.__SS__!.getState().tick);
  227 |         if (remaining > 0) await step(remaining);
  228 |         last = await mission(); await snap('l5-metro-shelter'); await snap('l5-metro-doors'); break;
  229 |       }
  230 |       if (!await fightNearby(11)) await step(15);
  231 |       last = await mission();
  232 |     }
  233 |     if (!h.shots.has('l5-metro-shelter')) await snap('l5-metro-shelter');
  234 |     if (!h.shots.has('l5-metro-doors')) await snap('l5-metro-doors');
  235 |     if (!last.l5!.shutterAt) last = await mission();
  236 |     for (let i = 0; i < 60 && !await page.evaluate(() => { const a = window.__SS__!; return a.getState().scenario === 'L6' || a.missions.state()?.phase === 'progression'; }); i++) {
  237 |       // The photograph loop can finish before a crowded ingress does. Keep using
  238 |       // the same real covering fire until the shutter closes, rather than stand
  239 |       // idle for thirty seconds while the last living followers cross.
  240 |       const arrival = (await mission()).l5!;
  241 |       if (!arrival.shutterAt) {
  242 |         // Rescuing a grabber can take the protector back up the stairs. Re-enter
  243 |         // with the same ground-click inputs so the living group's ingress resumes.
  244 |         if (!arrival.metroAt) { await go(metroFoot(), .4, 11); continue; }
  245 |         if (await fightNearby(18)) continue;
  246 |       }
  247 |       await step(30);
  248 |     }
  249 |     const finished = await mission();
  250 |     if (finished.id === 'L5') expect(finished.phase, 'paused sim must finish before waiting for streamed navigation').toBe('progression');
  251 |     await expect.poll(() => page.evaluate(() => window.__SS__!.getState().scenario), { timeout: 120_000 }).toBe('L6');
  252 |     const handover = await page.evaluate(() => ({ level: window.__SS__!.getState().scenario, survivors: window.__SS__!.campaign.state()!.survivors }));
  253 |     expect(handover.level).toBe('L6'); expect(handover.survivors!.slice().sort()).toEqual(l5Survivors.map(s => s.key).sort());
  254 |     writeFileSync(`${output}/browser-real-input.json`, JSON.stringify({ statsAtShutter: last.stats, handover, l5: { survivors: last.l5!.survivors.map(r => `${r.key}:${r.status}`), gloom: last.l5!.gloom, shutterAt: last.l5!.shutterAt }, shots: [...h.shots].sort(), errors }, null, 1));
  255 |     expect([...h.shots].sort()).toEqual(['l5-basement-exit', 'l5-group-of-five', 'l5-metro-doors', 'l5-metro-shelter', 'l5-sign-of-life', 'pair-harbor-street', 'pair-kessler-lane', 'pair-metro-entrance', 'pair-plaza']);
  256 |     expect(last.l5!.survivors.filter(r => r.status === 'sheltered').length).toBeGreaterThanOrEqual(3);
  257 |     expect(errors).toEqual([]);
  258 |   });
  259 | 
  260 |   test('T-E23-18 @E23 @E23-AC18 recognition: the four pair cameras in L4 (W0, intact) and L5 (W5, fallen) from the real game, side by side', async ({ page }) => {
  261 |     test.setTimeout(900_000); page.setDefaultTimeout(120_000); mkdirSync(output, { recursive: true });
  262 |     const names = ['pair-plaza', 'pair-harbor-street', 'pair-metro-entrance', 'pair-kessler-lane'], anchors: Record<string, P> = { 'pair-plaza': { x: -17, z: 3 }, 'pair-harbor-street': { x: -10, z: -39 }, 'pair-metro-entrance': { x: 37.8, z: -44.2 }, 'pair-kessler-lane': { x: 68, z: 28.6 } };
  263 |     const shoot = async (level: 'W0' | 'W5') => {
  264 |       const out: Record<string, Buffer> = {};
  265 |       for (const name of names) {
  266 |         // The courier stands at the anchor: the see-through fade keeps the buildings between her and the camera open, as in play.
  267 |         await page.evaluate(({ name, level, at }) => { const a = window.__SS__!; a.teleport(a.query({ kind: 'player' })[0].id, { x: at.x, z: at.z }); a.camera.preset(`D-FAIR/${level}/${name}`); }, { name, level, at: anchors[name] });
  268 |         await page.evaluate(() => window.__SS__!.step(8)); await page.evaluate(() => window.__SS__!.screenshotReady());
  269 |         out[name] = await page.screenshot();
  270 |       }
  271 |       return out;
  272 |     };
  273 |     await begin(page, 'L4', 'L4-default');
  274 |     await page.evaluate(() => { const a = window.__SS__!; a.cheats.god(true); a.cheats.completeObjective('ride'); });
  275 |     await page.evaluate(() => window.__SS__!.step(90));
  276 |     const safe = await shoot('W0');
  277 |     await begin(page);
  278 |     await page.evaluate(() => { const a = window.__SS__!; a.cheats.god(true); a.cheats.completeObjective('emerge'); });
  279 |     await page.evaluate(() => window.__SS__!.step(60 * 12));
  280 |     const fallen = await shoot('W5');
  281 |     const width = 800;
  282 |     const scaled = (png: PNG) => { const h = Math.round(png.height * width / png.width), out = new PNG({ width, height: h }); for (let y = 0; y < h; y++) for (let x = 0; x < width; x++) { const sx = Math.min(png.width - 1, Math.floor(x * png.width / width)), sy = Math.min(png.height - 1, Math.floor(y * png.height / h)), i = (y * width + x) * 4, j = (sy * png.width + sx) * 4; for (let k = 0; k < 4; k++) out.data[i + k] = png.data[j + k]; } return out; };
  283 |     const report: Record<string, number> = {};
  284 |     for (const name of names) {
  285 |       const a = PNG.sync.read(safe[name]), b = PNG.sync.read(fallen[name]), left = scaled(a), right = scaled(b), sheet = new PNG({ width: width * 2 + 4, height: left.height });
  286 |       sheet.data.fill(255); PNG.bitblt(left, sheet, 0, 0, width, left.height, 0, 0); PNG.bitblt(right, sheet, 0, 0, width, right.height, width + 4, 0);
  287 |       writeFileSync(`${output}/recognition-${name}.png`, PNG.sync.write(sheet));
  288 |       let differ = 0; for (let i = 0; i < a.data.length; i += 4) if (Math.abs(a.data[i] - b.data[i]) + Math.abs(a.data[i + 1] - b.data[i + 1]) + Math.abs(a.data[i + 2] - b.data[i + 2]) > 60) differ++;
  289 |       report[name] = differ / (a.data.length / 4);
  290 |       expect(report[name], `${name}: L5 must look clearly different from L4`).toBeGreaterThan(.3);
  291 |     }
  292 |     writeFileSync(`${output}/recognition.json`, JSON.stringify(report, null, 1));
  293 |   });
  294 | 
  295 |   test('T-E23-15b @E23 @E23-AC15 handover: the barred L4 cellar door loads L5 (L4 end loadout, no reward screen); the Metro shutter loads L6 with the rescued survivors in the campaign', async ({ page }) => {
  296 |     test.setTimeout(900_000); page.setDefaultTimeout(120_000);
  297 |     await begin(page, 'L4', 'L4-default');
  298 |     let carried: { LEFT: string[]; RIGHT: string[] } = { LEFT: [], RIGHT: [] };
  299 |     for (let i = 0; i < 12; i++) {
  300 |       const m = await page.evaluate(() => window.__SS__!.missions.state());
  301 |       if (!m || m.phase !== 'playing' || (await page.evaluate(() => window.__SS__!.getState().scenario)) !== 'L4') break;
  302 |       carried = await page.evaluate(() => { const w = window.__SS__!.getState().player!.weapons!; return { LEFT: w.LEFT.rack.map(r => r.id), RIGHT: w.RIGHT.rack.map(r => r.id) }; });
  303 |       if (m.l4?.phase === 'cellar' && m.l4.barredAt && !Object.values(m.steps).some(s => s.status === 'active')) {
  304 |         // Completing the wait objective does not skip the authored battle above the cellar.
  305 |         await page.evaluate(ticks => window.__SS__!.step(ticks), l4.cellar.battleAfterBarredS * 60);
  306 |       } else await page.evaluate(() => window.__SS__!.cheats.completeObjective());
  307 |       if (await page.evaluate(() => window.__SS__!.missions.state()?.phase === 'playing' && window.__SS__!.getState().scenario === 'L4')) await page.evaluate(() => window.__SS__!.step(2));
  308 |     }
  309 |     // Automatic campaign navigation streams the next district after the completion event.
```