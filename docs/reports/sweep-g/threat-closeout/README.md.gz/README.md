# Threat calibration

Runtime main: `4f2b75e42e69fd213de28e0701d8c7a04d4972d7`; harness base: `d6945beba8e279996e878593305b5806db9386e3`. Runtime source matches main: **false**. Seed 1, skilled and passive native routes, **low** population set before mission preparation. Sequential simulation only; 342.19 seconds, budget 600 seconds. Result: **0 acceptance fail flags**.

[Raw audit receipts](audit.json).

## Measurement contract

Every active mission step is measured, including simultaneous objectives and instant completions; controller phases have separate rows. These overlapping views must not be summed. L1 combat starts in controller `spread`, after the instantaneous escape milestone. L2 ambush combat starts in controller `collapse`, after the doors open; the earlier door-forcing objective is retained without a combat tag. Duration is actual active fixed ticks (cinematics/results excluded). Spawn counts count successful spawns and civilian conversions, with a fresh generation for each reused pool record; “at start” is the first-tick living population. Observed/path/contact counts are unique generations seen during that phase. Contact means ever within 2.5 m of the moving player. Attacks and first-attack times count targeted attack telegraphs (including interrupted windups), physical civilian grabs and synchronous escort strikes. Support roars, screams and revives are excluded; resolved hits are never counted again. Player and following-party targets have separate counters.

Path queries use an independent copy of the native infected AI grid, with identical walls, mask, live blockers and radius rules; the Mega uses its native pursuit grid. Live resumable searches are never advanced by the audit. Queries run every two simulated seconds and on phase changes. All active living infected count in the denominator, including hidden/pending arrivals; pending admission is unreachable until admitted. Contact requires visible admission. A threat phase fails if >30% remain unreachable for >20 seconds across consecutive samples. Evidence records positions and the player position at that time. Later recovery does not erase a flag. The table also gives the last measured reachable/alive snapshot.

Followers include civilian survivor groups, allied followers, escorts and the companion (never the courier). Each follower’s median uses moving samples plus stationary samples while lagging behind a moving leader. The group min/median compare those individual medians. Leader walking/stationary time uses resolved position changes, never a stale requested velocity. Parked formation shuffling, incapacitated actors and cinematic locks do not count as walking. G-13 flags any follower below 0.95× the group median; the moving native route also measures all stationary courier ticks with any active follower >10 m away, including combat stands, as a conservative upper bound on the ≤10% waiting-share criterion. Raw per-follower values/sample counts are retained in JSON. A pace median needs ten walking samples (five seconds at 2 Hz); the named L5/L7/L8 followers must each have that coverage in the moving native route, so a stationary passive route cannot produce a false PASS. A dash means no walking sample, not zero speed.

Announced waves use native clocks/events and actual cohort ledgers. G-22 is measured by a cohort member making a real attack windup against the player within 20 s; the baseline 10 s proximity heuristic was removed. Only explicit threat announcements and first breach cohorts are gating; recurring reinforcement clocks without an acceptance threshold remain informational. Reachability is judged on the passive snapshot. The skilled route also gates zero windups in every inventoried combat phase, L2 bridge ≥2/min, L5 search ≥3/min, L10 hold ≥8/min and L6 mortal damage ≥30 HP. Passive caps are 70 s for L3, 250 s for L4, 110 s for L6, and 60 s of the L10 hold. A `tick-budget` passive outcome means the window cap ended the native route, not that the measured window is missing.

## Run coverage

| Level | Skilled outcome | Skilled sim s | Passive outcome / furthest step | Passive sim s | Phase rows | Announced waves | Wall seconds | Flags |
|---|---|---:|---:|---:|---:|---:|
| L1 | complete | 115.08 | complete / firestation | 115.08 | 11 | 0 | 9.55 | 0 |
| L2 | complete | 141.87 | complete / bridge | 167.43 | 15 | 1 | 17.50 | 0 |
| L3 | complete | 274.10 | tick-budget / checkpoint | 70.00 | 6 | 3 | 22.68 | 0 |
| L4 | complete | 309.50 | tick-budget / hide | 248.50 | 8 | 26 | 118.15 | 0 |
| L5 | complete | 204.47 | mission-failed / look | 1200.00 | 5 | 0 | 79.37 | 0 |
| L6 | complete | 279.58 | tick-budget / retreat | 110.00 | 7 | 2 | 6.69 | 0 |
| L7 | complete | 103.07 | complete / bus-departure | 102.20 | 7 | 0 | 17.31 | 0 |
| L8 | complete | 100.38 | tick-budget / escape | 150.00 | 3 | 22 | 22.00 | 0 |
| L9 | complete | 128.13 | complete / reach-outskirts | 128.13 | 8 | 0 | 12.04 | 0 |
| L10 | complete | 1168.53 | tick-budget / hold | 1062.03 | 12 | 1 | 36.86 | 0 |

## Acceptance criteria matrix

| Criterion | Passive measured | Skilled measured | Expected | Verdict |
|---|---:|---:|---|---|
| L1-08 | 28.04 | — | ≥ 3/min | PASS |
| L2-07 | 53.80 (12.27 s) | — | ≥ 4/min | SHORT WINDOW |
| L2-07 reach | 100.00% | — | ≥ 90% | PASS |
| L2-12 | — | 12.27 | ≥ 2 and ≤ 20/min | PASS |
| L3-03 | 89.20 | — | ≥ 4/min | PASS |
| L3-03 reach | 100.00% | — | ≥ 90% | PASS |
| L4-07 | 970.11 | — | ≥ 6/min | PASS |
| L4-07 reach | 100.00% | — | ≥ 90% | PASS |
| L5-05 | 533.68 + 0.45 group | — | ≥ 3/min | PASS |
| L6-05 | 411.67 | — | ≥ 4/min | PASS |
| L6-05 reach | 100.00% | — | ≥ 95% | PASS |
| L6-06 | 100.00% | — | ≥ 95% | PASS |
| L7-05 | 19.88 + 23.56 group | — | ≥ 6/min | PASS |
| L8-06 | 278.80 + 9.20 group | — | ≥ 4/min | PASS |
| L10-11 | 844.62 | — | ≥ 8/min | PASS |
| G-13 | none | L5/28: 100.0% (43 samples); L5/31: 100.8% (127 samples); L7/60: 100.0% (169 samples); L7/63: 100.0% (169 samples); L8/354: 99.8% (31 samples); L8/359: 99.9% (32 samples); L8/362: 100.0% (32 samples); L8/363: 100.6% (32 samples); L8/364: 99.9% (32 samples); L8/365: 100.0% (32 samples); L8/366: 100.0% (32 samples); wait upper bounds: L5: 3.61%, L7: 0.83%, L8: 4.90% | every follower ≥ 95% of group median; ≥10 walking samples for each named follower; stationary >10m lag ≤10% of escort time | PASS |
| L3-02 cohorts | 15/15, 30/30, 50/50 | 15/15, 30/30, 50/50 | 15/30/50 actual members on low tier | PASS |
| L3-02 stream | 16.73 s scheduled; 15 admitted; 16.57 s scheduled; 30 admitted; 17.08 s scheduled; 50 admitted | — | every cohort admitted within its ≤18 s stream | PASS |
| L3-02 alarm frame | 5/15 | — | ≥25% of opening wave on screen within 2 s | PASS |
| L3-03 first attack | 3.92 s | — | ≤10 s | PASS |
| L4-07 first attack | 9.33 s | — | ≤10 s | PASS |
| L3-06 squad counts/losses | — | 4 → 1; bite, bite, bite | 3–4 at fallback; ≤2 at army; every loss a bite/kill/separation | PASS |
| L3-11 native competent rate | — | 20.17/min; 189.66666666666595 damage; 1 deaths | 3–25 player attacks/min | PASS |
| L4-05 directions/groups | 6 edges; ≥60°: true; max group 5 | — | ≥3 edges ≥60° apart; groups ≤5 at each source | PASS |
| L4-06 first breach | 52.72 s level / +19.90 s alarm; 65 alive | — | level clock 30–60 s; ≥60 alive at first breach | PASS |
| L4-06 sustained horde | minimum 69; 8760 observations; line break 190.00 s | — | ≥40 living in authored plaza from alarm +45 s through line break | PASS |
| L6-03/04 | Breach cohorts: see L6 wave table | — | breach 1 ≥6; breach 2 ≥10 | See wave flags |
| L8-04 | 12/12 across 4 outlets [3, 3, 3, 3] | — | ≥3 outlets ≥20m apart, ≥6/3 each (high/low); no pop-in | LEDGER PASS; visual pending |
| G-22 | See announced-wave table below | Informational | first attack ≤ 20 s; several reachable infected at start | See wave flags |
| L9-03 | Not measured by this harness | Not measured | ≥ 1 group/wanderer in camera frame per 60 s, each route | NOT TESTED (harness gap) |

## L1

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/pickup — pickup: Pick up the package at the courier depot | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-38.79, -34.84) | — |
| phase/morning — controller: morning | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (64.53, -9.88) | — |
| step/deliver — deliver: Deliver the package to the Medical Annex | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/handover — controller: handover | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/calm — controller: calm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.63, -11.61) | — |
| phase/accident — controller: accident | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (65.31, -9.54) | — |
| step/escape — escape: Get away from the facility | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 5/5 | 5/5 | (65.31, -9.54) | — |
| phase/spread — controller: spread | L1-08 | 28.04 player + 0.00 group/min; 12.12 s | 28.04 player + 0.00 group/min; 12.12 s | 27/27 | 27/27 | (-73.91, 40.46) | — |
| step/weapon — weapon: Find something to defend yourself | — | 26.11 player + 0.00 group/min; 12.10 s | 26.11 player + 0.00 group/min; 12.10 s | 20/20 | 20/20 | (23.26, 37.31) | — |
| step/firestation — firestation: Get inside the fire station | — | 29.33 player + 0.00 group/min; 0.72 s | 29.33 player + 0.00 group/min; 0.72 s | 27/27 | 27/27 | (-73.91, 40.46) | — |
| phase/run-out — level-end run-out | — | 192.00 player + 0.00 group/min; 0.15 s | 192.00 player + 0.00 group/min; 0.15 s | 29/29 | 29/29 | (-76.04, 41.15) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L2

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/calm — calm: Take the fire axe | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| step/axe — axe: Take the fire axe | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.20, 45.20) | — |
| phase/calm — controller: calm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| step/board — board: Get on the fire truck | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-73.98, 47.08) | — |
| phase/alarm — controller: alarm | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-70.82, 41.50) | — |
| step/ride — ride: Ride with Engine 3 to Grove Market | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-42.84, -32.00) | — |
| phase/ride — controller: ride | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-42.84, -32.00) | — |
| step/doors — doors: Cover the firefighters while they force the doors | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| phase/arrived — controller: arrived | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| phase/doors — controller: doors | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-45.97, -36.77) | — |
| step/bridge — bridge: Reach the police checkpoint at the bridge | — | 138.38 player + 0.00 group/min; 3.28 s | 12.27 player + 0.00 group/min; 3.28 s | 0/7 | 0/30 | (81.40, 32.95) | — |
| phase/collapse — controller: collapse | L2-07 | 53.80 player + 0.00 group/min; 3.28 s | 32.35 player + 0.00 group/min; 3.28 s | 30/30 | 30/30 | (-65.49, -23.23) | — |
| phase/escape — controller: escape | L2-12 | 153.25 player + 0.00 group/min; 2.35 s | 8.61 player + 0.00 group/min; 2.78 s | 7/8 | 30/30 | (81.42, 37.77) | — |
| phase/checkpoint — controller: checkpoint | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/7 | 0/30 | (81.40, 32.95) | — |
| phase/done — controller: done | — | 0.00 player + 0.00 group/min; — s | — | 0/7 | — | (81.40, 32.95) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| market-ambush | l2.doorsOpen | 58.60 | 108.83 | 24 | 24 | — | 3.28 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/bridge`, `phase/checkpoint` at 136.27 s, 30/30 unreachable: `185@2` (-25.98, -24.94); `191@5` (-63.76, -12.01); `195@7` (-52.86, -32.15); `235@28` (-64.62, 3.27); `241@31` (-65.71, 24.14); `243@32` (-65.27, 26.03); `245@33` (-64.18, 21.97); `247@34` (-63.72, 28.61); `249@35` (41.17, -28.47); `251@36` (44.46, -30.44); `253@37` (42.67, -29.10); `255@38` (41.38, -31.10); `261@41` (-32.01, -13.73); `263@42` (-33.74, 2.35); `265@43` (-27.23, 18.52); `267@44` (-13.80, 27.69); `269@45` (6.58, 28.73); `271@46` (25.31, 26.68); `273@47` (71.62, 29.60); `275@48` (72.50, 29.86); `277@49` (74.01, 30.31); `279@50` (70.59, 29.85); `281@51` (72.01, 28.77); `283@52` (50.42, 39.15); `285@53` (73.12, 30.54); `287@54` (74.10, 29.40); `289@55` (51.96, 35.41); `291@56` (74.99, 29.16); `293@57` (72.91, 46.48); `295@58` (71.09, 28.77). Player (81.40, 32.95).
- `phase/run-out` at 140.87 s, 30/30 unreachable: `185@2` (-26.11, -20.50); `191@5` (-65.73, -5.13); `195@7` (-47.76, -29.80); `199@9` (-70.84, -33.82); `217@18` (-64.62, -29.62); `219@19` (-65.24, 28.00); `227@23` (-67.63, 17.20); `233@27` (-68.73, 15.87); `235@28` (-65.34, 8.62); `237@29` (-68.08, 10.02); `239@30` (-69.14, 12.68); `241@31` (-64.14, 24.04); `243@32` (-66.96, 29.71); `245@33` (-62.32, 23.87); `247@34` (-65.38, 30.00); `249@35` (40.10, -31.07); `251@36` (43.43, -28.58); `253@37` (39.23, -31.79); `255@38` (37.31, -31.27); `257@39` (-0.04, 47.41); `261@41` (-33.26, -13.92); `263@42` (-35.82, 2.27); `265@43` (-29.27, 18.71); `267@44` (-12.21, 26.82); `269@45` (5.67, 28.09); `271@46` (27.37, 27.16); `283@52` (47.04, 34.98); `289@55` (48.43, 30.59); `293@57` (79.84, 46.48); `295@58` (70.53, 30.47). Player (81.95, 32.29).

## L3

Threat steps explicitly selected from the loaded mission definition:

- `defend` — Help defend the station (combat; L3-03).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/armory — armory: Take a handgun from the armory | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-139.91, -6.85) | — |
| phase/yard — controller: yard | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (-134.95, 0.61) | — |
| step/defend — defend: Help defend the station | L3-03 | 89.20 player + 0.00 group/min; 3.92 s | 20.25 player + 0.00 group/min; 24.90 s | 29/29 | 23/23 | (-134.95, 0.61) | — |
| phase/attack — controller: attack | — | 89.20 player + 0.00 group/min; 3.92 s | 20.25 player + 0.00 group/min; 24.90 s | 29/29 | 23/23 | (-134.95, 0.61) | — |
| step/checkpoint — checkpoint: Get inside the army checkpoint | — | 328.79 player + 120.74 group/min; 0.15 s | 20.17 player + 3.78 group/min; 2.22 s | 60/61 | 0/26 | (-134.95, 0.61) | — |
| phase/fallback — controller: fallback | — | 328.79 player + 120.74 group/min; 0.15 s | 80.90 player + 0.00 group/min; 2.22 s | 60/61 | 18/18 | (-134.95, 0.61) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| station-0 | L3 scheduled wave.at (before admission) | 9.45 | 60.55 | 15 | 15 | — | 3.92 | — |
| station-1 | L3 scheduled wave.at (before admission) | 29.45 | 40.55 | 30 | 30 | — | 3.62 | — |
| station-2 | L3 scheduled wave.at (before admission) | 49.45 | 20.55 | 50 | 50 | — | 8.97 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/checkpoint`, `phase/corridor` at 272.57 s, 26/26 unreachable: `2299@1378` (171.23, -1.01); `2301@1379` (161.17, -2.54); `2303@1380` (157.09, -0.64); `2307@1382` (150.98, 2.25); `2473@1457` (195.57, -1.90); `2571@1502` (168.63, -0.73); `2573@1503` (183.07, 1.96); `2575@1504` (177.25, 0.04); `2577@1505` (165.90, -1.32); `2579@1506` (173.71, -0.85); `2741@1579` (195.09, -1.39); `2745@1581` (192.24, -1.02); `2875@1640` (196.73, -2.51); `2877@1641` (196.04, -2.42); `2879@1642` (193.68, -0.16); `2881@1643` (194.40, -1.32); `2967@1686` (187.76, 1.93); `2969@1687` (189.27, 0.41); `2971@1688` (189.11, 1.42); `2973@1689` (185.01, 2.39); `2975@1690` (185.72, 2.54); `3033@1719` (169.76, -0.60); `3035@1720` (172.83, -0.77); `3037@1721` (176.59, -0.19); `3039@1722` (174.37, -0.59); `3041@1723` (171.75, -0.49). Player (224.95, 0.92).
- `phase/done` at 274.10 s, 28/28 unreachable: `2299@1378` (176.14, -0.27); `2301@1379` (166.08, -1.25); `2303@1380` (161.83, -2.61); `2307@1382` (155.67, 0.04); `2571@1502` (173.83, -0.54); `2573@1503` (188.09, 1.86); `2575@1504` (182.22, 1.61); `2577@1505` (170.96, -0.72); `2579@1506` (178.66, 0.53); `2745@1581` (195.70, -2.10); `2877@1641` (195.04, -3.13); `2879@1642` (196.40, -2.18); `2881@1643` (196.94, -2.61); `2967@1686` (192.02, -0.98); `2969@1687` (191.84, -2.53); `2971@1688` (191.84, 0.00); `2973@1689` (189.36, 0.35); `2975@1690` (190.68, 1.23); `3033@1719` (174.96, -0.46); `3035@1720` (177.85, 0.23); `3037@1721` (181.56, 1.36); `3039@1722` (179.38, 0.73); `3041@1723` (176.83, -0.15); `3061@1733` (166.84, -0.90); `3063@1734` (168.83, -0.20); `3065@1735` (164.49, -3.00); `3067@1736` (166.27, -1.92); `3069@1737` (168.65, -0.93). Player (224.98, 0.33).

## L4

Threat steps explicitly selected from the loaded mission definition:

- `hold` — Hold the plaza with the army (combat; L4-07).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/ride — ride: Ride into Fairhaven with the convoy | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| phase/convoy — controller: convoy | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/quartermaster — quartermaster: Report to the quartermaster | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| phase/plaza — controller: plaza | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/hold — hold: Hold the plaza with the army | L4-07 | 970.11 player + 0.00 group/min; 9.33 s | 181.35 player + 0.00 group/min; 16.90 s | 80/80 | 80/80 | (-22.85, 0.74) | — |
| phase/war — controller: war | — | 970.11 player + 0.00 group/min; 9.33 s | 181.35 player + 0.00 group/min; 16.90 s | 80/80 | 80/80 | (-22.85, 0.74) | — |
| step/hide — hide: Run to the cellar via Lakeshore, Metro Road and Harbor Street | — | 766.26 player + 0.00 group/min; 0.03 s | 10.61 player + 0.00 group/min; 0.83 s | 71/71 | 78/79 | (-5.83, 20.11) | — |
| phase/collapse — controller: collapse | — | 766.26 player + 0.00 group/min; 0.03 s | 10.61 player + 0.00 group/min; 0.83 s | 71/71 | 78/79 | (-5.83, 20.11) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| war-0@1969 | l4.wave | 32.82 | 215.68 | 24 | 24 | — | 9.33 | — |
| war-1@2629 | l4.wave | 43.82 | 204.68 | 36 | 36 | — | 14.45 | — |
| breach-west | L4 breach.openAt | 52.72 | 195.78 | — | 96 | — | 8.82 | — |
| war-2@3289 | l4.wave | 54.82 | 193.68 | 48 | 31 | — | 52.78 | — |
| war-3@3949 | l4.wave | 65.82 | 182.68 | 54 | 12 | — | 119.32 | — |
| war--1@4009 | l4.wave | 66.82 | 181.68 | 15 | 0 | — | — | — |
| war-4@4609 | l4.wave | 76.82 | 171.68 | 54 | 0 | — | — | — |
| war-5@5269 | l4.wave | 87.82 | 160.68 | 54 | 0 | — | — | — |
| war-6@5929 | l4.wave | 98.82 | 149.68 | 54 | 0 | — | — | — |
| war-7@6589 | l4.wave | 109.82 | 138.68 | 54 | 0 | — | — | — |
| war-8@7249 | l4.wave | 120.82 | 127.68 | 54 | 0 | — | — | — |
| war-9@7909 | l4.wave | 131.82 | 116.68 | 54 | 0 | — | — | — |
| breach-north | L4 breach.openAt | 138.08 | 110.42 | — | 26 | — | 9.28 | — |
| war-10@8569 | l4.wave | 142.82 | 105.68 | 54 | 0 | — | — | — |
| war-11@9229 | l4.wave | 153.82 | 94.68 | 54 | 0 | — | — | — |
| war-12@9889 | l4.wave | 164.82 | 83.68 | 54 | 0 | — | — | — |
| war-13@10549 | l4.wave | 175.82 | 72.68 | 54 | 0 | — | — | — |
| breach-south | L4 breach.openAt | 177.08 | 71.42 | — | 6 | — | 5.05 | — |
| war-14@11209 | l4.wave | 186.82 | 61.68 | 54 | 0 | — | — | — |
| opening-alarm | L4 opening pending street cohorts | 32.82 | 215.68 | — | 0 | — | — | — |
| war-15@11869 | l4.wave | 197.82 | 50.68 | 54 | 0 | — | — | — |
| war-16@12529 | l4.wave | 208.82 | 39.68 | 54 | 0 | — | — | — |
| war-17@13189 | l4.wave | 219.82 | 28.68 | 54 | 0 | — | — | — |
| collapse-0@13609 | l4.wave | 226.82 | 21.68 | 6 | 0 | — | — | — |
| collapse-1@14149 | l4.wave | 235.82 | 12.68 | 6 | 0 | — | — | — |
| collapse-2@14689 | l4.wave | 244.82 | 3.68 | 6 | 0 | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/hide`, `phase/collapse` at 300.82 s, 1/79 unreachable: `618@377` (43.30, 36.25). Player (-78.20, -43.33).
- `step/bar` at 301.33 s, 80/80 unreachable: `217@48` (-15.60, -16.62); `274@103` (-55.52, -37.57); `311@138` (-49.57, -36.65); `312@139` (9.21, 21.42); `381@204` (-15.17, 41.28); `382@205` (-34.75, -36.37); `388@210` (-13.17, 25.44); `389@211` (-19.89, 36.45); `394@216` (-36.91, -34.57); `400@221` (-12.14, 29.27); `413@234` (8.34, 9.74); `414@235` (1.47, 18.26); `417@237` (-24.76, -1.57); `423@243` (-0.59, 33.60); `430@250` (-2.56, 11.08); `431@251` (-40.01, -35.32); `432@252` (-48.39, -36.53); `434@254` (-6.33, 12.03); `435@255` (-0.38, 37.27); `436@256` (-0.45, 30.12); `437@257` (-18.21, -22.48); `449@266` (-35.73, -36.50); `451@268` (-2.90, 35.95); `452@269` (-25.39, 18.75); `457@274` (-2.31, 8.57); `461@278` (-4.34, 18.60); `469@286` (18.48, 10.46); `470@287` (50.62, 18.40); `476@292` (-12.07, 28.20); `477@293` (-45.28, -36.12); `488@304` (-11.67, 28.75); `489@305` (-10.69, 28.27); `491@307` (-16.74, -20.34); `492@308` (-15.11, -15.32); `493@309` (-10.90, 27.60); `494@310` (-11.76, 27.54); `497@312` (-10.09, 28.95); `498@313` (-12.53, 28.71); `499@314` (-14.92, -16.46); `500@315` (-11.37, 28.12); `502@317` (-7.70, 8.94); `504@318` (-13.85, -15.70); `508@322` (-24.91, 6.67); `511@324` (-13.66, -14.50); `523@331` (-17.76, 24.25); `526@334` (-17.23, -21.04); `527@335` (-13.68, -17.00); `528@336` (-3.22, 16.65); `531@339` (-12.45, 26.27); `532@340` (-10.78, 29.53); `534@342` (-10.40, 15.99); `535@343` (-15.12, -17.40); `536@344` (15.51, -25.22); `537@345` (-25.50, 2.22); `538@346` (2.60, 36.00); `541@349` (-3.55, 24.27); `542@350` (-17.36, 1.28); `543@351` (-18.07, 14.72); `544@352` (-14.68, -11.96); `545@353` (-38.81, -35.24); `546@354` (-11.00, 28.88); `547@355` (-57.92, -38.75); `553@358` (-21.14, 4.48); `555@360` (51.38, -15.38); `556@361` (-11.46, 29.42); `557@362` (-55.76, 30.40); `558@363` (-13.09, 31.07); `560@365` (-14.26, -17.69); `561@366` (-15.56, -13.48); `579@367` (-9.84, -34.79); `582@368` (6.04, 8.38); `589@370` (-15.38, -12.57); `599@371` (-23.94, 34.07); `600@372` (-11.89, 30.17); `609@373` (37.36, 42.75); `617@376` (36.07, 32.84); `618@377` (43.30, 36.25); `619@378` (25.29, 41.71); `620@379` (2.89, -37.62); `622@381` (-81.22, -40.00). Player (75.30, -6.40).
- `phase/cellar`, `step/wait` at 308.50 s, 78/78 unreachable: `217@48` (-17.57, -12.74); `274@103` (-57.01, -38.00); `311@138` (-50.76, -36.74); `312@139` (16.44, 19.68); `381@204` (-15.17, 41.28); `382@205` (-35.24, -36.24); `388@210` (-13.17, 25.44); `389@211` (-16.05, 32.96); `394@216` (-37.77, -34.75); `400@221` (-11.93, 29.67); `413@234` (12.01, 11.87); `414@235` (0.49, 17.35); `417@237` (-26.83, -0.49); `423@243` (-0.59, 33.60); `430@250` (-1.70, 12.96); `431@251` (-41.24, -35.24); `432@252` (-49.76, -36.74); `434@254` (-10.55, 9.79); `435@255` (-0.38, 37.27); `436@256` (-0.45, 30.12); `437@257` (-20.47, -20.82); `449@266` (-36.24, -36.76); `451@268` (-2.90, 35.95); `452@269` (-26.82, 19.43); `457@274` (-3.64, 8.35); `461@278` (-7.08, 19.28); `469@286` (18.48, 12.63); `470@287` (55.77, 15.49); `476@292` (-12.32, 28.55); `477@293` (-47.26, -36.24); `488@304` (-11.76, 28.98); `489@305` (-11.06, 28.00); `491@307` (-18.50, -20.63); `492@308` (-17.81, -11.86); `493@309` (-11.61, 27.60); `494@310` (-12.26, 27.85); `497@312` (-10.25, 28.40); `498@313` (-12.47, 29.23); `499@314` (-18.83, -16.06); `500@315` (-11.69, 28.30); `502@317` (-9.66, 6.33); `504@318` (-15.58, -15.71); `509@323` (-28.07, 3.44); `511@324` (-14.69, -14.54); `523@331` (-20.63, 22.56); `526@334` (-16.59, -19.14); `527@335` (-18.66, -13.93); `528@336` (-0.08, 10.46); `531@339` (-14.82, 26.31); `532@340` (-10.62, 29.23); `533@341` (-21.48, 6.73); `534@342` (-8.02, 19.77); `535@343` (-17.31, -10.21); `536@344` (15.53, -27.36); `538@346` (2.60, 36.39); `541@349` (-3.69, 20.89); `542@350` (-18.35, -4.19); `543@351` (-22.35, 15.96); `544@352` (-16.73, -8.94); `545@353` (-40.24, -35.24); `546@354` (-11.11, 28.71); `547@355` (-59.42, -39.15); `555@360` (51.09, -9.81); `556@361` (-11.26, 29.48); `558@363` (-13.07, 31.28); `560@365` (-13.80, -14.71); `561@366` (-16.42, -10.00); `579@367` (-10.97, -34.94); `589@370` (-17.02, -11.31); `599@371` (-27.29, 31.47); `600@372` (-11.32, 30.32); `609@373` (37.60, 50.25); `617@376` (36.55, 34.36); `618@377` (43.30, 36.25); `619@378` (24.80, 41.71); `620@379` (15.67, -31.10); `621@380` (-5.67, -38.07); `622@381` (-75.78, -36.08). Player (74.65, -2.13).
- `phase/done` at 309.50 s, 79/79 unreachable: `217@48` (-17.55, -12.97); `274@103` (-57.01, -38.00); `311@138` (-50.76, -36.74); `312@139` (16.36, 19.81); `381@204` (-15.17, 41.28); `382@205` (-35.24, -36.24); `388@210` (-13.17, 25.44); `389@211` (-16.03, 32.38); `394@216` (-37.77, -34.75); `400@221` (-11.93, 29.66); `413@234` (12.63, 12.76); `414@235` (1.60, 17.32); `417@237` (-27.16, -0.05); `423@243` (-0.59, 33.60); `430@250` (-0.81, 12.86); `431@251` (-41.24, -35.24); `432@252` (-49.76, -36.74); `434@254` (-12.08, 10.70); `435@255` (-0.38, 37.27); `436@256` (-0.45, 30.12); `437@257` (-21.03, -20.05); `449@266` (-36.24, -36.76); `451@268` (-2.90, 35.95); `452@269` (-25.25, 20.48); `457@274` (-2.80, 8.35); `461@278` (-7.83, 20.59); `469@286` (18.48, 13.31); `470@287` (55.77, 15.49); `476@292` (-12.31, 28.52); `477@293` (-47.26, -36.24); `488@304` (-11.76, 28.97); `489@305` (-11.03, 28.00); `491@307` (-18.30, -21.51); `492@308` (-17.55, -12.05); `493@309` (-11.57, 27.59); `494@310` (-12.23, 27.83); `497@312` (-10.23, 28.43); `498@313` (-12.46, 29.19); `499@314` (-18.74, -16.73); `500@315` (-11.67, 28.28); `502@317` (-9.07, 6.55); `504@318` (-14.36, -15.98); `509@323` (-28.04, 3.49); `511@324` (-14.63, -14.69); `523@331` (-20.36, 22.17); `526@334` (-16.53, -19.56); `527@335` (-18.63, -10.89); `528@336` (0.61, 10.75); `531@339` (-14.75, 25.96); `532@340` (-10.63, 29.24); `533@341` (-24.56, 9.09); `534@342` (-8.46, 20.09); `535@343` (-16.57, -10.75); `536@344` (14.98, -27.63); `538@346` (2.60, 36.39); `541@349` (-3.87, 20.78); `542@350` (-18.37, -3.84); `543@351` (-22.06, 15.90); `544@352` (-17.12, -6.52); `545@353` (-40.24, -35.24); `546@354` (-11.10, 28.71); `547@355` (-59.42, -39.15); `552@357` (-26.51, 1.20); `555@360` (51.04, -8.88); `556@361` (-11.27, 29.48); `558@363` (-13.07, 31.28); `560@365` (-13.71, -14.52); `561@366` (-16.38, -9.85); `579@367` (-10.97, -34.94); `589@370` (-17.56, -11.10); `599@371` (-27.29, 31.47); `600@372` (-11.35, 30.32); `609@373` (37.59, 50.24); `617@376` (36.29, 35.13); `618@377` (43.30, 36.25); `619@378` (24.85, 41.71); `620@379` (16.23, -28.12); `621@380` (-5.67, -38.08); `622@381` (-76.71, -36.50). Player (74.65, -2.13).

## L5

Threat steps explicitly selected from the loaded mission definition:

- `look` — Look for anyone still alive (combat; L5-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/emerge — emerge: Unbar the cellar door | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/100 | 0/100 | (75.30, -5.39) | — |
| phase/cellar — controller: cellar | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/100 | 0/100 | (74.66, -1.77) | — |
| phase/emerged — controller: emerged | — | 30.00 player + 0.00 group/min; 6.23 s | 30.00 player + 0.00 group/min; 6.23 s | 100/100 | 100/100 | (-79.30, -44.28) | — |
| step/look — look: Look for anyone still alive | L5-05 | 533.68 player + 0.45 group/min; 0.05 s | 4.51 player + 0.00 group/min; 0.05 s | 100/100 | 37/37 | (37.51, -47.86) | — |
| phase/search — controller: search | — | 533.68 player + 0.45 group/min; 0.05 s | 4.51 player + 0.00 group/min; 0.05 s | 100/100 | 37/37 | (37.51, -47.86) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/emerge` at 0.02 s, 100/100 unreachable: `84@3` (-20.00, -37.60); `86@4` (-17.50, -36.10); `88@5` (-22.00, 10.00); `90@1` (46.00, 36.00); `91@6` (22.00, -37.40); `93@7` (-26.00, 40.00); `95@8` (-23.50, 41.50); `97@2` (-40.00, -37.40); `98@9` (2.00, 43.60); `100@10` (14.00, -2.00); `102@11` (-12.00, 18.00); `104@12` (44.00, -36.40); `106@13` (46.50, -34.90); `108@14` (-6.00, -37.40); `110@15` (10.00, 13.00); `112@16` (-46.00, -37.50); `114@17` (36.00, -37.40); `116@18` (-12.00, 43.60); `118@19` (14.00, -24.00); `120@20` (-60.00, 43.00); `122@21` (-4.00, 28.00); `124@22` (-40.00, -20.00); `126@23` (-8.90, 2.60); `128@24` (0.10, 2.60); `130@25` (53.50, 41.30); `132@26` (62.50, 41.30); `134@27` (-29.00, -2.70); `136@28` (-25.87, -44.40); `138@29` (-49.50, 50.00); `140@30` (-40.50, 50.00); `142@31` (68.00, -37.40); `144@32` (48.00, -12.00); `146@33` (40.00, 43.60); `148@34` (4.00, -37.40); `150@35` (0.00, -12.00); `152@36` (-4.00, 14.00); `154@37` (-16.00, -12.00); `156@38` (-28.00, -37.40); `158@39` (-32.00, -12.00); `160@40` (-36.00, 14.00); `162@41` (-60.00, -37.40); `164@42` (-72.00, 43.60); `166@43` (64.00, 2.00); `168@44` (60.00, 28.00); `170@45` (48.00, 2.00); `172@46` (4.00, -24.00); `174@47` (-16.00, 2.00); `176@48` (-32.00, 2.00); `178@49` (-36.00, 28.00); `180@50` (56.00, -37.40); `182@51` (52.00, -12.00); `184@52` (48.00, 14.00); `186@53` (12.00, 43.60); `188@54` (8.00, -37.40); `190@55` (0.00, 14.00); `192@56` (-28.00, -12.00); `194@57` (-36.00, 43.60); `196@58` (-52.00, 43.60); `198@59` (-56.00, -37.40); `200@60` (-68.00, 43.60); `202@61` (64.00, 28.00); `204@62` (52.00, 2.00); `206@63` (48.00, 28.00); `208@64` (-16.00, 28.00); `210@65` (-28.00, 2.00); `212@66` (-32.00, 28.00); `214@67` (60.00, -37.40); `216@68` (52.00, 14.00); `218@69` (48.00, 43.60); `220@70` (32.00, 43.60); `222@71` (16.00, 43.60); `224@72` (12.00, -37.40); `226@73` (-8.00, -12.00); `228@74` (-24.00, -12.00); `230@75` (-40.00, -12.00); `232@76` (-48.00, 43.60); `234@77` (68.00, 28.00); `236@78` (56.00, 2.00); `238@79` (52.00, 28.00); `240@80` (-12.00, 28.00); `242@81` (-20.00, -24.00); `244@82` (-24.00, 2.00); `246@83` (-28.00, 28.00); `248@84` (68.00, 43.60); `250@85` (64.00, -37.40); `252@86` (36.00, 43.60); `254@87` (12.00, -12.00); `256@88` (-4.00, -12.00); `258@89` (-20.00, -12.00); `260@90` (-32.00, -37.40); `262@91` (-36.00, -12.00); `264@92` (-40.00, 14.00); `266@93` (-44.00, 43.60); `268@94` (-64.00, -37.40); `270@95` (-76.00, 43.60); `272@96` (60.00, 2.00); `274@97` (56.00, 28.00); `276@98` (48.00, -24.00); `278@99` (0.00, -24.00); `280@100` (-20.00, 2.00). Player (75.30, -5.39).
- `phase/cellar` at 1.00 s, 100/100 unreachable: `84@3` (-20.00, -37.60); `86@4` (-17.30, -36.15); `88@5` (-21.79, 9.95); `90@1` (46.00, 36.00); `91@6` (21.56, -37.50); `93@7` (-26.00, 40.00); `95@8` (-23.54, 41.62); `97@2` (-40.00, -37.40); `98@9` (2.30, 43.54); `100@10` (13.96, -1.67); `102@11` (-12.00, 18.02); `104@12` (44.18, -36.40); `106@13` (46.31, -35.00); `108@14` (-5.70, -37.42); `110@15` (10.01, 12.98); `112@16` (-45.87, -37.55); `114@17` (36.12, -37.62); `116@18` (-12.02, 43.63); `118@19` (13.92, -24.32); `120@20` (-59.98, 42.86); `122@21` (-4.05, 27.91); `124@22` (-39.89, -19.80); `126@23` (-8.69, 2.47); `128@24` (0.07, 2.56); `130@25` (53.78, 41.29); `132@26` (62.49, 41.32); `134@27` (-28.94, -2.77); `136@28` (-25.87, -44.40); `138@29` (-49.58, 49.96); `140@30` (-40.83, 49.94); `142@31` (68.43, -37.61); `144@32` (48.04, -11.61); `146@33` (40.02, 43.64); `148@34` (4.29, -37.38); `150@35` (-0.01, -12.00); `152@36` (-4.04, 13.99); `154@37` (-16.04, -11.90); `156@38` (-27.82, -37.50); `158@39` (-31.77, -11.82); `160@40` (-36.01, 13.99); `162@41` (-60.16, -37.49); `164@42` (-72.22, 43.71); `166@43` (64.00, 2.00); `168@44` (59.86, 28.08); `170@45` (47.99, 1.50); `172@46` (3.72, -23.88); `174@47` (-16.01, 1.98); `176@48` (-32.00, 2.00); `178@49` (-36.10, 27.98); `180@50` (56.12, -37.42); `182@51` (51.96, -11.92); `184@52` (48.01, 14.00); `186@53` (11.51, 43.65); `188@54` (8.17, -37.30); `190@55` (-0.00, 14.00); `192@56` (-27.99, -12.00); `194@57` (-36.01, 43.64); `196@58` (-52.03, 43.55); `198@59` (-55.97, -37.40); `200@60` (-67.90, 43.72); `202@61` (63.63, 28.21); `204@62` (52.00, 2.00); `206@63` (48.07, 28.41); `208@64` (-15.98, 27.98); `210@65` (-28.00, 1.97); `212@66` (-32.11, 27.82); `214@67` (59.95, -37.39); `216@68` (51.77, 14.24); `218@69` (48.03, 43.62); `220@70` (32.04, 44.10); `222@71` (15.82, 43.69); `224@72` (11.76, -37.58); `226@73` (-7.99, -11.98); `228@74` (-23.98, -11.89); `230@75` (-40.00, -12.00); `232@76` (-48.00, 43.60); `234@77` (68.00, 28.00); `236@78` (55.97, 1.98); `238@79` (51.99, 27.97); `240@80` (-11.90, 27.80); `242@81` (-20.00, -24.00); `244@82` (-23.91, 2.30); `246@83` (-28.35, 27.68); `248@84` (67.93, 43.62); `250@85` (63.88, -37.39); `252@86` (35.90, 43.65); `254@87` (11.93, -11.75); `256@88` (-4.06, -11.74); `258@89` (-20.34, -11.70); `260@90` (-31.88, -37.46); `262@91` (-36.15, -12.28); `264@92` (-39.99, 14.06); `266@93` (-44.36, 43.63); `268@94` (-64.00, -37.40); `270@95` (-76.14, 43.65); `272@96` (59.63, 1.80); `274@97` (55.69, 27.90); `276@98` (48.00, -23.97); `278@99` (-0.07, -23.96); `280@100` (-19.77, 2.27). Player (74.66, -1.77).
- `step/metro`, `phase/shelter` at 203.47 s, 20/20 unreachable: `88@5` (-24.02, 5.15); `90@1` (49.05, 40.12); `91@6` (13.06, -37.34); `97@2` (-41.33, -40.14); `108@14` (4.54, -35.64); `118@19` (12.34, -15.46); `148@34` (11.73, -36.47); `162@41` (-82.11, -41.46); `168@44` (61.56, 18.37); `184@52` (62.50, 22.16); `188@54` (4.54, -40.37); `200@60` (-64.58, 44.52); `214@67` (59.32, -41.61); `224@72` (8.25, -38.16); `226@73` (-7.59, -13.49); `234@77` (66.64, 29.63); `238@79` (63.10, 21.47); `246@83` (-32.85, 20.78); `248@84` (71.29, 46.49); `278@99` (-6.69, -13.68). Player (38.38, -51.17).
- `phase/done` at 204.47 s, 20/20 unreachable: `88@5` (-24.02, 5.15); `90@1` (49.05, 40.12); `91@6` (12.61, -36.03); `97@2` (-41.33, -40.14); `108@14` (4.05, -35.88); `118@19` (12.34, -16.53); `148@34` (11.08, -36.86); `162@41` (-82.32, -41.58); `168@44` (61.57, 18.38); `184@52` (62.04, 21.01); `188@54` (3.54, -40.13); `200@60` (-64.48, 44.45); `214@67` (60.37, -41.57); `224@72` (7.55, -38.89); `226@73` (-7.18, -12.55); `234@77` (67.81, 29.75); `238@79` (63.11, 21.42); `246@83` (-33.81, 19.77); `248@84` (71.16, 45.46); `278@99` (-6.27, -12.71). Player (38.38, -51.17).

## L6

Threat steps explicitly selected from the loaded mission definition:

- `stop` — Stop the infected (combat; L6-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/shelter — shelter: Look around the shelter | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (0.33, 3.56) | — |
| phase/shelter — controller: shelter | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (0.33, 3.56) | — |
| step/stop — stop: Stop the infected | L6-05 | 411.67 player + 6.30 group/min; 1.62 s | 5.01 player + 13.36 group/min; 1.92 s | 17/17 | 3/3 | (0.33, 3.56) | — |
| phase/first — controller: first | — | 411.10 player + 0.00 group/min; 1.62 s | 8.56 player + 0.00 group/min; 1.92 s | 8/8 | 1/1 | (0.33, 3.56) | — |
| phase/fails — controller: fails | — | 413.25 player + 23.84 group/min; 0.28 s | 0.00 player + 32.21 group/min; — s | 17/17 | 3/3 | (0.33, 3.56) | — |
| step/retreat — retreat: Cover the retreat through the tunnel | — | 549.83 player + 125.64 group/min; 0.08 s | 8.06 player + 43.01 group/min; 32.78 s | 18/18 | 11/11 | (0.33, 3.56) | — |
| phase/retreat — controller: retreat | — | 549.83 player + 125.64 group/min; 0.08 s | 8.06 player + 43.01 group/min; 32.78 s | 18/18 | 11/11 | (0.33, 3.56) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| l6.breach1 | l6.breach1 | 33.20 | 76.80 | 8 | 8 | — | 1.62 | — |
| l6.breach2 | l6.breach2 | 54.22 | 55.78 | 10 | 10 | — | 6.27 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L7

Threat steps explicitly selected from the loaded mission definition:

- `corridor` — Bring the group to the evacuation corridor (combat; L7-05).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/rocket — rocket: Recover the rocket launcher beside the exit | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 98/98 | (273.01, 15.00) | — |
| phase/pickup — controller: pickup | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 98/98 | 98/98 | (273.01, 15.00) | — |
| step/corridor — corridor: Bring the group to the evacuation corridor | L7-05 | 19.88 player + 23.56 group/min; 4.18 s | 0.81 player + 0.00 group/min; 3.10 s | 96/96 | 62/62 | (-17.96, 47.95) | — |
| phase/encounters — controller: encounters | — | 45.82 player + 20.65 group/min; 4.18 s | 0.70 player + 0.00 group/min; 3.10 s | 98/98 | 5/5 | (-57.88, 47.26) | — |
| step/departure — departure: Get everyone aboard the bus | — | 128.89 player + 0.00 group/min; 2.17 s | 0.00 player + 0.00 group/min; — s | 96/97 | 0/0 | (35.94, 47.00) | — |
| phase/departing — controller: departing | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 96/97 | 0/0 | (35.94, 47.00) | — |
| phase/done — controller: done | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 97/98 | 0/0 | (40.00, 47.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L8

Threat steps explicitly selected from the loaded mission definition:

- `escape` — Bring the survivors to the armored vehicle and board (breach combat; L8-06).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/escape — escape: Bring the survivors to the armored vehicle and board | L8-06 | 278.80 player + 9.20 group/min; 63.82 s | 1.91 player + 0.00 group/min; 61.97 s | 88/88 | 80/80 | (51.37, 69.76) | — |
| phase/sanctuary — controller: sanctuary | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 0/0 | 0/0 | (23.14, 64.15) | — |
| phase/breached — controller: breached | — | 464.67 player + 15.33 group/min; 3.82 s | 5.24 player + 0.00 group/min; 1.97 s | 88/88 | 80/80 | (51.37, 69.76) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| tunnel-breach | L8 breachedAt/story.say | 60.00 | 90.00 | 12 | 12 | 3, 3, 3, 3 | 3.82 | — |
| tunnel-reinforcement@4200 | L8 nextWave clock | 70.00 | 80.00 | 16 | 16 | — | 3.15 | — |
| tunnel-reinforcement@4440 | L8 nextWave clock | 74.00 | 76.00 | 16 | 16 | — | 4.08 | — |
| tunnel-reinforcement@4680 | L8 nextWave clock | 78.00 | 72.00 | 16 | 16 | — | 2.98 | — |
| tunnel-reinforcement@4920 | L8 nextWave clock | 82.00 | 68.00 | 16 | 16 | — | 2.90 | — |
| tunnel-reinforcement@5160 | L8 nextWave clock | 86.00 | 64.00 | 16 | 4 | — | 35.42 | — |
| tunnel-reinforcement@5400 | L8 nextWave clock | 90.00 | 60.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5640 | L8 nextWave clock | 94.00 | 56.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@5880 | L8 nextWave clock | 98.00 | 52.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6120 | L8 nextWave clock | 102.00 | 48.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6360 | L8 nextWave clock | 106.00 | 44.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6600 | L8 nextWave clock | 110.00 | 40.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@6840 | L8 nextWave clock | 114.00 | 36.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7080 | L8 nextWave clock | 118.00 | 32.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7320 | L8 nextWave clock | 122.00 | 28.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7560 | L8 nextWave clock | 126.00 | 24.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@7800 | L8 nextWave clock | 130.00 | 20.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8040 | L8 nextWave clock | 134.00 | 16.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8280 | L8 nextWave clock | 138.00 | 12.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8520 | L8 nextWave clock | 142.00 | 8.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@8760 | L8 nextWave clock | 146.00 | 4.00 | 16 | 0 | — | — | — |
| tunnel-reinforcement@9000 | L8 nextWave clock | 150.00 | 0.00 | 16 | 0 | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L9

Threat steps explicitly selected from the loaded mission definition:

- None; roadside infected are still measured.

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/approach — approach: Drive toward the city | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (466.34, 3.29) | — |
| phase/driving — controller: driving | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (466.34, 3.29) | — |
| phase/approach — controller: approach | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 4/4 | 4/4 | (494.74, 1.14) | — |
| phase/fall — controller: fall | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (508.00, 0.00) | — |
| step/reach-outskirts — reach-outskirts: Get clear of the wreck | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (540.50, 0.87) | — |
| phase/impact — controller: impact | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (527.50, 2.60) | — |
| phase/crawl — controller: crawl | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (540.50, 0.87) | — |
| phase/done — controller: done | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | 2/2 | 2/2 | (547.00, 0.00) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| None announced during native run | — | — | — | — | — | — | — | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- No unreachable identities in the recorded phase snapshots.

## L10

Threat steps explicitly selected from the loaded mission definition:

- `hold` — Charge the dispersal system (assault combat; L10-11).

| Step / controller phase | Criterion | Passive attacks/min; first s | Skilled attacks/min; first s | Passive reachable | Skilled reachable | Passive player x/z | Passive flags |
|---|---|---:|---:|---:|---:|---|---|
| step/crash — crash: Leave the wreck on foot | — | 0.00 player + 0.00 group/min; — s | 0.00 player + 0.00 group/min; — s | — | — | — | — |
| step/residential-fringe — residential-fringe: Recover the handgun at the checkpoint | — | 156.52 player + 0.00 group/min; 5.32 s | 8.24 player + 0.00 group/min; 5.32 s | 7/7 | 5/5 | (763.90, 25.00) | — |
| step/industrial-area — industrial-area: Recover the shotgun at the checkpoint | — | 382.65 player + 0.00 group/min; 0.18 s | 7.68 player + 0.00 group/min; 28.43 s | 18/19 | 7/8 | (1253.25, 25.00) | — |
| step/military-zone — military-zone: Recover the machine gun at the checkpoint | — | 528.85 player + 0.00 group/min; 0.10 s | 8.36 player + 0.00 group/min; 36.52 s | 33/34 | 4/5 | (1849.67, 25.01) | — |
| step/research-campus — research-campus: Reach the research campus | — | 304.24 player + 0.00 group/min; 0.13 s | 14.25 player + 0.00 group/min; 11.45 s | 7/8 | 4/5 | (2461.00, -5.14) | — |
| step/research — research: Play the research recording | — | 338.87 player + 0.00 group/min; 2.67 s | 46.08 player + 0.00 group/min; 9.75 s | 54/55 | 28/29 | (2703.11, 41.37) | — |
| step/cure — cure: Pack the cure canister | — | 585.00 player + 0.00 group/min; 0.02 s | 0.00 player + 0.00 group/min; — s | 54/55 | 15/16 | (2705.13, 41.31) | — |
| step/research-exit — research-exit: Get the cure out of the laboratory | — | 860.45 player + 0.00 group/min; 0.02 s | 0.00 player + 0.00 group/min; — s | 52/53 | 1/2 | (2800.42, 44.74) | — |
| step/destroyed-corridor — destroyed-corridor: Carry the cure down the corridor and grab the rocket launcher | — | 934.52 player + 0.00 group/min; 0.07 s | 21.36 player + 0.00 group/min; 9.50 s | 54/55 | 19/20 | (2930.18, -4.99) | — |
| step/dispersal-complex — dispersal-complex: Bring the cure to the dispersal complex | — | 246.25 player + 0.00 group/min; 0.18 s | 5.54 player + 0.00 group/min; 4.48 s | 9/9 | 1/1 | (3694.13, -24.96) | — |
| step/install — install: Install the cure in the dispersal device | — | 287.33 player + 0.00 group/min; 0.27 s | 7.16 player + 0.00 group/min; 8.60 s | 20/21 | 0/1 | (4002.66, -37.19) | — |
| step/hold — hold: Charge the dispersal system | L10-11 | 844.62 player + 0.00 group/min; 0.20 s | 70.23 player + 0.00 group/min; 6.77 s | 95/95 | 36/36 | (4002.75, -28.82) | — |

| Announced wave | Native start source | Start s | Observed s | Expected | Spawned cohort | Per-outlet cohort | First attack s | Flags |
|---|---|---:|---:|---:|---:|---|---:|---|
| dispersal-assault | L10 charge-active (not first spawn) | 1002.05 | 59.98 | — | 74 | — | 4.67 | — |

Unreachable infected (sustained-threshold evidence when present, otherwise the last sample; coordinates in metres):

- `step/industrial-area` at 190.28 s, 1/8 unreachable: `119@17` (1029.80, 80.00). Player (1252.90, 25.00).
- `step/military-zone` at 355.02 s, 1/5 unreachable: `119@17` (1496.54, 100.00). Player (1850.05, 25.01).
- `step/research-campus` at 528.15 s, 1/5 unreachable: `119@17` (1948.72, -75.00). Player (2462.27, -5.11).
- `step/research` at 590.77 s, 1/29 unreachable: `119@17` (2175.55, -75.00). Player (2697.03, 41.56).
- `step/cure` at 592.57 s, 1/16 unreachable: `119@17` (2182.07, -75.00). Player (2705.13, 41.31).
- `step/research-exit` at 614.02 s, 1/2 unreachable: `119@17` (2259.77, -75.00). Player (2801.59, 44.79).
- `step/destroyed-corridor` at 652.78 s, 1/20 unreachable: `119@17` (2527.00, 24.05). Player (2929.14, -4.99).
- `step/dispersal-complex` at 786.12 s, 1/1 unreachable: `119@17` (3233.73, 70.51). Player (3432.02, 94.90).
- `step/install` at 944.57 s, 1/1 unreachable: `119@17` (3797.00, -36.30). Player (3999.20, -35.56).

## Every fail flag

- None.

## Flag-to-criterion mapping

| Flag | Acceptance criterion |
|---|---|

Absolute targets come from `docs/qa/level-acceptance.md`. L4 high-tier census supplements the low-tier passive contact/reachability run; its plaza uses the authored `l4.map.plaza` bounds. Both level and alarm clocks are reported; first breach must occur at level time 30–60 s with ≥60 alive. L3’s scheduled 18 s streams retain unspawned entries under the strict live cap (E21 §5.6); actual admissions within 18 s are shown separately, and the complete native route must produce every authored member. Armory visibility, actual squad attrition, competent damage and mortal input completion require the playtest report.

## Defect triage provenance

Historical failures and the original handoff are in `docs/reports/threat-calibrate/README.md`. They are baseline evidence, not current-run findings. Current failures are listed above with criterion mappings.

Run `npm run qa:threat -- --maxWorkers=2` for current JSON/Markdown receipts in `test-results/qa-threat/`. To refresh this baseline deliberately, add `--report docs/reports/threat-audit/README.md`. Remote: `sh tools/remote/run.sh "$PWD" --pull test-results/qa-threat -- npm run qa:threat -- --maxWorkers=2`. `npm run qa:threat -- --proof` proves the fail thresholds using deliberately broken fixtures without adding registered unit cases. `npm run qa:threat -- --passive-from test-results/qa-threat/audit.json` repeats the same policies without instrumentation and checks complete state hashes; add the same `--report` option to save proof with the baseline.
