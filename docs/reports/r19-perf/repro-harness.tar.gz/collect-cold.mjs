import{spawnSync}from'node:child_process';import{mkdirSync,writeFileSync}from'node:fs';
const [out,...cells]=process.argv.slice(2);if(!out||!cells.length)throw Error('Usage: collect-cold <out> <level/backend/tier>...');mkdirSync(out,{recursive:true});const rows=[];
for(const cell of cells){const[level,backend,tier]=cell.split('/');for(const[side,port]of[['prod',4912],['candidate',4911]]){
 const directory=`${out}/${level}-${backend}-${tier}/${side}`;mkdirSync(directory,{recursive:true});const started=Date.now();
 const args=['--import','tsx','tools/perf/cold-load-time.ts',`http://127.0.0.1:${port}`,backend,tier,'20',level];
 const r=spawnSync(process.execPath,args,{env:{...process.env,LOAD_OUT:directory,LOAD_FRESH_BROWSER:'1',LOAD_ASSERT:'0',LOAD_TRACE:'0',LOAD_GAMEPLAY_MS:'10000',LOAD_GAMEPLAY_LAST:'1'},stdio:'inherit'});
 rows.push({cell,side,args,started:new Date(started).toISOString(),seconds:(Date.now()-started)/1000,code:r.status,signal:r.signal,directory});writeFileSync(out+'/commands.json',JSON.stringify(rows,null,2)+'\n');if(r.status!==0)throw Error('Cold collection failed for '+cell+' '+side);
}}
