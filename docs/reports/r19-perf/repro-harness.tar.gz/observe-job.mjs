import './capture-admission.mjs';
import{spawn}from'node:child_process';import{mkdirSync,writeFileSync}from'node:fs';import{quietConditions}from'../../tools/browser-pool/host.ts';
const [out,...command]=process.argv.slice(2);if(!out||!command.length)throw Error('Usage: observe-job <out-directory> <command...>');
mkdirSync(out,{recursive:true});const started=Date.now(),samples=[];let sampling=false;
const sample=async()=>{if(sampling)return;sampling=true;try{const owned=new Set([process.pid]);let poolOwnership;
if(process.env.MI_BROWSER_POOL_EXCLUSIVE&&process.env.MI_BROWSER_POOL==='1'){
 const response=await fetch((process.env.BROWSER_POOL_URL??'http://127.0.0.1:4329')+'/health',{signal:AbortSignal.timeout(3000)});if(!response.ok)throw Error('Pool ownership health failed');const health=await response.json(),reservation=health.exclusive.find(e=>e.id===process.env.MI_BROWSER_POOL_EXCLUSIVE&&e.granted),job=process.env.BROWSER_POOL_JOB_ID??process.env.MI_SLUG??process.cwd().split('/').at(-1);
 if(!reservation||reservation.job!==job||health.leases.some(l=>!l.exclusive||l.job!==job)||health.starting.some(s=>s.job!==job))throw Error('Pool exclusive ownership mismatch');
 owned.add(health.pid);for(const browser of health.browsers)owned.add(browser.pid);poolOwnership={reservation:reservation.id,job,browsers:health.browsers};
}
samples.push({at:new Date().toISOString(),poolOwnership,...await quietConditions(owned,started)});}catch(error){samples.push({at:new Date().toISOString(),error:String(error)});}finally{sampling=false;}};
await sample();const timer=setInterval(()=>void sample(),2000);
const child=spawn(command[0],command.slice(1),{env:process.env,stdio:'inherit'});process.on('SIGTERM',()=>child.kill('SIGTERM'));process.on('SIGINT',()=>child.kill('SIGINT'));
const result=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',(code,signal)=>resolve({code,signal}));});clearInterval(timer);while(sampling)await new Promise(done=>setTimeout(done,10));await sample();
const foreign=samples.filter(s=>s.error||s.busy?.length);const receipt={command,started:new Date(started).toISOString(),finished:new Date().toISOString(),seconds:(Date.now()-started)/1000,...result,validQuiet:foreign.length===0,foreign,samples};
writeFileSync(out+'/host.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({out,seconds:receipt.seconds,code:result.code,validQuiet:receipt.validQuiet}));process.exitCode=foreign.length?75:result.code??1;
