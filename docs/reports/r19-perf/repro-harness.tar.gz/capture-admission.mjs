// A queued exclusive request can outlive the cooldown checked by quiet-run's
// wrapper. Recheck the current completion stamp after it is actually granted.
import {readFileSync,appendFileSync}from'node:fs';
import{quietConditions}from'../../tools/browser-pool/host.ts';
for(;;){
 let last=0;try{last=Number(readFileSync((process.env.E2E_LOCK??'/tmp/minor-incident-e2e.lock')+'.quiet-finished','utf8'));}catch{}
 const owned=new Set();
 if(process.env.MI_BROWSER_POOL_EXCLUSIVE&&process.env.MI_BROWSER_POOL==='1'){
  const response=await fetch((process.env.BROWSER_POOL_URL??'http://127.0.0.1:4329')+'/health',{signal:AbortSignal.timeout(3000)});if(!response.ok)throw Error('Pool health unavailable');const health=await response.json(),job=process.env.BROWSER_POOL_JOB_ID??process.env.MI_SLUG??process.cwd().split('/').at(-1),reservation=health.exclusive.find(e=>e.id===process.env.MI_BROWSER_POOL_EXCLUSIVE&&e.granted);
  if(!reservation||reservation.job!==job||health.leases.some(l=>!l.exclusive||l.job!==job)||health.starting.some(s=>s.job!==job))throw Error('Pool exclusive ownership mismatch');owned.add(health.pid);
 }
 const conditions=await quietConditions(owned);
 if(Date.now()>=last*1000+60000&&conditions.quiet){
  const row={at:new Date().toISOString(),pool:true,postQueueCooldown:true,...conditions};
  if(process.env.PERF_CONDITIONS_LOG)appendFileSync(process.env.PERF_CONDITIONS_LOG,JSON.stringify(row)+'\n');
  console.log('Capture admission after current cooldown: '+JSON.stringify(row));break;
 }
 await new Promise(done=>setTimeout(done,1000));
}
