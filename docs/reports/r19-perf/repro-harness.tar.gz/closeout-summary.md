## Closeout result

The original frame regressions are repaired in the six remeasured gameplay cells. Cold loading improved substantially in the two remeasured cells, but remains slower than fresh PROD. The full goal requires the missing matrix and event windows; this report does not certify them.

| What improved | Batch 60 before | Final | Matched fresh PROD |
|---|---:|---:|---:|
| L4 low/high frame p95 | 33.30 / 33.40 ms | 16.70 / 16.70 ms | 16.80 / 16.80 ms |
| L9 low/high maximum frame | 100.00 / 83.40 ms | 33.40 / 50.00 ms | 33.40 / 50.00 ms |
| L10 low maximum frame | 66.60 ms | 33.40 ms | 33.40 ms |
| L10 low full-charge maximum frame | 66.70 ms | 33.40 ms | 33.40 ms |
| L8 low WebGPU load median | 3,741.35 ms | 3,224.95 ms | 3,208.05 ms |
| L10 low WebGPU load median | 4,060.50 ms | 3,442.85 ms | 3,301.00 ms |

Before and final were separate sessions; the fresh PROD columns provide the contemporaneous comparison. Neither transfer size nor content was reduced by deleting features; lossless baked assets add delivery bytes, and first-damage render sources now load on demand.

### What is still worse than PROD, and why

| Measurement | Final difference | Explanation and next action |
|---|---:|---|
| L8 low WebGPU load median | +16.90 ms / +0.53% | Passes the brief's +5% bound, but strict parity is not achieved. The final run has no CPU profile to attribute this remaining gap; do not assign it to a specific subsystem from older profiles. Profile a new paired run if strict parity is required. |
| L10 low WebGPU load median | +141.85 ms / +4.30% | Passes +5%, with only about 23 ms median headroom. Earlier profiles identified static conversion, geometry, navigation and placement costs; their repairs explain the improvement, but do not establish the cause of the entire final residual. Profile the final source before another targeted repair. |
| L10 low charge p95 | +0.10 ms (16.80 vs 16.70) | Passes the inherited +1 ms comparison tolerance; literal no-increase is not demonstrated. This is consistent with browser interval quantization; a causal performance regression is not established by that difference alone. |
| L4 high maximum frame | +0.10 ms (50.10 vs 50.00) | Passes the inherited one-frame maximum tolerance. Retained in full rather than rounded away or discarded. |
| Other cold/native cells | Unknown | The closeout stops collection before these were measured at the frozen source. Earlier failures remain unresolved verification work, especially the WebGL2 cold spikes. Lamp replay success does not qualify cold loads or the missing native matrix. |

