import{spawn}from'node:child_process';import{mkdirSync,writeFileSync,openSync}from'node:fs';const root='test-results/r19-perf/final-v12',ledger=[];mkdirSync(root,{recursive:true});
const jobs=[
 {name:'cold-critical-low',kind:'cold',cells:['L8/webgpu/low','L10/webgpu/low']},
 {name:'native-low-L4-L9',kind:'native',tier:'low',levels:'L4,L9'},
 {name:'native-high-L4-L9',kind:'native',tier:'high',levels:'L4,L9'},
 {name:'native-low-L10',kind:'native',tier:'low',levels:'L10',seconds:90},
 {name:'native-high-L10',kind:'native',tier:'high',levels:'L10',seconds:90},
 {name:'cold-critical-high',kind:'cold',cells:['L8/webgpu/high','L10/webgpu/high']},
 {name:'cold-webgl-start-low',kind:'cold',cells:['L1/webgl2/low','L4/webgl2/low']},
 {name:'cold-webgl-late-low',kind:'cold',cells:['L8/webgl2/low','L10/webgl2/low']},
 {name:'cold-webgl-late-high',kind:'cold',cells:['L8/webgl2/high','L10/webgl2/high']},
 {name:'native-low-L3-L5-L6',kind:'native',tier:'low',levels:'L3,L5,L6'},
 {name:'native-high-L3-L5-L6',kind:'native',tier:'high',levels:'L3,L5,L6'},
 {name:'native-low-L7-L8',kind:'native',tier:'low',levels:'L7,L8'},
 {name:'native-high-L7-L8',kind:'native',tier:'high',levels:'L7,L8'},
 {name:'cold-gpu-start-low',kind:'cold',cells:['L1/webgpu/low','L4/webgpu/low']},
 {name:'cold-gpu-start-high',kind:'cold',cells:['L1/webgpu/high','L4/webgpu/high']},
 {name:'cold-gpu-L7',kind:'cold',cells:['L7/webgpu/low','L7/webgpu/high']},
 {name:'cold-gl-start-high',kind:'cold',cells:['L1/webgl2/high','L4/webgl2/high']},
 {name:'cold-gl-L7',kind:'cold',cells:['L7/webgl2/low','L7/webgl2/high']},
 {name:'ending-low',kind:'ending',tier:'low'}, {name:'ending-high',kind:'ending',tier:'high'}];
const run=(cmd,args,env,log)=>new Promise((resolve,reject)=>{const fd=openSync(log,'a'),p=spawn(cmd,args,{env:{...process.env,...env},stdio:['ignore',fd,fd]});p.on('error',reject);p.on('exit',(code,signal)=>resolve({code,signal}));});
for(const job of jobs){for(let attempt=0;attempt<3;attempt++){const dir=`${root}/${job.name}-a${attempt}`,log=dir+'.log';mkdirSync(dir,{recursive:true});let args,env={E2E_UNITS:'1',PERF_CONDITIONS_LOG:'test-results/r19-perf/conditions.jsonl'};if(job.kind==='cold')args=['node','--import','tsx','test-results/r19-perf/collect-cold.mjs',dir,...job.cells];if(job.kind==='native'){args=['node','--import','tsx','test-results/r19-perf/native.mjs','strips',job.levels,'webgpu'];Object.assign(env,{RELEASE_QUALITY:job.tier,RELEASE_SECONDS:String(job.seconds??60),RELEASE_PERF_ONLY:'1',RELEASE_CPU_PROFILE:'0',RELEASE_OUT:dir});}if(job.kind==='ending')args=['node','--import','tsx','test-results/r19-perf/ending.mjs',job.tier];const start=new Date().toISOString(),result=await run('sh',['tools/perf/quiet-run.sh','node','--import','tsx','test-results/r19-perf/observe-job.mjs',dir,...args],env,log);const row={...job,attempt,start,finished:new Date().toISOString(),dir,...result};ledger.push(row);writeFileSync(root+'/ledger.json',JSON.stringify(ledger,null,2));console.log(JSON.stringify(row));if(result.code===75)continue;if(result.code!==0)throw Error('Capture failed: '+job.name);if(job.kind==='cold'){const evaluated=await run('node',['test-results/r19-perf/evaluate-cold.mjs',dir],{},log);if(evaluated.code!==0)throw Error('Cold gate failed: '+job.name);}break;}}
