from pathlib import Path
import json,gzip,hashlib,shutil,tarfile,datetime,io
R=Path('test-results/r19-perf'); O=Path('docs/reports/r19-perf');O.mkdir(parents=True,exist_ok=True);index=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def emit(name,data,source=None):
 b=json.dumps(data,separators=(',',':'),ensure_ascii=False).encode();z=gzip.compress(b,compresslevel=9,mtime=0);assert len(z)<1048576,(name,len(z));(O/name).write_bytes(z);index.append({'path':name,'bytes':len(z),'sha256':sha(z),'source':source})
def read(p):return json.loads(p.read_text())
# Every collected cold sample is retained. Classification includes failed and incomplete attempts.
for group in sorted((R/'final-v12').glob('cold-*-a*')):
 if not group.is_dir():continue
 host=read(group/'host.json')if(group/'host.json').exists()else None
 for cell in sorted(group.iterdir()):
  if not cell.is_dir() or not cell.name.startswith('L'):continue
  samples=[]
  for side in ['prod','candidate']:
   for p in sorted((cell/side).glob(cell.name+'-*.json')):
    if not p.stem.rsplit('-',1)[-1].isdigit():continue
    b=p.read_bytes();samples.append({'source':str(p),'sha256':sha(b),'side':side,'record':json.loads(b)})
  emit('cold-'+group.name+'-'+cell.name+'.json.gz',{'hostValid':host and host['validQuiet'],'attempt':group.name,'samples':samples},str(cell))
 for file in ['evaluation.json','host.json','commands.json']:
  p=group/file
  if p.exists():emit(group.name+'-'+file+'.gz',read(p),str(p))
# Preserve all native frames/events/proof; omit only the redundant complete bot-input history.
for group in sorted((R/'final-v12').glob('native-*-a*')):
 if not group.is_dir():continue
 for p in group.glob('strips/webgpu/*.json'):
  b=p.read_bytes();rows=json.loads(b)
  for level in sorted(set(r['level']for r in rows)):
   data=[]
   for r in rows:
    if r['level']!=level:continue
    perf=r.get('performance',{});inputs=perf.pop('inputs',[]);r['inputEvidence']={'count':len(inputs),'sha256':sha(json.dumps(inputs,separators=(',',':')).encode()),'first':inputs[:2],'last':inputs[-2:],'fullHistoryLocal':str(p)};data.append(r)
   emit('native-'+group.name+'-'+level+'.json.gz',{'originalSource':str(p),'originalSha256':sha(b),'rows':data},str(p))
 p=group/'host.json'
 if p.exists():emit(group.name+'-host.json.gz',read(p),str(p))
for name in ['ending-low','ending-high']:
 p=R/(name+'.json')
 if p.exists():emit(name+'-frames.json.gz',read(p),str(p))
for group in sorted((R/'deferred-v12b').glob('*-a*')):
 if not group.is_dir():continue
 for file in ['host.json','evaluation.json']:
  p=group/file
  if p.exists():emit('deferred-'+group.name+'-'+file+'.gz',read(p),str(p))
 for p in group.glob('*-web*.json'):
  emit('lamp-'+group.name+'-'+p.name+'.gz',read(p),str(p))
for name in ['provenance.json','lamp-hardware.json','instrumentation.json']:
 p=R/name
 if p.exists():shutil.copyfile(p,O/name)
for rel in ['zoo-visual/receipt.json','static-visual/receipt.json','static-visual/comparison.json','differential/results.json','differential/farm-results.json','destruction-templates.json','load-graphs-v7/L10.cpu-summary.json','load-graphs-v6/L8.cpu-summary.json']:
 p=R/rel
 if p.exists():emit('diagnostic-'+p.parent.name+'-'+p.name+'.gz',read(p),str(p))
# Original failed repair attempts are retained in full as diagnostics, not mixed into final data.
for label,base in [('b946',R/'final/cold/critical-a0'),('e8fb',R/'final-v11/cold-critical-low-a0')]:
 cells=[]
 for p in base.glob('L*/[pc]*/*-summary.json'):cells.append({'source':str(p),'record':read(p)})
 if cells:emit('earlier-'+label+'-cold-summaries.json.gz',cells,str(base))
for p in [R/'deferred-v12/ending-low-a0/partial-results.json']:
 if p.exists():emit('ending-first-invalid-fixture.json.gz',read(p),str(p))
for label,rel in [('L4-cover-after','native-initial-L4/strips/webgpu/L4-candidate.cpuprofile.gz'),('L9-fragments-before','native-v2-L9/strips/webgpu/L9-candidate.cpuprofile.gz'),('L10-tableau-before','native-v3-L10/strips/webgpu/L10-candidate.cpuprofile.gz'),('L10-load-before-final-cpu','load-graphs-v7/L10.cpuprofile.gz')]:
 p=R/rel
 if p.exists():
  b=p.read_bytes();assert len(b)<1048576;(O/('profile-'+label+'.cpuprofile.gz')).write_bytes(b);index.append({'path':'profile-'+label+'.cpuprofile.gz','bytes':len(b),'sha256':sha(b),'source':str(p)})
for name in ['ledger.json','native-evaluation.json']:
 p=R/'final-v12'/name
 if p.exists():shutil.copyfile(p,O/('final-'+name))
p=R/'deferred-v12b/ledger.json'
if p.exists():shutil.copyfile(p,O/'deferred-ledger.json')
checks=Path('test-results/epics/E18/checks.json');shutil.copyfile(checks,O/'validation.json')
log=R/'verify-E18-harness.log'
if log.exists():(O/'validation-log.txt.gz').write_bytes(gzip.compress(log.read_bytes(),compresslevel=9,mtime=0))
kit=['snapshot-serve.mjs','restore-batch59.mjs','public-adapter.ts','public-adapter.js','baseline-public-adapter.js','build-baseline-adapter.mjs','capture-admission.mjs','observe-job.mjs','collect-cold.mjs','evaluate-cold.mjs','native.mjs','ab-tour-charge.ts','evaluate-native.mjs','ending.mjs','run-final.mjs','run-deferred.mjs','lamp-hardware.mjs','refresh-report.py','closeout-summary.md','closeout-details.md','package-evidence.py','static-frontier-ids.json','static-bake-ids.json','bake-frontier.mjs','map-profile.mjs']
with tarfile.open(O/'repro-harness.tar.gz','w:gz')as tar:
 for name in kit:
  p=R/name
  if p.exists():
   b=p.read_bytes()
   if p.suffix in ['.mjs','.ts']:
    b=b.replace((str(Path.cwd())+'/').encode(),b'../../')
   info=tarfile.TarInfo(name);info.size=len(b);info.mtime=int(p.stat().st_mtime);tar.addfile(info,io.BytesIO(b))
 tar.add('docs/reports/r18-release/ending-seeds.json',arcname='ending-seed-sources.json')
for p in sorted(O.iterdir()):
 if p.is_file() and p.name not in ['README.md','evidence-index.json'] and not any(x['path']==p.name for x in index):
  b=p.read_bytes();index.append({'path':p.name,'bytes':len(b),'sha256':sha(b),'source':'packaged receipt or reproduction source'})
(O/'evidence-index.json').write_text(json.dumps({'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':index,'rawRoot':str(R),'nativeInputHistories':'Full originals stay locally; every frame, event, scene sample and proof is retained in compact native files.'},indent=2)+'\n')
print(json.dumps({'files':len(index),'bytes':sum(x['bytes']for x in index),'kitBytes':(O/'repro-harness.tar.gz').stat().st_size}))
