## Follow-up lane

Keep game source `49078834` as the starting point and preserve the pinned batch 59 baseline. Finish qualification before treating the performance goal as achieved:

1. **18 cold cells:** all four backend/tier combinations for L1, L4 and L7; high WebGPU and both WebGL2 tiers for L8 and L10. Use 20 fresh browsers per side, all samples retained, the 6,000 ms maximum, +5% median and 200 ms post-card criteria. Prioritize WebGL2: r18 reported maxima of 8,226.8 ms at L1 low and 11,256.8 ms at L8 low. These were not remeasured here. Browser profile freshness does not reset OS or driver caches.
2. **10 native cells:** L3, L5, L6, L7 and L8, both tiers. Capture at least 60 seconds of actual gameplay with rendered-frame, geometry, input and survival proof.
3. **L7 event coverage:** pickup, rocket impact and combined windows in both tiers. Six r18 windows do not qualify the changed source.
4. **Residual strict parity:** investigate the +0.53% / +4.30% cold medians and repeat the +0.10 ms low charge p95 if the brief's literal p95 wording is required. PASS in these tables uses the explicitly disclosed inherited frame tolerance, not a stronger assertion.
5. **Deferred-work risk:** measure a normal full-route L10 approach through panorama prewarming, and isolated first-damage source visibility latency. Both natural endings and all lamp-boundary replays are complete; they do not establish every preceding route's performance.

Do not reuse an invalid host reservation. The rejected L4/L9 attempt and WebGL2 lamp attempt retain the foreign TypeScript process evidence. Pool-owned Chrome is classified by ownership, not rejected as a foreign browser. The observer uses a three-second pool RPC timeout; the earlier one-second timeout and a continuation-fixture failure are retained as failed attempts.

## Evidence and reproduction details

- [Coverage verdict](coverage.json): the complete goal remains false, with each missing cell counted.
- [Evidence index](evidence-index.json): compressed raw measurements, host receipts, failed repair summaries, differential outputs and CPU profiles, with SHA-256 and original local paths. Every native frame, event, proof and scene sample is retained. Redundant complete input histories remain in the original local JSON; compact files include their count, digest and first/last records.
- [Source and build provenance](provenance.json), [public instrumentation](instrumentation.json), [lamp hardware probe](lamp-hardware.json), [validation receipt](validation.json).
- [Native evaluator output](final-native-evaluation.json), [main capture ledger](final-ledger.json), [ending/lamp ledger](deferred-ledger.json). The last main ledger row was reconciled from its completed child host receipt because the parent was stopped before its next job.
- [Reproduction harness](repro-harness.tar.gz): extract into `test-results/r19-perf/` in this repository. Absolute workspace imports are normalized to relative paths in the archive. Requires this repository, its locked dependencies, browser-pool tooling and the recorded browser/GPU environment; it is not a standalone application. The kit contains seed source references rather than large duplicate save files. CPU source maps and original full local histories are not included; the selected raw CPU profiles and mapped summaries are included.

Use `b21393dc` for the continuation fixture correction; its `src/` and `public/` trees equal frozen source `49078834`. The report commit adds evidence only. No dependencies were added. The baseline adapter is compiled from `2741447`, not from candidate game code.

From the repository root, after unpacking the kit:

```sh
mkdir -p test-results/r19-perf
tar -xzf docs/reports/r19-perf/repro-harness.tar.gz -C test-results/r19-perf
node test-results/r19-perf/restore-batch59.mjs
```

The restore fails if a remote file no longer matches the recorded SHA; in that case restore the archived batch 59 bytes matching `docs/reports/perf12/mirror.json`. It never silently substitutes a later deployment. Rebuild public bytes with the frozen build label (or restore the retained immutable local snapshot):

```sh
NODE_ENV=production BRANCH=release VITE_QA_HOOKS=0 node --input-type=module <<'JS'
import { build } from 'vite';
await build({ define: { __BUILD_COMMIT__: JSON.stringify('49078834') } });
JS
cp -R dist test-results/r19-perf/public-dist
cp -R dist test-results/r19-perf/public-dist-v12
node test-results/r19-perf/build-baseline-adapter.mjs
PERF_CANDIDATE_ROOT=test-results/r19-perf/public-dist-v12 node test-results/r19-perf/snapshot-serve.mjs
```

Verify the public main bundle SHA-256 against the provenance before accepting a repeat; a rebuild with different tooling need not produce identical bytes. The last command owns ports 4911/4912; run it in a separate terminal and stop it afterwards. The supplied candidate adapter bundle is retained in the kit; cold URLs never request it. For a fresh one-cell cold capture:

```sh
sh tools/perf/quiet-run.sh node --import tsx test-results/r19-perf/observe-job.mjs test-results/r19-perf/recheck-cold node --import tsx test-results/r19-perf/collect-cold.mjs test-results/r19-perf/recheck-cold L10/webgpu/low
node test-results/r19-perf/evaluate-cold.mjs test-results/r19-perf/recheck-cold
```

For a fresh paired L10 native capture (use a new output directory rather than resuming old rows):

```sh
RELEASE_QUALITY=high RELEASE_SECONDS=90 RELEASE_PERF_ONLY=1 RELEASE_CPU_PROFILE=0 RELEASE_OUT=test-results/r19-perf/recheck-native/native-high-L10-a0 sh tools/perf/quiet-run.sh node --import tsx test-results/r19-perf/observe-job.mjs test-results/r19-perf/recheck-native/native-high-L10-a0 node --import tsx test-results/r19-perf/native.mjs strips L10 webgpu
node test-results/r19-perf/evaluate-native.mjs test-results/r19-perf/recheck-native
```

Restore ending fixtures from each entry's Git `source` in the kit's `ending-seed-sources.json` to `test-results/r19-perf/ending-seeds/{side}-{tier}.json.gz`, verifying its SHA-256. Resolve candidate `HEAD:` references at `49078834`. `run-deferred.mjs` then describes both natural ending and four QA lamp reservations. Its QA snapshot must be built with `VITE_QA_HOOKS=1`; it is separate from the public cold snapshot. Delete qualified cache stamps only when intentionally starting an independent repeat; raw previous attempts must remain available.

The development servers and matrix runner owned by this lane were stopped at closeout. No push or deployment was performed.
