from pathlib import Path
import json,re,subprocess,datetime
root=Path('test-results/r19-perf'); final=root/'final-v12'; report=Path('docs/reports/r19-perf/README.md'); before=Path('docs/reports/r18-release/README.md').read_text(); lines=before.splitlines(); cold_before={};native_before={}
for line in lines:
 cells=[x.strip()for x in line.split('|')[1:-1]]
 if cells and re.match(r'^L\d+ webgpu (low|high)$|^L\d+ webgl2 (low|high)$',cells[0]):cold_before[cells[0]]=cells[1:3]
 if cells and re.match(r'^L\d+ (low|high)$',cells[0]) and len(cells)==4 and re.match(r'^[\d.—]',cells[1]):native_before[cells[0]]=cells[1:3]
cold={}
for p in final.glob('cold-*-a*/evaluation.json'):
 try:
  obj=json.loads(p.read_text());host=json.loads((p.parent/'host.json').read_text())
  if not host['validQuiet']:continue
  for r in obj['rows']:cold[r['cell'].replace('-',' ')]=r
 except (ValueError,FileNotFoundError):pass
native_file=final/'native-evaluation.json';native=json.loads(native_file.read_text())['rows']if native_file.exists()else[]
for p in (root/'deferred-v12b').glob('ending-*-a*/evaluation.json'):
 try:
  r=json.loads(p.read_text());h=json.loads((p.parent/'host.json').read_text())
  if h['validQuiet']:native.append({'name':'L10 ending '+r['tier'],'prod':r['pair']['prod'],'candidate':r['pair']['candidate'],'pass':r['pass'] and r['allShots'] and r['panoramaFrames']>0})
 except (ValueError,FileNotFoundError):pass
nm={r['name']:r for r in native}
def fmt(a):return f"{a['median']:.1f} / {a['p90']:.1f} / {a['max']:.1f}"
def nf(a):return f"{a['p95']:.2f} / {a['max']:.2f}"
lamp_lines=[]
for backend in ['webgpu','webgl2']:
 for entry in ['debug','continue']:
  value=None
  for d in (root/'deferred-v12b').glob('lamps-'+backend+'-a*'):
   if not d.is_dir():continue
   try:
    h=json.loads((d/'host.json').read_text());r=json.loads((d/(entry+'-'+backend+'.json')).read_text())
    if h['validQuiet'] and h['code']==0:value=r
   except (ValueError,FileNotFoundError):pass
  if value:
   ok=value['playableFrames']>100 and (value['backend']==backend or backend=='webgl2' and value['backend']=='webgl') and value['state']['transform']['x']>800 and value['max']<=200
   lamp_lines.append(f"| {backend} / {entry} | {value['playableFrames']} | {value['p95']:.2f} / {value['max']:.2f} | {value['state']['transform']['x']:.2f} | {'PASS' if ok else 'FAIL'} |")
  else:lamp_lines.append(f'| {backend} / {entry} | — | — | — | UNMEASURED |')
now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds');source='49078834';out=[f'# r19-perf — batch 60 load and frame repair\n',f'**Status: closed at orchestrator instruction; the full goal is NOT met or certified.** Updated {now}. Frozen game source `{source}` (starting point `4f1e6728`). No deployment or push.\n','## Build and method\n','PROD is the pinned batch 59 public release: all 2,758 mirror files were restored and rehashed against the r18 manifest. Its matching adapter comes from the read-only `2741447` source export; the dependency lock matches. Candidate public bundle is `index-CrPXP-rT.js`, SHA-256 `ab39ed860a2debf9804836047e279b997873beeaa0cbbb2ab2795e09755c7922`. Immutable snapshots are served identically on 4911/4912. Only native probes request `testApi=1`; cold requests receive the original public bytes.\n','All timing uses `tools/perf/quiet-run.sh`, exclusive browser admission and post-queue cooldown, headless Chromium with `--use-angle=metal`, native Apple Metal, fixed DPR 1. Browser disk/HTTP caches are fresh; OS/GPU driver caches remain shared. Cold viewport is 1600×900; native viewport is 1280×720. Each reservation retains a host scan every two seconds. An overlap invalidates the complete paired reservation and requires a new attempt; individual slow samples are retained.\n','Cold acceptance: 20 fresh browser profiles per side/configuration; median ≤ matched PROD × 1.05, every candidate load ≤ 6,000 ms, maximum post-card interval ≤ 200 ms. Each configuration includes ten seconds of physical movement, at least 100 gameplay frames and the first post-card frames in every sample. The source cold tool’s strict no-increase median assertion remains unchanged; the separate evaluator applies the brief’s explicit +5% criterion.\n','Native acceptance uses the established [r18 comparison rules](../r18-release/README.md#frame-comparison-rules): p95 ≤ PROD + 1 ms, maximum ≤ PROD + 16.8 ms, and no new ≥66 ms hitch when PROD is below 66 ms. Each L3–L10 tier gets at least 60 seconds (L10 90), ordinary bot input, courier survival protection, actual rendered-frame progress and nonzero geometry. Both versions use the inherited fixture settings: camera shake, cheap DOF and VFX are disabled; selected low/high geometry quality is retained. These are browser animation-frame intervals, not GPU timer queries. Full default-effects parity is outside this measurement. Explicit L7 pickup/rocket, full L10 charge and natural ending windows are evaluated separately.\n','## Causes and repairs\n','| Cause | Profile / before evidence | Repair | Evidence / commit |','|---|---|---|---|',
'| Full dynamic cover scan | r18 L4 simulation p95 19.2 ms; cover query 15.58 s sampled self time in a minute. | Include destruction/door walls in the existing 8 m broadphase; retain exact ray tests and invalidate door mutations. | `09c2c540`; 512-ray differential plus door replacements; diagnostic L4 p95/max 16.8/33.4 ms versus PROD 16.7/33.4. |',
'| Repeated local destruction partitions | Every duplicate placement recomputed identical parts/collider intersections. | Share immutable templates per asset/class; HP, fire and damage state remain per object. | `66bc53a7`; constructor diagnostic L9 48.65→7.65 ms and L10 20.63→3.44 ms; all geometry/state hashes equal. Stub physics isolates this constructor. |',
'| Eager destruction render sources | Every potential damaged source and wreck was awaited at initial load. | Request the source after first damage, with readiness/disposal ownership retained. | `170a1a7a`; first-damage source can arrive asynchronously; ordinary combat is included in final native probes; isolated first-damage visibility latency was not measured. |',
'| Missing monkey/lioness crowd bakes | r18 L8 infected-crowd preparation added 772 ms. | Deliver the existing pipeline’s healthy/infected bakes for all three LODs (12 files, 4.4 MiB). | `fd357e3e`; no animation/geometry reduction. |',
'| Zoo shader identity includes data | Joint-name strings and bind-row constants split otherwise identical zoo skin graphs. | Share graph features; bind each draw’s atlas, pose and inverse-bind row. | `2da4a316`, `deedd09e`, `be3acfca`; all pixels identical in seven-species healthy/infected low/high fixtures; no browser errors. |',
'| Seating nonpassenger zoo animals | Vehicle startup prepared seated monkey/lioness models although the escape roster excludes zoo animals. | Prewarm eligible human passengers. | `5f8b5caf`; actual registry-load contract checked. |',
'| First obstacle/destruction fragment shaders | L9 100 ms frame follows a new plain-box wood material build at 6.44 s. | Warm real box variants under the loading camera; select materials from actual destructible parts. | `e2f6d472`, `c176d5a4`; diagnostic L9 maximum 50 ms after repair. |',
'| Full-world ground point queries | L10 groundHeight 139 ms plus rescue reachability 302 ms sampled in startup. | Raster exact support/slab heights; avoid redundant flat diagonals while retaining directed drops/climbs. | `cac84c2d`; full L10 raster compared to point samples and directed random graphs compared to reference. |',
'| Per-cell navigation flood queue | L10 flood 106.5 ms sampled over 8.88M cells. | Traverse contiguous row spans with the same four-neighbour connectivity. | `f419ac77`; differential masks against ordinary BFS. |',
'| Repeated enclosure frames | L10 interior ownership 153.8 ms sampled, including 106.8 ms in footFrame. | Prepare building frames/prop corners once; reject distant centres before the original exact containment test. | `1ca93632`, `25dade18`; 100 buildings / 2,500 props: identical 258 owners, diagnostic 25.28→6.36 ms. |',
'| Route-array allocation in scenery assembly | L10 roadside 67.4 ms and vignette placement 51.1 ms sampled. | Scalar distance loops, reuse nearest distance; placement and RNG order unchanged. | `19435ac3`; full outputs byte-identical (279 roadside / 612 vignette placements); isolated 71.12→46.78 and 42.78→27.96 ms. |',
'| Farm placement overlap scans | Farm scenery repeatedly scanned the full multi-kilometre placement list for each tile. | Cull occupied 16 m X buckets before the original exact footprint predicate; keep RNG and placement order. | `49078834`; 261 generated placements byte-identical in five runs; isolated 21–23→1–3 ms. |',
'| Runtime static geometry conversion | L10 staticBatch 332.9 ms sampled after the first delivery pass. | Deliver lossless existing batch format for campaign/zoo asset frontier, including hero LOD. Preserve every existing key and the ≤2× source transfer check. | `817c2762`, `e8fbf6aa`; 132 + 154 additional entries (3.21 + 9.61 MiB); source GLBs and fallback remain. |',
'| Ground triangle iterators | L10 ground field assembly 105.7 ms sampled. | Transform three vertices directly, preserving arithmetic. | `06e88ab0`. |',
'| Epilogue raw scenery shaders | L10 first charge frame 66.6 ms; 68 late material builds from raw barn/building tableau meshes. | Batch/instance fixed tableau scenery and share equivalent RGB-preserving graphs; animated people retain their rigs. | `457b2962`; diagnostic L10 maximum 50 ms after repair; both natural endings pass with all eight tableaux and panorama. |',
'| Distant panorama startup pipelines | R1 initial loading compiled panorama-only landscape/forest/mist graphs. | Retain the geometry and incrementally prepare pipelines when the finale console region becomes resident. | `b9460efb`; both natural endings pass; ordinary full-route approach is not separately qualified. |\n','## Cold-load matrix\n',f'Qualified final cells: **{len(cold)}/20**. Values are median / p90 / maximum milliseconds. “Batch 60” is the unchanged game source measured in r18 (`c8d4a802`; no src/tools/public difference from `4f1e6728`).\n','| Configuration | r18 PROD | Batch 60 before | Fresh PROD | Final candidate | Δ median | Post-card max | Verdict |','|---|---:|---:|---:|---:|---:|---:|---|']
for level in ['L1','L4','L7','L8','L10']:
 for backend in ['webgpu','webgl2']:
  for tier in ['low','high']:
   key=f'{level} {backend} {tier}';base=cold_before[key];r=cold.get(key)
   out.append('| '+ ' | '.join([key,*base,fmt(r['prod'])if r else '—',fmt(r['candidate'])if r else '—',f"{r['deltaPercent']:+.2f}%"if r else '—',f"{r['candidate']['postCardMax']:.1f}"if r else '—',('PASS'if r['pass']else'FAIL')if r else 'UNMEASURED'])+' |')
out+=['\n## Native frame matrix\n','Values are p95 / maximum milliseconds. r18’s diagnostic values above do not substitute for this frozen-source matrix.\n','| Cell | r18 PROD | Batch 60 before | Fresh PROD | Final candidate | Verdict |','|---|---:|---:|---:|---:|---|']
for level in ['L3','L4','L5','L6','L7','L8','L9','L10']:
 for tier in ['low','high']:
  key=f'{level} {tier}';b=native_before.get(key,['—','—']);r=nm.get(key)
  out.append('| '+' | '.join([key,*b,nf(r['prod'])if r else'—',nf(r['candidate'])if r else'—',('PASS'if r['pass']else'FAIL')if r else'UNMEASURED'])+' |')
out+=['\n### Event and ending windows\n','| Window | PROD p95 / max | Candidate p95 / max | Verdict |','|---|---:|---:|---|']
for kind in ['L7 pickup','L7 rocket','L7 combined','L10 charge','L10 ending']:
 for tier in ['low','high']:
  key=f'{kind} {tier}';r=nm.get(key);out.append('| '+' | '.join([key,nf(r['prod'])if r else'—',nf(r['candidate'])if r else'—',('PASS'if r['pass']else'FAIL')if r else'UNMEASURED'])+' |')
out+=['\n### L10 lamp-boundary recorded input\n','Required: >100 native playable frames, actual backend, endpoint x >800, maximum post-card interval ≤200 ms. These are uncapped profiled diagnostics; they are excluded from the cold and native matched-frame distributions. The QA game source is frozen at `49078834`. The game API calls its WebGL2 backend `webgl`.\n',
'| Backend / entry | Frames | p95 / max ms | Endpoint x | Verdict |',
'|---|---:|---:|---:|---|', *lamp_lines, '\n','## Validation, attempts and remaining work\n','- `npm run verify -- E18`: PASS, typecheck + lint + 27 files / 107 unit cases. The retired per-AC gate delegates to the per-change gate.\n- `git diff --check`: PASS after the frozen source commit.\n- Public and QA builds: PASS. No new dependencies.\n- Zoo skinning: healthy/infected lion, gorilla, elephant, zebra, flamingo, monkey and lioness fixtures are pixel-identical in low and high tiers, with no browser errors. Static-bake views in L8/L10 are also pixel-identical in both tiers, with no browser errors.\n- The first clean 20-profile repair attempt (`b9460efb`) was retained as a FAIL: L8 3,408.55 vs 3,174.85 ms (+7.36%); L10 approximately 3,725 ms vs 3,292.45 ms. Later three-profile runs are diagnostic only. The next complete repair attempt (`e8fbf6aa`) was also retained: L8 PASS (+0.55%), L10 FAIL (+5.039%, 1.30 ms above the +5% limit). Final source `49078834` adds an exact farm overlap broadphase and is measured independently.\n- One native L4/L9 reservation was invalidated in full when a root-workspace TypeScript check overlapped at 13:52:31–13:52:42 UTC. All four captures were repeated; the retry host receipt is clean.\n- The previously unexecuted r18 ending harness initially timed out on PROD: its old bot starts route cursor 0 on the restored release save. The fixture now restores the cursor to the finale on both versions and records that provenance. Positions, physics, native inputs and natural clocks are retained. The failed attempt and its complete unpaired candidate diagnostic are retained.\n- Closed coverage: 2/20 cold cells, 6/16 native cells, both charge windows, both natural endings, and all four lamp replays. All qualified measurements pass the stated comparison rules; missing cells remain UNMEASURED.\n- Closeout: the orchestrator instructed this lane to finish its current capture, commit, document remaining regressions, and end within 20 minutes. The last capture finished at 14:54:47 UTC on 2026-11-09. No further captures were started. Remaining qualification and repairs belong to a follow-up lane.\n','## Reproduction\n','The retained harness runs the original public cold tool with 20 fresh browsers per side, then applies the brief’s +5% evaluator. Native uses each release’s matching adapter. Every attempted reservation retains raw samples and host receipts; slow samples are not removed. See the evidence and reproduction section below.\n']
out.insert(2,(root/'closeout-summary.md').read_text())
out.append((root/'closeout-details.md').read_text())
report.write_text('\n'.join(out))
print('Report refreshed:',len(cold),'cold cells;',len(native),'native/event rows')
