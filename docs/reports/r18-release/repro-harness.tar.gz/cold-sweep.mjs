import {spawn} from 'node:child_process';import {openSync,mkdirSync,writeFileSync,existsSync,readFileSync} from 'node:fs';
const root='test-results/r18-release';mkdirSync(`${root}/cold/logs`,{recursive:true});mkdirSync(`${root}/conditions`,{recursive:true});
const receipts=[];let child;process.on('SIGTERM',()=>child?.kill('SIGTERM'));process.on('SIGINT',()=>child?.kill('SIGINT'));
for(const level of ['L1','L4','L7','L8','L10'])for(const backend of ['webgpu','webgl2'])for(const tier of ['low','high']){
 const id=`${level}-${backend}-${tier}`,summary=`${root}/cold/candidate/${id}-summary.json`;
 if(existsSync(summary)){const x=JSON.parse(readFileSync(summary));if(x.n===20){console.log('retaining complete cell '+id);continue;}}
 const log=`${root}/cold/logs/${id}.log`,fd=openSync(log,'a'),start=Date.now();console.log('start '+id);
 child=spawn('sh',['tools/perf/quiet-run.sh','node','test-results/r18-release/cold-pair.mjs',level,backend,tier],{env:{...process.env,MI_SLUG:'r18-release',E2E_UNITS:'1',PERF_CONDITIONS_LOG:`${root}/conditions/cold-${id}.jsonl`},stdio:['ignore',fd,fd]});
 const code=await new Promise(resolve=>child.once('exit',(code,signal)=>resolve(code??signal)));child=null;
 receipts.push({id,code,seconds:(Date.now()-start)/1000,log});writeFileSync(`${root}/cold/commands.json`,JSON.stringify(receipts,null,2)+'\n');console.log('finish '+JSON.stringify(receipts.at(-1)));
}
