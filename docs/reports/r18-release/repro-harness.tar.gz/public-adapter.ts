import { installTestApi } from '../../src/debug/testApi';
export async function install(game: Parameters<typeof installTestApi>[0], ready: Promise<void>) {
  const settled = ready.then(async () => {
    await (game as unknown as { audioLoad: Promise<void> }).audioLoad;
    if ((game as unknown as { speculativeRunning: boolean }).speculativeRunning) await game.loadLevel('L1', { seed: Number(game.params.get('seed') ?? 1) });
  });
  installTestApi(game, settled);
  (window as unknown as { __SCENE__: { game: typeof game } }).__SCENE__ = { game };
}
