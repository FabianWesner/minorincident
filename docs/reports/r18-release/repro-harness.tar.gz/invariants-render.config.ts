import base from '../../tests/qa/invariants/playwright.config';
import { fileURLToPath } from 'node:url';
import { defineConfig } from '@playwright/test';
export default defineConfig({ ...base, testDir: fileURLToPath(new URL('.', import.meta.url)), testMatch: 'invariants-render.spec.ts', grep: /8 load time/, outputDir: 'test-results/r18-release/invariants-prod-mirror/browser', reporter: [['list'], ['json', { outputFile: 'test-results/r18-release/invariants-prod-mirror/browser.json' }]] });
