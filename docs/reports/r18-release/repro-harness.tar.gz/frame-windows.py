import json,pathlib,math
R=pathlib.Path('test-results/r18-release')
def stats(a):return {'samples':len(a),'p95':sorted(a)[math.ceil(.95*len(a))-1],'max':max(a),'spikes66':sum(x>=66-1e-6 for x in a)}if a else None
def window(r,kind):
 f=r['performance'];events=f['events'];clock=f['missionFrames']or f['chargeFrames']
 if kind in ['pickup','first rocket','pickup through first rocket']:
  pickup=next(e for e in events if e['type']=='pickup.collected'and e.get('actionId')=='weapon.rocket-launcher')
  rocket=next(e for e in events if e['type']=='combat.attack'and e.get('actionId')=='weapon.rocket-launcher'and e.get('sourceId')==1)
  impact=next(e for e in events if e['type']=='explosion'and e.get('defId')=='explosion.rocket'and e.get('sourceId')==1 and e['at']>=rocket['at'])
  start=(rocket if kind=='first rocket'else pickup)['at']-100;end=(pickup if kind=='pickup'else impact)['at']+250
 else:
  assert r['proof']['l10']['chargeTicks']==0 and not r['proof']['l10']['active'] and r['proof']['tick']==f['tick'], 'capture began after charge activation'
  start=0;end=next(x['at']for x in f['chargeFrames']if x['charge']>=3600)+2000
 assert end<=f['durationMs'],f'{end} > {f["durationMs"]}'
 assert len(clock)==len(f['frames']), 'frame clocks are not aligned'
 indices=[i for i,x in enumerate(clock)if x['at']>=start and x['at']-f['frames'][i]<=end]
 initial=max(0,clock[0]['at']-f['frames'][0]) if start==0 else 0
 values=[f['frames'][i]for i in indices]
 if initial>1e-6:values.insert(0,initial)
 return {'startMs':start,'endMs':end,'indices':indices,'initialPartialMs':initial,'stats':stats(values)}
allrows=[]
for p in(R/'native').glob('*/strips/webgpu/*.json'):
 for r in json.load(open(p)):r['source']=str(p);allrows.append(r)
for p in(R/'charge-full').glob('*/strips/webgpu/*.json'):
 for r in json.load(open(p)):r['source']=str(p);allrows.append(r)
rows=[]
for level,kinds in [('L7',['pickup','first rocket','pickup through first rocket']),('L10',['charge through completion +2s'])]:
 for tier in ['low','high']:
  for kind in kinds:
   row={'level':level,'tier':tier,'name':kind,'sides':{},'issues':[]}
   eligible=[r for r in allrows if r['level']==level and r['tier']==tier]
   if level=='L10' and any('/charge-full/' in r['source'] for r in eligible):eligible=[r for r in eligible if '/charge-full/' in r['source']]
   for r in eligible:
    if r['level']==level and r['tier']==tier and r.get('performance')and not r.get('failure'):
     try:row['sides'][r['side']]={'source':r['source'],**window(r,kind)}
     except(StopIteration,AssertionError)as e:row['issues'].append(r['side']+': '+str(e))
   if len(row['sides'])==2:
    p,c=(row['sides'][s]['stats']for s in ['prod','candidate'])
    if c['p95']>p['p95']+1+1e-6:row['issues'].append('p95 >PROD+1ms')
    if c['max']>p['max']+16.8+1e-6:row['issues'].append('max >PROD+one frame')
    if c['max']>=66-1e-6 and p['max']<66-1e-6:row['issues'].append('new >=66ms hitch')
   row['verdict']='INCOMPLETE'if len(row['sides'])<2 else'FAIL'if row['issues']else'PASS';rows.append(row)
(R/'event-windows.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Event windows', {v:sum(r['verdict']==v for r in rows)for v in ['PASS','FAIL','INCOMPLETE']})
