import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const audit=[];
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.wasm':'application/wasm','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.glb':'model/gltf-binary','.webm':'audio/webm','.m4a':'audio/mp4','.gz':'application/gzip','.ktx2':'image/ktx2'};
const api=fs.readFileSync('test-results/r18-release/public-adapter.js');
const patchRows=[];
for(const [side,root,port] of [['after','dist',4916],['before','test-results/r18-release/before-build',4915]].filter(([side])=>!process.env.PERF_SERVE_SIDES||process.env.PERF_SERVE_SIDES.split(',').includes(side))){
 const files=new Map();
 for(const p of fs.readdirSync(root,{recursive:true}).map(String)) if(fs.statSync(path.join(root,p)).isFile()){
  const file=path.join(root,p),stat=fs.statSync(file); files.set('/'+p,{file,size:stat.size,etag:`W/"${stat.size}-${Math.floor(stat.mtimeMs)}"`});
 }
 const index=fs.readFileSync(path.join(root,'index.html'),'utf8'),main=/src="(\/build\/index-[^" ]+\.js)"/.exec(index)[1], original=fs.readFileSync(files.get(main).file,'utf8');
 const re=/const (\w+)=new (\w+)\((\w+)\),(\w+)=\(async\(\)=>\{await \1\.init\(\)\}\)\(\);try\{/;
 if(!re.test(original))throw Error('Unable to expose game on '+side);
 const patched=original.replace(re,(match,g)=>match.replace('try{',`globalThis.__perfGame=${g};try{`));
 patchRows.push({side,main,originalSha256:crypto.createHash('sha256').update(original).digest('hex'),patchedSha256:crypto.createHash('sha256').update(patched).digest('hex'),patch:'Expose the existing Game instance to the shared test adapter only for ?testApi=1; original public code otherwise intact.'});
 http.createServer((req,res)=>{const pathname=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
  if(pathname==='/__perf6__/audit'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({patchRows,requests:audit}));return;}
  if(pathname==='/__perf6__/api.js'){res.setHeader('Content-Type','text/javascript');res.end(api);return;}
  const p=pathname==='/'?'/index.html':pathname,entry=files.get(p),instrument=p===main&&req.headers.referer?.includes('perfProbe=1');
  audit.push({at:new Date().toISOString(),side,path:p,status:entry?200:404,instrumented:!!instrument});
  if(!entry){res.writeHead(404,{'Content-Type':'text/plain'});res.end('Missing mirrored file: '+p);return;}
  res.setHeader('Content-Type',mime[path.extname(p)]??'application/octet-stream');res.setHeader('Cache-Control','no-cache');res.setHeader('Access-Control-Allow-Origin','*');
  if(instrument){res.end(patched);return;}
  res.setHeader('ETag',entry.etag);
  if(req.headers['if-none-match']===entry.etag){audit.at(-1).status=304;res.writeHead(304);res.end();return;}
  res.setHeader('Content-Length',entry.size);fs.createReadStream(entry.file).pipe(res);
 }).listen(port,'127.0.0.1',()=>console.log(side+' http://127.0.0.1:'+port));
}
fs.writeFileSync('test-results/r18-release/instrumentation-probe.json',JSON.stringify({adapterSha256:crypto.createHash('sha256').update(api).digest('hex'),patchRows},null,2));
