import json,pathlib,statistics,math
R=pathlib.Path('test-results/r18-release')
def read(p):return json.loads(p.read_text())
def stats(a):return {'n':len(a),'p95':sorted(a)[math.ceil(len(a)*.95)-1],'max':max(a),'spikes66':sum(x>=66-1e-6 for x in a)} if a else None
loads=[]
for level in ['L1','L4','L7','L8','L10']:
 for backend in ['webgpu','webgl2']:
  for tier in ['low','high']:
   row={'level':level,'backend':backend,'tier':tier,'sides':{}};issues=[]
   for side in ['prod','candidate']:
    p=R/'cold'/side/f'{level}-{backend}-{tier}-summary.json'
    if not p.exists():issues.append(side+': missing summary');continue
    v=read(p);row['sides'][side]=v
    files=list((R/'cold'/side).glob(f'{level}-{backend}-{tier}-[0-9]*.json'))
    samples=[read(p) for p in files]
    if len(samples)!=20 or v['n']!=20:issues.append(side+': expected20 samples')
    if len({r.get('diskCache') for r in samples})!=20:issues.append(side+': repeated browser profile')
    if any(len(r.get('frames',[]))<2 for r in samples) or not any(r['gameplayMs']>=10000 and len(r.get('frames',[]))>=100 for r in samples):issues.append(side+': missing post-card/gameplay frames')
    if any(not r['freshBrowser'] or r['diagnostic'] or r['errors'] or r['settingsQuality']!=tier for r in samples):issues.append(side+': invalid profile/tier/errors')
    if any(not(r['adapter'] and not r['adapter'].get('fallback',False) and r['adapter']['architecture'].startswith('metal-')) if backend=='webgpu' else not(r.get('glRenderer') and 'metal' in r['glRenderer'].lower())for r in samples):issues.append(side+': wrong backend/hardware')
   if len(row['sides'])==2:
    p,c=(row['sides'][s]for s in ['prod','candidate'])
    if c['max']>6000:issues.append('maximum >6000ms')
    if c['median']>p['median']:issues.append('median >PROD')
    if c['maxFrameMs']>200:issues.append('post-card frame >200ms')
    if c['gameplaySamples']<1:issues.append('missing10s movement')
   row['issues']=issues;row['verdict']='INCOMPLETE'if len(row['sides'])<2 else'FAIL'if issues else'PASS';loads.append(row)
native=[]
for p in (R/'native').glob('*/strips/webgpu/*.json'):
 for r in read(p):r['receipt']=str(p);native.append(r)
frames=[]
for level in ['L3','L4','L5','L6','L7','L8','L9','L10']:
 for tier in ['low','high']:
  sides={r['side']:r for r in native if r['level']==level and r['tier']==tier};row={'level':level,'tier':tier,'sides':{}};issues=[]
  for side,r in sides.items():
   perf=r.get('performance');row['sides'][side]={'stats':stats(perf['frames'])if perf else None,'receipt':r['receipt'],'failure':r.get('failure'),'errors':r['errors']}
   if r.get('failure')or r['errors']or r['diagnostic']or not perf or sum(perf['frames'])<60000 or perf['nonGameplayFrames']:issues.append(side+': incomplete/invalid window')
   if perf and perf.get('renderedFrameEnd',0)-perf.get('renderedFrameStart',0)<1000:issues.append(side+': missing rendered-frame progress')
   if not r['samples']or not any(s.get('drawCalls',0)>0 and s.get('triangles',0)>0 for s in r['samples']):issues.append(side+': no submitted geometry')
   if any(s.get('scenario')!=level or s.get('quality')!=tier or s.get('backend')!='webgpu'for s in r['samples']):issues.append(side+': level/backend/tier mismatch')
   h=r.get('hardware');
   if not h or not h['architecture'].startswith('metal-')or h.get('isFallbackAdapter'):issues.append(side+': hardware fallback')
  if len(row['sides'])==2 and all(s.get('stats')for s in row['sides'].values()):
   p,c=(row['sides'][s]['stats']for s in ['prod','candidate'])
   if c['p95']>p['p95']+1+1e-6:issues.append('p95 >PROD+1ms')
   if c['max']>p['max']+16.8+1e-6:issues.append('max >PROD+one frame')
   if c['max']>=66-1e-6 and p['max']<66-1e-6:issues.append('new >=66ms hitch')
  row['issues']=issues;row['verdict']='INCOMPLETE'if len(row['sides'])<2 else'FAIL'if issues else'PASS';frames.append(row)
result={'loads':loads,'native':frames};(R/'release-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for label,rows in result.items():
 counts={v:sum(r['verdict']==v for r in rows)for v in ['PASS','FAIL','INCOMPLETE']};print(label,counts)
 for r in rows:
  if r['verdict']!='INCOMPLETE':print(r['level'],r.get('backend','webgpu'),r['tier'],r['verdict'],r['issues'])
