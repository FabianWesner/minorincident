import './capture-admission.mjs';
import {spawnSync} from 'node:child_process';
for(const [tier,area,args] of [['low','low',['L1,L3,L4,L5,L7,L10']],['high','high',['L1,L3,L4,L5,L7,L10']],['low','gl2-low',['L1,L4,L7','webgl2']]]){
 const result=spawnSync(process.execPath,['--import','tsx','tools/qa/release-ab-load.mjs',...args],{env:{...process.env,RELEASE_QUALITY:tier,RELEASE_OUT:`test-results/r18-release/final/${area}`},stdio:'inherit'});
 if(result.status!==0)process.exit(result.status??1);
}

const ssr=spawnSync(process.execPath,['--import','tsx','test-results/r18-release/ssr-cost.mjs'],{env:process.env,stdio:'inherit'});if(ssr.status!==0)process.exit(ssr.status??1);
