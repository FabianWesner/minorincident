import './capture-admission.mjs';
import{spawnSync}from'node:child_process';
const phase=process.argv[2];if(!['before-state','after-state'].includes(phase))throw Error('phase');
for(const [backend,tier,levels]of [['webgl2','low','L1,L4,L7'],['webgpu','high','L7']]){
 const r=spawnSync(process.execPath,['--import','tsx','test-results/r18-release/diagnostic-load.mjs',levels,backend],{env:{...process.env,RELEASE_CPU_PROFILE:'1',RELEASE_QUALITY:tier,RELEASE_SIDES:'candidate',RELEASE_OUT:`test-results/r18-release/causal/${phase}/${backend}-${tier}`},stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);
}
