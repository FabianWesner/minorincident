import json,pathlib,math
R=pathlib.Path('test-results/r18-release');D=pathlib.Path('docs/reports/r18-release')
read=lambda p:json.loads(p.read_text())
summary=read(R/'release-summary.json');events=read(R/'event-windows.json')
lines=['## Native frame matrix','','Milliseconds, WebGPU, one matched public-build capture per side and tier. See the comparison rules and coverage limitations above.','','| Level/tier | PROD p95 / max | Candidate p95 / max | Verdict / reason |','|---|---:|---:|---|']
def fmt(v):return f"{v['p95']:.2f} / {v['max']:.2f}" if v else '—'
for r in summary['native']:
 vals=[r['sides'].get(side,{}).get('stats')for side in ['prod','candidate']]
 lines.append(f"| {r['level']} {r['tier']} | {fmt(vals[0])} | {fmt(vals[1])} | {r['verdict']}{': '+', '.join(r['issues'])if r['issues']else''} |")
lines+=['','### Native event windows','','| Event/tier | PROD p95 / max | Candidate p95 / max | Verdict |','|---|---:|---:|---|']
for r in events:
 vals=[r['sides'].get(side,{}).get('stats')for side in ['prod','candidate']]
 lines.append(f"| {r['level']} {r['name']} {r['tier']} | {fmt(vals[0])} | {fmt(vals[1])} | {r['verdict']} |")
def stats(frames):
 a=sorted(f['ms']for f in frames);return {'p95':a[math.ceil(.95*len(a))-1],'max':max(a),'n':len(a),'durationMs':sum(a)}if a else None
endings=[]
for tier in ['low','high']:
 p=R/f'ending-{tier}.json';row={'tier':tier,'sides':{},'issues':[]}
 if p.exists():
  for r in read(p):
   v=r.get('result',{});row['sides'][r['side']]={'stats':stats(v.get('frames',[])),'finished':v.get('finished'),'failure':r.get('failure'),'errors':r['errors']}
   if r.get('failure')or r['errors']or not v.get('finished'):row['issues'].append(r['side']+': incomplete ending')
 if len(row['sides'])==2 and all(v.get('stats')for v in row['sides'].values()):
  p,c=(row['sides'][side]['stats']for side in ['prod','candidate'])
  if c['p95']>p['p95']+1+1e-6:row['issues'].append('p95 >PROD+1ms')
  if c['max']>p['max']+16.8+1e-6:row['issues'].append('max >PROD+one frame')
  if c['max']>=66-1e-6 and p['max']<66-1e-6:row['issues'].append('new >=66ms hitch')
 row['verdict']='INCOMPLETE'if len(row['sides'])<2 else'FAIL'if row['issues']else'PASS';endings.append(row)
lines+=['','### L10 natural ending through credits','','| Tier | PROD p95 / max | Candidate p95 / max | Verdict |','|---|---:|---:|---|']
for r in endings:
 vals=[r['sides'].get(side,{}).get('stats')for side in ['prod','candidate']];lines.append(f"| {r['tier']} | {fmt(vals[0])} | {fmt(vals[1])} | {r['verdict']} |")
lamps=[]
lines+=['','### L10 lamp-boundary recorded-input replay','','Each row must exceed100 playable frames, reach x>800 across both lamp boundaries, retain the requested backend, and have no post-card frame above200 ms. These established replays are profiled diagnostics and are excluded from the cold-load distributions.','','| Backend/entry | Frames | p95 / max ms | Endpoint x | Verdict |','|---|---:|---:|---:|---|']
for backend in ['webgpu','webgl2']:
 for entry in ['debug','continue']:
  p=R/'lamp'/f'{entry}-{backend}.json';row={'backend':backend,'entry':entry,'verdict':'INCOMPLETE'}
  if p.exists():
   v=read(p);ok=v['playableFrames']>100 and v['state']['transform']['x']>800 and v['max']<=200 and v['backend']in(['webgpu']if backend=='webgpu'else['webgl','webgl2']);row.update({'verdict':'PASS'if ok else'FAIL','frames':v['playableFrames'],'p95':v['p95'],'max':v['max'],'x':v['state']['transform']['x']});lines.append(f"| {backend} {entry} | {row['frames']} | {row['p95']:.2f} / {row['max']:.2f} | {row['x']:.2f} | {row['verdict']} |")
  else:lines.append(f'| {backend} {entry} | — | — | — | INCOMPLETE |')
  lamps.append(row)
(R/'ending-summary.json').write_text(json.dumps(endings,indent=2)+'\n');(R/'lamp-summary.json').write_text(json.dumps(lamps,indent=2)+'\n')
p=D/'README.md';s=p.read_text();start='<!-- native-matrix-start -->';end='<!-- native-matrix-end -->';block=start+'\n'+'\n'.join(lines)+'\n'+end
s=s[:s.index(start)]+block+s[s.index(end)+len(end):]if start in s else s+'\n\n'+block+'\n';p.write_text(s)
