import json,pathlib,math
R=pathlib.Path('test-results/r18-release')
read=lambda p:json.loads(p.read_text())
s=read(R/'release-summary.json');issues=[]
for r in s['loads']:
 if len(r['sides'])!=2:issues.append(f"cold {r['level']}/{r['backend']}/{r['tier']}: incomplete")
 for side,v in r['sides'].items():
  if v['n']!=20 or v['gameplaySamples']<1:issues.append(f"cold {r['level']}/{r['backend']}/{r['tier']}/{side}: missing samples or movement")
 for issue in r['issues']:
  if issue.startswith(('prod:','candidate:')):issues.append(f"cold {r['level']}/{r['backend']}/{r['tier']}: {issue}")
for r in s['native']:
 if len(r['sides'])!=2:issues.append(f"native {r['level']}/{r['tier']}: incomplete")
 for issue in r['issues']:
  if issue.startswith(('prod:','candidate:')):issues.append(f"native {r['level']}/{r['tier']}: {issue}")
events=read(R/'event-windows.json')
for r in events:
 if len(r['sides'])!=2:issues.append(f"event {r['level']}/{r['tier']}/{r['name']}: incomplete {r['issues']}")
for tier in ['low','high']:
 p=R/f'ending-{tier}.json'
 if not p.exists():issues.append(f'ending {tier}: absent');continue
 rows=read(p)
 if {r['side']for r in rows}!= {'prod','candidate'}:issues.append(f'ending {tier}: missing side')
 for r in rows:
  v=r.get('result',{});frames=v.get('frames',[])
  if r.get('failure')or r.get('errors')or not v.get('finished')or not frames or frames[-1]['phase']!='credits' or v.get('renderedFrameEnd',0)-v.get('renderedFrameStart',0)<1000:issues.append(f"ending {tier}/{r['side']}: incomplete rendered credits {r.get('failure')}")
for backend in ['webgpu','webgl2']:
 for entry in ['debug','continue']:
  p=R/'lamp'/f'{entry}-{backend}.json'
  if not p.exists():issues.append(f'lamp {entry}/{backend}: absent');continue
  v=read(p)
  if v['playableFrames']<=100 or v['state']['transform']['x']<=800:issues.append(f'lamp {entry}/{backend}: incomplete replay')
p=R/'invariants-prod-mirror'/'browser.json'
if not p.exists():issues.append('invariants PROD renderer: absent')
else:
 for level in range(1,11):
  q=R/'invariants-prod-mirror'/f'load-L{level}.json'
  if not q.exists():issues.append(f'invariants PROD renderer: L{level} missing')
  elif '4912'not in read(q)['baselineURL']:issues.append(f'invariants PROD renderer: L{level} wrong baseline')
out={'coverageComplete':not issues,'issues':issues,'coldConfigurations':len(s['loads']),'nativeConfigurations':len(s['native']),'eventWindows':len(events)}
(R/'coverage-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
