import pathlib,json
R=pathlib.Path('test-results/r18-release');x=json.load(open(R/'release-summary.json'));p=pathlib.Path('docs/reports/r18-release/README.md');s=p.read_text()
rows=['## Cold-load matrix','', 'Milliseconds; each complete cell has 20 fresh browser profiles per side. `post-card max` includes the first frames of every load and ten seconds of movement after the last load.','', '| Configuration | PROD median / p90 / max | Candidate median / p90 / max | Δ median | Candidate post-card max | Verdict |','|---|---:|---:|---:|---:|---|']
for r in x['loads']:
 a=r['sides'];fmt=lambda side:' / '.join(f'{a[side][k]:.2f}'for k in ['median','p90','max'])if side in a else'—';delta=f"{a['candidate']['median']-a['prod']['median']:+.2f}"if len(a)==2 else'—';frame=f"{a['candidate']['maxFrameMs']:.2f}"if'candidate'in a else'—';rows.append(f"| {r['level']} {r['backend']} {r['tier']} | {fmt('prod')} | {fmt('candidate')} | {delta} | {frame} | {r['verdict']} |")
start='<!-- load-matrix-start -->';end='<!-- load-matrix-end -->';text=start+'\n'+'\n'.join(rows)+'\n'+end
if start in s:s=s[:s.index(start)]+text+s[s.index(end)+len(end):]
else:s+='\n\n'+text+'\n'
p.write_text(s)
