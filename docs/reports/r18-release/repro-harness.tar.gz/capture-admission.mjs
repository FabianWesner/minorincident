// A queued exclusive request can outlive the cooldown checked by quiet-run's
// wrapper. Recheck the current completion stamp after it is actually granted.
import {readFileSync,appendFileSync}from'node:fs';
import{quietConditions}from'../../tools/browser-pool/host.ts';
for(;;){
 let last=0;try{last=Number(readFileSync((process.env.E2E_LOCK??'/tmp/minor-incident-e2e.lock')+'.quiet-finished','utf8'));}catch{}
 const conditions=await quietConditions(new Set());
 if(Date.now()>=last*1000+60000&&conditions.quiet){
  const row={at:new Date().toISOString(),pool:true,postQueueCooldown:true,...conditions};
  if(process.env.PERF_CONDITIONS_LOG)appendFileSync(process.env.PERF_CONDITIONS_LOG,JSON.stringify(row)+'\n');
  console.log('Capture admission after current cooldown: '+JSON.stringify(row));break;
 }
 await new Promise(done=>setTimeout(done,1000));
}
