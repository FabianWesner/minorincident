"""Recompute retained performance evidence; integrity and performance are separate results."""
import json,pathlib,hashlib,math
O=pathlib.Path('docs/reports/perf12')
def read(n):return json.loads((O/n).read_text())
def digest(b):return hashlib.sha256(b).hexdigest()
def stats(a):return dict(samples=len(a),p95=sorted(a)[math.ceil(.95*len(a))-1],maximum=max(a),spikes66=sum(x>=66-1e-6 for x in a))
def issues(p,c):
 out=[]
 if c['p95']>p['p95']+1+1e-6:out.append('p95 > PROD+1 ms')
 if c['maximum']>p['maximum']+16.8+1e-6:out.append('max > PROD+1 frame')
 if c['maximum']>=66-1e-6 and p['maximum']<66-1e-6:out.append('new >=66 ms spike')
 return out
checks=[]
def check(name,ok,detail=None):
 checks.append(dict(name=name,passCheck=bool(ok),detail=detail))
 if not ok:print('AUDIT FAIL',name,detail)
loads=read('loads.json');native=read('native.json');extras=read('extra-native.json');matrix=read('matrix.json');extra=read('extras.json');prov=read('provenance.json');build=read('build.json')
check('15 matrix cells and 9 named windows',len(matrix['matrix'])==15 and len(matrix['moments'])==9)
check('60 unique cold/warm loads',len(loads)==60 and len({(r['side'],r['level'],r['tier'],r['backend'],r['temperature'])for r in loads})==60)
check('24 unique native main captures',len(native)==24 and len({(r['side'],r['level'],r['tier'])for r in native})==24)
check('completed extra captures unique (2/18 collected)',len(extras)==2 and len({(r['side'],r['slice'],r['tier'])for r in extras})==2 and all(r['slice']=='wet'and r['tier']=='high'for r in extras))
check('fresh public build',build['exitCode']==0 and bool(prov['publicHookExclusion'])and build['revision']==prov['revision'])
check('committed runtime source',not prov['uncommittedSourceChanges'])
check('build precedes every final capture',build['finished']<=min(r['measuredAt']for r in loads+native+extras))
patches=read('instrumentation.json')['patchRows']
check('both original public bundle identities preserved',len(patches)==2 and all(x['originalSha256']==prov['prodBundleSha256'if x['side']=='prod'else'candidateBundleSha256']and x['originalSha256']!=x['patchedSha256']for x in patches))
for r in loads:
 name='/'.join(['load',r['side'],r['backend'],r['tier'],r['level'],r['temperature']])
 check(name+'/no errors and correct tier',not r['errors']and r['quality']==r['tier']and not r['diagnostic'])
 check(name+'/bundle',r['bundle'].endswith(prov['prodBundle'if r['side']=='prod'else'candidateBundle']))
 gpu=r['adapter']and r['adapter']['vendor']=='apple'and not r['adapter'].get('fallback')
 gl=r['glRenderer']and'Apple'in r['glRenderer']and'Metal'in r['glRenderer']and'SwiftShader'not in r['glRenderer']
 check(name+'/native backend',('webgpu'in r['contexts']and gpu)if r['backend']=='webgpu'else('webgl2'in r['contexts']and'webgpu'not in r['contexts']and gl))
 if r['level']=='L1'and r['backend']=='webgl2'and r['temperature']=='cold':check(name+'/G-01 Begin mission',r['begin'])
for r in native+extras:
 f=r['performance'];name='/'.join(['native',r['side'],r.get('slice',r['level']),r['tier']]);clock=f['warFrames']or f['chargeFrames']or f['missionFrames']
 minimum=60000 if 'slice'in r else 90000 if r['level']=='L1'or(r['level']=='L10'and r['tier']=='high')else 60000
 check(name+'/complete native duration',f['durationMs']>=minimum and sum(f['frames'])>=minimum and f['nonGameplayFrames']==0,dict(duration=f['durationMs'],frameSum=sum(f['frames']),minimum=minimum,nonGameplay=f['nonGameplayFrames']))
 check(name+'/no errors or CPU profiling',not r.get('failure')and not r['errors']and not r['diagnostic'])
 check(name+'/native Apple adapter',r['hardware']['vendor']=='apple'and r['hardware'].get('isFallbackAdapter')is False)
 check(name+'/actual backend and tier',all(s['backend']=='webgpu'and s['quality']==r['tier']and s['scenario']==r['level']and not s['loading']for s in r['samples']))
 check(name+'/frame statistics',stats(f['frames'])['maximum']==f['maxMs']and stats(f['frames'])['p95']==f['p95Ms'])
 check(name+'/ordinary input frames',r['inputFrames']>0)
 if clock:check(name+'/complete frame clocks',len(clock)==len(f['frames']))
for row in matrix['matrix']:
 name='/'.join(['matrix',row['backend'],row['tier'],row['level']]);bad=[]
 for t in ['cold','warm']:
  pair={s:next(r for r in loads if(r['side'],r['level'],r['tier'],r['backend'],r['temperature'])==(s,row['level'],row['tier'],row['backend'],t))for s in ['prod','candidate']}
  p,c=(pair[s]['ms']for s in ['prod','candidate'])
  if c>6000:bad.append(t+': >6 s')
  if c>p+500:bad.append(t+': >PROD+0.5 s')
  check(name+'/'+t+'/exact load values',all(row['loads'][s][t]==pair[s]['ms']for s in pair))
 if row['backend']=='webgpu':
  pair={s:next(r for r in native if(r['side'],r['level'],r['tier'])==(s,row['level'],row['tier']))for s in ['prod','candidate']}
  st={s:stats(r['performance']['frames'])for s,r in pair.items()};bad+=issues(st['prod'],st['candidate']);check(name+'/exact frame values',row['native']==st)
 check(name+'/verdict',row['issues']==bad and row['verdict']==('FAIL'if bad else'PASS'),bad)
for m in matrix['moments']:
 st={};kind=m['name']
 for side in ['prod','candidate']:
  r=next(r for r in native if(r['side'],r['level'],r['tier'])==(side,m['level'],m['tier']));f=r['performance'];events=f['events'];clock=f['missionFrames']or f['chargeFrames']
  if kind=='handover/outbreak':start=next(x['at']for x in f['missionFrames']if x['phase']=='handover')-100;end=next(x['at']for x in events if x['type']=='l1.infectedExit')+2000
  elif 'rocket'in kind or kind=='pickup':
   pickup=next(x for x in events if x['type']=='pickup.collected'and x.get('actionId')=='weapon.rocket-launcher');rocket=next(x for x in events if x['type']=='combat.attack'and x.get('actionId')=='weapon.rocket-launcher'and x.get('sourceId')==1);impact=next(x for x in events if x['type']=='explosion'and x.get('defId')=='explosion.rocket'and x.get('sourceId')==1 and x['at']>=rocket['at'])
   start=(rocket if kind=='first rocket'else pickup)['at']-100;end=(pickup if kind=='pickup'else impact)['at']+250
  else:start=0;end=next(x['at']for x in f['chargeFrames']if x['charge']>=3600)+2000
  indices=[i for i,x in enumerate(clock)if x['at']>=start and x['at']-f['frames'][i]<=end];st[side]=stats([f['frames'][i]for i in indices]);w=m['windows'][side]
  check('/'.join(['moment',m['level'],m['tier'],kind,side]),end<=f['durationMs']and w['startMs']==start and w['endMs']==end and w['indices']==indices and w['stats']==st[side])
 bad=issues(st['prod'],st['candidate']);check('moment/'+m['level']+'/'+m['tier']+'/'+kind+'/verdict',m['sides']==st and m['issues']==bad and m['verdict']==('FAIL'if bad else'PASS'))
for row in extra:
 st={};bad=[]
 for side in ['prod','candidate']:
  matches=[r for r in extras if(r['side'],r['slice'],r['tier'])==(side,row['slice'],row['tier'])]
  if not matches:bad.append(side+': missing capture');continue
  r=matches[0];st[side]=stats(r['performance']['frames']);coverage=row['coverage'][side]
  check('extra/'+row['slice']+'/'+row['tier']+'/'+side+'/stats',row['sides'][side]==st[side])
  field='car'if row['slice']=='drive'else'player';points=[s[field]for s in r['samples']]
  travel=sum(math.hypot(b['x']-a['x'],b['z']-a['z'])for a,b in zip(points,points[1:]))
  check('extra/'+row['slice']+'/'+row['tier']+'/'+side+'/exact route',abs(travel-coverage['sampledPathM'])<1e-8 and coverage['start']==points[0]and coverage['end']==points[-1])
  check('extra/'+row['slice']+'/'+row['tier']+'/'+side+'/route',travel>=50 if row['slice']!='wet'else all(x>.3 for x in coverage['wetness']))
  if row['slice']=='wet'and side=='candidate':check('wet high SSR remains active',all(x and x['active']for x in coverage['ssr']))
 if len(st)==2:bad+=issues(st['prod'],st['candidate'])
 check('extra/'+row['slice']+'/'+row['tier']+'/verdict',row['issues']==bad and row['verdict']==('perf pending'if len(st)<2 else'FAIL'if bad else'PASS'))
ssr=read('ssr-cost.json');check('SSR diagnostic explicitly pending',ssr.get('status')=='perf pending');check('SSR diagnostic errors absent',not ssr['errors']and len(ssr['rows'])==1)
for row in ssr['rows']:
 check('SSR diagnostic controls',row['weather']['wetness']>.3 and [g['ssrEnabled']for g in row['groups']]==[1,0,1,0])
 for i,g in enumerate(row['groups']):
  check('SSR diagnostic enabled state/'+str(i),g['snapshot']['ssr']['active']==bool(g['ssrEnabled']))
  check('partial SSR diagnostic sample count/'+str(i),len(g['samples'])==30)
mirror=read('mirror-audit.json');request=read('request-audit.json');live=read('live-control-final.json')
check('every mirrored file rehashed',mirror['files']>=2700 and not mirror['rehashFailures'])
check('deployed asset versions rehashed',mirror['assetVersionPaths']>=2000 and not mirror['assetVersionMismatches'])
check('runtime uses mirrored successful public files',request['requests']>0 and not request['badResponses']and not request['prodPathsMissingFromMirror']and not request['loadBadResponses']and not request['loadExternalURLs'])
check('pinned PROD bundle still live',live['pinnedBundleUnchanged'])
validation=read('validation.json')
check('four required validation commands pass on captured source',len(validation)==4 and all(r['exitCode']==0 and r['sourceTree']==prov['sourceTree']for r in validation))
for r in read('runs.json'):
 if r.get('admissionOnly'):
  conditions=[c for c in read('conditions.json')if c['source']==r.get('conditionsPath')]
  check('uncaptured admission timeout/'+r['label'],r['exitCode']==75 and r['admissionOnly']['nativeCaptureFiles']==0 and not any(c.get('quiet')is True for c in conditions)and any('admission reached the 600-second reservation cap'in line for line in r['terminalOutput']))
 elif r['label']!='validation'and (r['exitCode']==0 or r.get('phase')=='final'):check('quiet admission/'+r['label'],any(c.get('quiet')is True and c.get('pool')is True and c['source']==r.get('conditionsPath')for c in read('conditions.json')))
for name,v in prov['harnessSources'].items():check('reproduction source hash/'+name,digest(v['source'].encode())==v['sha256'])
attr=read('attribution12.json');check('cause commit and code match',any(x.startswith(attr['sourceFixCommit'])for x in prov['sourceFixCommits']))
check('six focused pairs conserve every linked program',len(attr['linkConservation'])==6 and all(x['sameTotalPrograms']and x['afterSync']<x['beforeSync']for x in attr['linkConservation']))
diag=read('diagnostic-loads.json')
for pair in attr['linkConservation']:
 for phase,label in [('before-state','before'),('after-state','after')]:
  rows=[r for r in diag if '/'+phase+'/'in r['rawSource']and r['level']==pair['level']and r['tier']==pair['tier']and r['temperature']==pair['temperature']]
  check('focused receipt unique/'+phase+'/'+pair['level']+'/'+pair['temperature'],len(rows)==1)
  if len(rows)!=1:continue
  r=rows[0];status=[x for x in r['tap']['status']if r['start']<=x['at']<=r['done']];sync=sum(not x['asyncPolled']for x in status)
  check('focused link census/'+phase+'/'+pair['level']+'/'+pair['temperature'],not r['errors']and pair[label+'Sync']==sync and pair[label+'Total']==len(status)and pair[label+'Async']==len(status)-sync)
check('model asset versions unchanged',attr['assetVersions']['assetVersionsUnchanged']and attr['assetVersions']['beforeAssetPaths']>=2000)
if(O/'cleanup.json').exists():
 cleanup=read('cleanup.json');check('owned raw output deleted and servers released',cleanup['rawPathsAbsent']and not cleanup['ownedProcesses']and not cleanup['ownedReservations']and cleanup['browserPoolRunning'])
performancePass=all(r['verdict']=='PASS'for r in matrix['matrix']+matrix['moments']+extra)
pending=[dict(scope='extra',slice=r['slice'],tier=r['tier'],reason=r['issues'])for r in extra if r['verdict']=='perf pending']+[dict(scope='SSR cost',reason=ssr['reason'])]
check('orchestrator stop recorded',read('capture-status.json')['status']=='perf pending'and len(pending)==9)
result=dict(performanceStatus='perf pending'if pending else'PASS'if performancePass else'FAIL',pending=pending,passAudit=all(x['passCheck']for x in checks),performancePass=performancePass,checks=len(checks),failures=[x for x in checks if not x['passCheck']],details=checks)
(O/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items()if k!='details'})
raise SystemExit(0 if result['passAudit']else 1)
