import {spawn}from'node:child_process';import{mkdirSync,writeFileSync,openSync,existsSync,readFileSync}from'node:fs';
const root='test-results/r18-release';mkdirSync(`${root}/native`,{recursive:true});const commands=[];
for(const tier of ['low','high'])for(const levels of ['L3,L5,L6','L4,L7,L8','L9','L10']){
 const id=levels.replaceAll(',','-'),out=`${root}/native/${id}-${tier}`,receipt=`${out}/strips/webgpu/${id}.json`;
 if(existsSync(receipt)&&JSON.parse(readFileSync(receipt)).filter(r=>!r.failure&&!r.errors.length).length===levels.split(',').length*2){console.log('retain '+id+'/'+tier);continue;}
 const start=Date.now(),log=`${root}/native/${id}-${tier}.log`,fd=openSync(log,'a');console.log('start '+id+'/'+tier);
 const child=spawn('node',[`${root}/run-job.mjs`,`native-${id}-${tier}`,'node','--import','tsx',`${root}/native.mjs`,'strips',levels,'webgpu'],{env:{...process.env,MI_SLUG:'r18-release',E2E_UNITS:'1',RELEASE_QUALITY:tier,RELEASE_OUT:out,RELEASE_SECONDS:levels.includes('L10')?'90':'60',RELEASE_PERF_ONLY:'1'},stdio:['ignore',fd,fd]});
 const code=await new Promise(resolve=>child.once('exit',resolve));commands.push({levels,tier,code,seconds:(Date.now()-start)/1000,log});writeFileSync(`${root}/native/commands.json`,JSON.stringify(commands,null,2)+'\n');console.log(JSON.stringify(commands.at(-1)));
}
