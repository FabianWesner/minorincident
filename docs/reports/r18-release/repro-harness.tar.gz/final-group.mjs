import './capture-admission.mjs';
import {spawnSync}from'node:child_process';
const [tier,group]=process.argv.slice(2);if(!['low','high'].includes(tier)||!['near','heavy','heavy-near','heavy-finale'].includes(group))throw Error('tier/group');
const jobs=group==='heavy-near'?[['L4,L7',60]]:group==='heavy-finale'?[['L10',90]]:group==='near'?[['L1',90],['L3,L5',60]]:tier==='low'?[['L4,L7,L10',60]]:[['L4,L7',60],['L10',90]];
for(const [levels,seconds]of jobs){
 const r=spawnSync(process.execPath,['--import','tsx','test-results/r18-release/native.mjs','strips',levels,'webgpu'],{env:{...process.env,RELEASE_QUALITY:tier,RELEASE_OUT:`test-results/r18-release/final/${tier}-${levels.replaceAll(',','-')}`,RELEASE_SECONDS:String(seconds),RELEASE_PERF_ONLY:'1'},stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);
}
