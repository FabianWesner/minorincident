import{spawnSync}from'node:child_process';
const [slice,level]=process.argv.slice(2),root='test-results/r18-release';
for(const tier of ['low','high']){
 const r=spawnSync(process.execPath,['--import','tsx',root+'/extra-native.mjs','strips',level,'webgpu'],{env:{...process.env,RELEASE_SLICE:slice,RELEASE_QUALITY:tier,RELEASE_OUT:root+'/extras/'+slice+'-'+tier,RELEASE_SECONDS:'60',RELEASE_PERF_ONLY:'1'},stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);
}

if(slice==='drive'){const r=spawnSync(process.execPath,['--import','tsx',root+'/ssr-cost.mjs'],{env:process.env,stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);}
