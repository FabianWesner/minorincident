import './capture-admission.mjs';
import {mkdirSync,writeFileSync} from 'node:fs';
import {launchBrowser} from '../../tools/browser-pool/client.ts';
const root='test-results/r18-release', out=root+'/ssr-cost.json', rows=[];
const browser=await launchBrowser({headless:true,args:['--use-angle=metal','--enable-gpu','--enable-unsafe-webgpu','--ignore-gpu-blocklist']});
try {
 const context=await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1});
 const page=await context.newPage();page.setDefaultTimeout(120000);const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.addInitScript('window.__name = fn => fn');
 await page.goto('http://127.0.0.1:4901/?test=poses&testApi=1&scenelab=1&preload=0&dpr=1&quality=high&audio=muted&seed=1');
 await page.waitForFunction(()=>!!window.__SS__);await page.evaluate(async()=>{const a=window.__SS__;await a.ready;a.pause();a.settings.set({quality:'high',cameraShake:false,cheapDof:false});await a.loadLevel('L1',{seed:1});a.pause();a.missions.begin();a.cheats.god(true);a.weather.override('rain',1);await a.step(4000);a.debug.figureJoints(false);a.camera.follow();a.camera.zoom(1.5);await a.screenshotReady();});
 const result=await page.evaluate(async()=>{
  const a=window.__SS__,g=window.__SCENE__.game,r=g.view.renderer,b=r.backend,post=g.view.postFx;
  if(!post?.wetReflections || !b.device?.features.has('timestamp-query')) throw Error('SSR and native GPU timestamps required');
  const begin=b.beginRender.bind(b),render=r.render.bind(r);let label='',contexts=[];b.trackTimestamp=true;
  r.render=(scene,camera)=>{const old=label;label=scene.name||scene.type;try{return render(scene,camera);}finally{label=old;}};
  b.beginRender=context=>{begin(context);contexts.push({uid:b.getTimestampUID(context),label:context.textures?.map(t=>t.name).filter(Boolean).join('+')||context.depthTexture?.name||label,width:context.width,height:context.height});};
  const device=b.device,query=device.createQuerySet({type:'timestamp',count:2});
  const resolved=device.createBuffer({size:16,usage:GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC});
  const readback=device.createBuffer({size:16,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});
  const groups=[];
  try {
   for(const enabled of [1,0,1,0]) {
    post.wetReflections.enabled.value=enabled;const samples=[];
    for(let i=0;i<35;i++) {
     contexts=[];r.nextNodeFrame();const f=r._nodes.nodeFrame;f.time=f.deltaTime=0;
     const wallStart=performance.now(),before=device.createCommandEncoder();before.beginComputePass({timestampWrites:{querySet:query,beginningOfPassWriteIndex:0}}).end();device.queue.submit([before.finish()]);
     g.view.update(1);const cpuSubmitMs=performance.now()-wallStart;
     const after=device.createCommandEncoder();after.beginComputePass({timestampWrites:{querySet:query,endOfPassWriteIndex:1}}).end();after.resolveQuerySet(query,0,2,resolved,0);after.copyBufferToBuffer(resolved,0,readback,0,16);device.queue.submit([after.finish()]);
     await readback.mapAsync(GPUMapMode.READ);const stamps=new BigUint64Array(readback.getMappedRange()),frameTimelineMs=Number(stamps[1]-stamps[0])/1e6;readback.unmap();const serializedFrameMs=performance.now()-wallStart;
     if(!(frameTimelineMs>0&&frameTimelineMs<1000))throw Error('Invalid whole-frame GPU timestamp bracket '+frameTimelineMs);
     const backendReportedMs=await r.resolveTimestampsAsync('render');
     const passes=contexts.map(c=>({...c,ms:b.hasTimestampQuery(c.uid)?b.getTimestamp(c.uid):null}));
     if(i>=5)samples.push({frameTimelineMs,serializedFrameMs,cpuSubmitMs,backendReportedMs,totalMs:passes.reduce((n,p)=>n+(p.ms??0),0),passes});
    }
    groups.push({ssrEnabled:enabled,snapshot:post.snapshot(),samples});
   }
  } finally {b.trackTimestamp=false;b.beginRender=begin;r.render=render;post.wetReflections.enabled.value=1;query.destroy();resolved.destroy();readback.destroy();}
  return {groups,weather:{wetness:g.world.weather.wetness,rain:g.world.weather.rain},device:[...b.device.features],tick:a.tick(),perf:a.perf()};
 });
 rows.push(result);await context.close();writeFileSync(out,JSON.stringify({method:'Diagnostic only: paused identical wet L1 high scene, alternating SSR on/off/on/off, 30 warmed WebGPU frames per block; a separate timestamp pair brackets the complete submitted frame, including submission gaps; serialized CPU+GPU wall time and pass inventory retained. Nested pass sums overlap and are not whole-frame costs; no verdict supplied by these timings',rows,errors},null,2));
 console.log(JSON.stringify({groups:result.groups.map(g=>({enabled:g.ssrEnabled,meanGpuTimelineMs:g.samples.reduce((n,s)=>n+s.frameTimelineMs,0)/g.samples.length})),errors}));
} finally {await browser.close();}
