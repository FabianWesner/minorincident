import json, pathlib, hashlib, subprocess, re, math, collections, datetime, copy
R=pathlib.Path('test-results/r18-release'); O=pathlib.Path('docs/reports/perf12'); O.mkdir(parents=True,exist_ok=True)
def read(p): return json.loads(pathlib.Path(p).read_text())
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def put(n,x): (O/n).write_text(json.dumps(x,indent=2)+'\n')
def cmd(*args): return subprocess.check_output(args,text=True).strip()
def stats(a): return dict(samples=len(a),p95=sorted(a)[math.ceil(.95*len(a))-1],maximum=max(a),spikes66=sum(x>=66-1e-6 for x in a))
def compare(p,c):
 issues=[]
 if c['p95']>p['p95']+1+1e-6: issues.append('p95 > PROD+1 ms')
 if c['maximum']>p['maximum']+16.8+1e-6: issues.append('max > PROD+1 frame')
 if c['maximum']>=66-1e-6 and p['maximum']<66-1e-6: issues.append('new >=66 ms spike')
 return dict(verdict='FAIL' if issues else 'PASS',issues=issues)
def compact(r,p):
 r=copy.deepcopy(r);r.update(rawSource=str(p),rawSha256=sha(p));r.pop('images',None)
 f=r.get('performance',{});inputs=f.pop('inputs',[])
 r.update(inputFrames=len(inputs),inputSha256=hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest())
 r['samples']=[{k:v for k,v in s.items() if k in ['wallSeconds','scenario','loading','tick','backend','quality','player','alive','alphas','phase','objective','l7Followers','weather','post','car']}for s in r.get('samples',[])]
 # Keep frame intervals, frame clocks, native events, builds and long tasks so verdicts can be independently recomputed.
 for k in ['cpuFrames','layoutCalls','navCalls','frozenBakes']: 
  if not f.get(k):f.pop(k,None)
 return r
loads=[];native=[];extras=[]
for p in sorted((R/'final').glob('*/loads/*.json')):
 for r in read(p):
  r.pop('resources',None);r.pop('frames',None);r.update(rawSource=str(p),rawSha256=sha(p));loads.append(r)
for p in sorted((R/'final').glob('*/strips/webgpu/*.json')):native += [compact(r,p)for r in read(p)]
for p in sorted((R/'extras').glob('*/strips/webgpu/*.json')):extras += [compact(r,p)for r in read(p)]
put('loads.json',loads);put('native.json',native);put('extra-native.json',extras);put('matrix.json',read(R/'summary-final.json'))
extra=[]
for slice,tier in [(s,t)for s in ['r4','r6','approach','drive']for t in ['low','high']]+[('wet','high')]:
 rows={r['side']:r for r in extras if r['slice']==slice and r['tier']==tier}
 row=dict(slice=slice,tier=tier,sides={},coverage={});issues=[]
 for side in ['prod','candidate']:
  r=rows.get(side)
  if not r or not r.get('performance'):issues.append(side+': missing capture');continue
  f=r['performance'];row['sides'][side]=stats(f['frames'])
  if r.get('failure')or r['errors']or r['diagnostic']or f['durationMs']<60000 or sum(f['frames'])<60000 or f['nonGameplayFrames']:issues.append(side+': invalid capture')
  field='car'if slice=='drive'else'player';points=[s[field]for s in r['samples']]
  travel=sum(math.hypot(b['x']-a['x'],b['z']-a['z'])for a,b in zip(points,points[1:]))
  row['coverage'][side]=dict(start=points[0],end=points[-1],sampledPathM=travel,ticks=f['endTick']-f['tick'],wetness=[s.get('weather',{}).get('wetness')for s in r['samples']],ssr=[s.get('post',{}).get('ssr')for s in r['samples']])
  if slice!='wet'and travel<50:issues.append(side+': insufficient native movement')
  if slice=='wet'and any((s.get('weather',{}).get('wetness')or 0)<=.3 for s in r['samples']):issues.append(side+': scene not wet')
  if slice=='wet'and side=='candidate'and not all(s.get('post',{}).get('ssr',{}).get('active')for s in r['samples']):issues.append('candidate: SSR not active')
 if len(row['sides'])==2:issues+=compare(row['sides']['prod'],row['sides']['candidate'])['issues']
 row.update(verdict='perf pending'if len(row['sides'])<2 else'FAIL'if issues else'PASS',issues=issues);extra.append(row)
put('extras.json',extra)
for name in ['runs.json','mirror.json','live-control-final.json','build.json','instrumentation.json','validation.json','ssr-cost.json','attribution12.json','build-before.json','initial-stop.json','source-equivalence.json','validation-before-budget-fix.json','wet-capture-receipt.json','capture-status.json']:
 if(R/name).exists():put(name,read(R/name))
for area,name in [('initial','initial-native.json'),('diagnostic','diagnostic-native.json'),('recheck','rechecks.json')]:
 rows=[compact(r,p)for p in sorted((R/area).glob('*/strips/webgpu/*.json'))for r in read(p)]
 if rows:put(name,rows)
if(R/'summary-initial.json').exists():put('initial-matrix.json',read(R/'summary-initial.json'))
initialLoads=[]
for p in sorted((R/'initial').glob('*/loads/*.json')):
 for r in read(p):
  r.pop('resources',None);r.pop('frames',None);r.update(rawSource=str(p),rawSha256=sha(p));initialLoads.append(r)
put('initial-loads.json',initialLoads)
diagnosticLoads=[]
for p in sorted((R/'causal').glob('*/*/loads/*.json')):
 for r in read(p):
  r.pop('resources',None);r.pop('frames',None)
  tap=r.get('tap',{});sources=tap.pop('shaderSources',[])
  tap['shaderSources']=[dict(id=x['id'],at=x['at'],bytes=len(x['source'].encode()),sha256=hashlib.sha256(x['source'].encode()).hexdigest())for x in sources]
  r.update(rawSource=str(p),rawSha256=sha(p));diagnosticLoads.append(r)
put('diagnostic-loads.json',diagnosticLoads)
conditions=[dict(json.loads(line),source=str(p))for p in sorted((R/'conditions').glob('*.jsonl'))for line in p.read_text().splitlines()if line];put('conditions.json',conditions)
put('host-waits.json',[dict(json.loads(line.split('Host wait before reservation: ',1)[1]),source=str(p))for p in sorted(R.glob('extras-batch*.log'))for line in p.read_text().splitlines()if line.startswith('Host wait before reservation: ')])
mirror=read(R/'mirror.json');bad=[]
for r in mirror['rows']:
 p=R/'prod'/('index.html'if r['path']=='/'else r['path'].lstrip('/'))
 if not p.is_file()or p.stat().st_size!=r['bytes']or sha(p)!=r['sha256']:bad.append(r['path'])
prodBundle=mirror['expectedBundle'];prod=R/'prod/build'/prodBundle;versions=[]
for path,expected in re.findall(r'"(/assets/[^"\n]+)":"([a-f0-9]{10})"',prod.read_text()):
 p=R/'prod'/path.lstrip('/');actual=sha(p)[:10]if p.is_file()else None;versions.append(dict(path=path,expected=expected,actual=actual,match=expected==actual))
put('asset-version-audit.json',versions);put('mirror-audit.json',dict(files=len(mirror['rows']),bytes=sum(x['bytes']for x in mirror['rows']),rehashFailures=bad,assetVersionPaths=len(versions),assetVersionMismatches=[x for x in versions if not x['match']]))
requests=read(R/'request-final.json')['requests'];ledger={r['path']for r in mirror['rows']};served={}
for x in requests:
 k=(x['side'],x['path']);a=served.setdefault(k,dict(side=x['side'],path=x['path'],count=0,statuses={}));a['count']+=1;a['statuses'][str(x['status'])]=a['statuses'].get(str(x['status']),0)+1
net=[v for r in loads for v in r['network']]
put('request-audit.json',dict(requests=len(requests),statuses=dict(collections.Counter(str(x['status'])for x in requests)),badResponses=[x for x in requests if x['status']not in[200,304]],prodPathsMissingFromMirror=sorted({x['path']for x in requests if x['side']=='prod'and not x['path'].startswith('/__perf6__/')and x['path']not in ledger and x['path']!='/index.html'}),loadBadResponses=[x for x in net if x['status']not in[200,304]],loadExternalURLs=[x['url']for x in net if not x['url'].removeprefix('blob:').startswith(('http://127.0.0.1:4901/','http://127.0.0.1:4902/'))],servedPaths=sorted(served.values(),key=lambda x:(x['side'],x['path']))))
main=re.search(r'src="/build/(index-[^" ]+\.js)"',pathlib.Path('dist/index.html').read_text()).group(1)
imports=['src/Game.ts','src/render/Renderer.ts','src/render/PreRenderer.ts','tests/shared/render-contracts.test.ts','src/core/Quality.ts','src/render/GameView.ts','tools/qa/release-ab-load.mjs','tools/qa/ab-tour.ts','tools/perf/quiet-run.sh','src/debug/testApi.ts','tools/browser-pool/client.ts','tools/browser-pool/wrapper.ts','tools/browser-pool/host.ts']
harness=['perf6-mirror.mjs','build-public.mjs','serve.mjs','run-job.mjs','native.mjs','extra-native.mjs','extras-batch.mjs','extra-group.mjs','ssr-cost.mjs','public-adapter.ts','final-batch.mjs','final-group.mjs','final-loads.mjs','summarize.py','validate.mjs','package12.py','audit12.py','report12.py','live-final.mjs','capture-admission.mjs','diagnostic-load.mjs','state-group.mjs','restore-batch59.mjs','wet-first.mjs','pipeline-load.mjs','serve-probe.mjs','attribute12.py','cleanup12.py']
put('provenance.json',dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),initialRevision='f3e603fbfa37fcc81335a85c6db1c3c328776256',revision=cmd('git','rev-parse','HEAD'),sourceTree=cmd('git','rev-parse','HEAD:src'),sourceFixCommits=cmd('git','log','--reverse','--format=%H %s','f3e603fb..HEAD','--','src').splitlines(),sourceDiff=cmd('git','diff','f3e603fb','HEAD','--','src'),uncommittedSourceChanges=cmd('git','diff','HEAD','--','src','tests','specs','package.json','package-lock.json'),candidateBundle=main,candidateBundleSha256=sha('dist/build/'+main),prodBundle=prodBundle,prodBundleSha256=sha(prod),sourceHashes={p:sha(p)for p in imports},harnessSources={str(R/n):dict(sha256=sha(R/n),source=(R/n).read_text())for n in harness if(R/n).exists()},toolchain=dict(node=cmd('node','--version'),playwright=read('node_modules/@playwright/test/package.json')['version'],chromium=next(x['browserVersion']for x in read('node_modules/playwright-core/browsers.json')['browsers']if x['name']=='chromium'),macOS=cmd('sw_vers','-productVersion'),macOSBuild=cmd('sw_vers','-buildVersion'),cpu=cmd('sysctl','-n','machdep.cpu.brand_string')),publicHookExclusion=[x for x in(R/'build.log').read_text().splitlines()if'[public-build]'in x]))
put('gate-receipts.json',{str(p):dict(sha256=sha(p),receipt=read(p))for p in[pathlib.Path('test-results/timings/test.json'),pathlib.Path('test-results/epics/E18/checks.json')]if p.exists()})
put('raw-manifest.json',[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(R.rglob('*'))if p.is_file()and'prod'not in p.relative_to(R).parts])
print(dict(loads=len(loads),native=len(native),extras=len(extras),mirrorFailures=len(bad)))
