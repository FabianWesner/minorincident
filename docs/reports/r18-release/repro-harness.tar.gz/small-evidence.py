import pathlib,json,gzip,hashlib,tarfile,shutil
R=pathlib.Path('test-results/r18-release');D=pathlib.Path('docs/reports/r18-release')
def emit(name,value):
 raw=(json.dumps(value,separators=(',',':'))+'\n').encode()
 with open(D/name,'wb')as f:
  with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as z:z.write(raw)
read=lambda p:json.loads(p.read_text())
for level in ['L1','L4','L7','L8','L10']:
 rows=[]
 for side in ['prod','candidate']:
  for p in sorted((R/'cold'/side).glob(f'{level}-*-*-*.json')):
   if p.stem.endswith('summary'):continue
   rows.append({'file':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sample':read(p)})
 assert len(rows)==160,(level,len(rows));emit(f'cold-{level}-raw.json.gz',rows)
allrows=[]
for p in(R/'native').glob('*/strips/webgpu/*.json'):
 for row in read(p):allrows.append({'file':str(p.relative_to(R)),'receipt':row})
for level in ['L3','L4','L5','L6','L7','L8','L9','L10']:
 rows=[r for r in allrows if r['receipt']['level']==level]
 for r in rows:r['receipt'].get('performance',{}).pop('inputs',None)
 emit(f'native-{level}-frames.json.gz',rows)
rows=read(R/'charge-full/low/strips/webgpu/L10.json')
for r in rows:r['performance'].pop('inputs',None)
emit('charge-full-low-frames.json.gz',rows)
emit('quiet-conditions.json.gz',{str(p.relative_to(R)):p.read_text()for p in(R/'conditions').glob('*')})
emit('run-ledger.json.gz',read(R/'runs.json'))
emit('invariants-initial-browser.json.gz',read(R/'invariants-initial/browser.json'))
emit('invariants-prod-browser.json.gz',read(R/'invariants-prod-mirror/browser.json'))
emit('invariants-prod-loads.json.gz',[read(p)for p in sorted((R/'invariants-prod-mirror').glob('load-*.json'))])
shutil.copyfile(R/'invariants-initial/run.json',D/'invariants-stages.json')
for n in ['release-summary.json','event-windows.json','ending-summary.json','lamp-summary.json','load-attribution.json','nonquiet-rerun.json','instrumentation.json']:
 shutil.copyfile(R/n,D/n)
for kind in ['L4','L9']:
 for p in(R/f'diagnostic-native-{kind}/strips/webgpu').glob('*.cpuprofile.gz'):shutil.copyfile(p,D/f'native-diagnostic-{p.name}')
for side in ['prod','candidate']:
 p=R/f'diagnostic-loads/{side}/L1-webgl2-low-0.cpuprofile.gz';shutil.copyfile(p,D/f'load-diagnostic-{side}.cpuprofile.gz')
# Preserve invalid timing data; exclude original build-overlap pair from qualified distributions.
emit('invalid-cold-build-overlap.json.gz',{str(p.relative_to(R)):read(p)for p in(R/'attempts/nonquiet-build').rglob('*.json')})
sources=[p for p in R.iterdir()if p.is_file()and p.suffix in ['.mjs','.ts','.py','.js']]
with tarfile.open(D/'repro-harness.tar.gz','w:gz')as t:
 for p in sources:t.add(p,arcname=p.name,recursive=False)
# Large traces and complete input streams remain local; inventory makes their location explicit.
local=[]
for p in R.rglob('*.zip'):
 if '/test-results/r18-release/test-results/'in str(p):continue
 local.append({'path':str(p),'bytes':p.stat().st_size})
(D/'local-trace-inventory.json').write_text(json.dumps(local,indent=2)+'\n')
print('Small evidence written; bytes',sum(p.stat().st_size for p in D.iterdir()if p.is_file()))
