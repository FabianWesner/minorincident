import fs from 'node:fs';import{spawnSync,execFileSync}from'node:child_process';import crypto from'node:crypto';
const root='test-results/r18-release';fs.mkdirSync(root+'/validation',{recursive:true});
const commands=[['npm','run','typecheck'],['npm','run','lint'],['npm','run','test:unit'],['npm','run','verify','--','E18']],rows=[];
for(let i=0;i<commands.length;i++){
 const command=commands[i],started=new Date().toISOString(),r=spawnSync(command[0],command.slice(1),{encoding:'utf8',maxBuffer:32*1024*1024});
 const output=r.stdout+r.stderr;fs.writeFileSync(`${root}/validation/${i}.log`,output);
 const row={command,started,finished:new Date().toISOString(),seconds:(Date.now()-Date.parse(started))/1000,revision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),sourceTree:execFileSync('git',['rev-parse','HEAD:src'],{encoding:'utf8'}).trim(),exitCode:r.status,signal:r.signal,outputSha256:crypto.createHash('sha256').update(output).digest('hex'),tail:output.split('\n').slice(-24)};
 rows.push(row);fs.writeFileSync(root+'/validation.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(row));if(r.status!==0)process.exit(r.status??1);
}
