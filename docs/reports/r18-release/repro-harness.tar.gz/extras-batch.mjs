import{quietConditions,delay}from'../../tools/browser-pool/host.ts';
import{spawnSync}from'node:child_process';
const root='test-results/r18-release';
for(const [slice,level]of [['r4','L10'],['r6','L10'],['approach','L10'],['drive','L9']]){
 let lastLog=0;for(;;){const c=await quietConditions(new Set());if(c.quiet)break;if(Date.now()-lastLog>=30000){console.log('Host wait before reservation: '+JSON.stringify({at:new Date().toISOString(),...c}));lastLog=Date.now();}await delay(1000);}
 const r=spawnSync(process.execPath,[root+'/run-job.mjs','extra-'+slice+(process.env.PERF_ATTEMPT?'-'+process.env.PERF_ATTEMPT:''),process.execPath,'--import','tsx',root+'/extra-group.mjs',slice,level],{stdio:'inherit',env:process.env});if(r.status!==0)process.exit(r.status??1);
}
