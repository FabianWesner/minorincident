import{spawnSync}from'node:child_process';
for(const[side,port]of[['prod',4902],['candidate',4901]]){
 const r=spawnSync(process.execPath,['--import','tsx','tools/perf/cold-load-time.ts',`http://127.0.0.1:${port}`,'webgl2','low','1','L1'],{env:{...process.env,LOAD_OUT:`test-results/r18-release/diagnostic-loads/${side}`,LOAD_TRACE:'1',LOAD_ASSERT:'0',LOAD_FRESH_BROWSER:'1',LOAD_GAMEPLAY_MS:'10000',LOAD_GAMEPLAY_LAST:'1'},stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);
}
