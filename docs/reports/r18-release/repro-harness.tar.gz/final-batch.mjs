import {spawnSync}from'node:child_process';
for(const [label,script,args]of [
 ['final-loads','test-results/r18-release/final-loads.mjs',[]],
 ['final-low-near','test-results/r18-release/final-group.mjs',['low','near']],
 ['final-high-near','test-results/r18-release/final-group.mjs',['high','near']],
 ['final-low-heavy','test-results/r18-release/final-group.mjs',['low','heavy']],
 ['final-high-heavy-near','test-results/r18-release/final-group.mjs',['high','heavy-near']],
 ['final-high-heavy-finale','test-results/r18-release/final-group.mjs',['high','heavy-finale']]
]){
 console.log(`START ${label} ${new Date().toISOString()}`);
 const r=spawnSync(process.execPath,['test-results/r18-release/run-job.mjs',label,process.execPath,'--import','tsx',script,...args],{env:process.env,stdio:'inherit'});console.log(`END ${label} status=${r.status}`);if(r.status!==0)process.exit(r.status??1);
}
