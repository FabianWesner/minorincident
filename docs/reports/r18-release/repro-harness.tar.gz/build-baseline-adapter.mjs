import{mkdirSync,existsSync,symlinkSync,writeFileSync,readFileSync,readdirSync,statSync}from'node:fs';import{execFileSync}from'node:child_process';import{build}from'esbuild';import{createHash}from'node:crypto';
const base='/private/tmp/r18-release-batch59-source-2741447',archive='/private/tmp/r18-release-batch59-source.tar',root='test-results/r18-release';
// Read-only Git source export for the version-matched diagnostic adapter; this is not a Git worktree.
if(!existsSync(base)){mkdirSync(base,{recursive:true});execFileSync('git',['archive','-o',archive,'2741447','src','tests','tools','layouts','public/assets/layouts','specs','package.json','package-lock.json','tsconfig.json','vite.config.ts']);execFileSync('tar',['-xf',archive,'-C',base]);symlinkSync(process.cwd()+'/node_modules',base+'/node_modules','dir');}
if(!existsSync(base+'/layouts/D-CURE/routes.json')){execFileSync('git',['archive','-o',archive+'.layouts','2741447','layouts']);execFileSync('tar',['-xf',archive+'.layouts','-C',base]);}
const entry=root+'/baseline-public-adapter.ts',source=readFileSync(root+'/public-adapter.ts','utf8').replace('../../src/debug/testApi',base+'/src/debug/testApi');writeFileSync(entry,source);
await build({entryPoints:[entry],outfile:root+'/baseline-public-adapter.js',bundle:true,format:'esm',platform:'browser',target:'es2022',minify:true,define:{__QA_HOOKS__:'true',__ASSET_VERSIONS__:'{}',__BUILD_COMMIT__:JSON.stringify('2741447-baseline-adapter'),'import.meta.env.DEV':'false'}});
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');const receipt={revision:execFileSync('git',['rev-parse','2741447'],{encoding:'utf8'}).trim(),sourceExport:base,entrySha256:sha(entry),apiSourceSha256:sha(base+'/src/debug/testApi.ts'),bundleSha256:sha(root+'/baseline-public-adapter.js'),packageLockMatchesCurrent:sha(base+'/package-lock.json')===sha('package-lock.json')};writeFileSync(root+'/baseline-adapter.json',JSON.stringify(receipt,null,2)+'\n');console.log(receipt);

const publicRows=[];
for(const name of readdirSync(root+'/public-dist',{recursive:true}).map(String))if(statSync(root+'/public-dist/'+name).isFile()){const a=root+'/public-dist/'+name,b='dist/'+name;publicRows.push({path:name,bytes:statSync(a).size,sha256:sha(a),matchesOriginal:existsSync(b)&&sha(a)===sha(b)});}
if(publicRows.some(r=>!r.matchesOriginal))throw Error('Immutable public snapshot differs from original production build');
writeFileSync(root+'/snapshot-files.json',JSON.stringify(publicRows,null,2)+'\n');
const mirror=JSON.parse(readFileSync(root+'/mirror.json')),mirrorChecks=mirror.rows.map(r=>({path:r.path,expected:r.sha256,actual:sha(root+'/prod/'+(r.path==='/'?'index.html':r.path.slice(1)))}));
if(mirrorChecks.some(r=>r.actual!==r.expected))throw Error('Pinned batch59 mirror drift');
writeFileSync(root+'/mirror-rehash.json',JSON.stringify({files:mirrorChecks.length,checks:mirrorChecks},null,2)+'\n');console.log({publicFiles:publicRows.length,allPublicBytesEqual:true,mirrorFiles:mirrorChecks.length,allMirrorHashesMatch:true});
