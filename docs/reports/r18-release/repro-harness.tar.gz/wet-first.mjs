import{spawnSync}from'node:child_process';
const root='test-results/r18-release';
for(const [script,args,env]of [[root+'/extra-native.mjs',['strips','L1','webgpu'],{RELEASE_SLICE:'wet',RELEASE_QUALITY:'high',RELEASE_OUT:root+'/extras/wet-high',RELEASE_SECONDS:'60',RELEASE_PERF_ONLY:'1'}],[root+'/ssr-cost.mjs',[],{}]]){
 const r=spawnSync(process.execPath,['--import','tsx',script,...args],{env:{...process.env,...env},stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);
}
