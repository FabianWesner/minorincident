import fs from 'node:fs';import crypto from 'node:crypto';
const root='test-results/r18-release',mirror=JSON.parse(fs.readFileSync(root+'/mirror.json')),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const checks=[];
for(const path of ['/', '/build/'+mirror.expectedBundle]){
 const r=await fetch(mirror.origin+path,{signal:AbortSignal.timeout(45000)}),b=Buffer.from(await r.arrayBuffer());
 checks.push({path,status:r.status,headers:Object.fromEntries(r.headers),bytes:b.length,sha256:hash(b),...(path==='/'?{index:b.toString()}: {})});
}
const pinned=checks[1],initialIndex=mirror.rows.find(r=>r.path==='/'),initialBundle=mirror.rows.find(r=>r.path==='/build/'+mirror.expectedBundle);
const receipt={at:new Date().toISOString(),initialIndexSha256:initialIndex.sha256,initialIndexHtml:fs.readFileSync(root+'/prod/index.html','utf8'),currentIndexSha256:checks[0].sha256,indexUnchanged:checks[0].sha256===initialIndex.sha256,pinnedBundleUnchanged:pinned.status===200&&pinned.sha256===initialBundle.sha256,checks};
fs.writeFileSync(root+'/live-control-final.json',JSON.stringify(receipt,null,2));console.log({indexUnchanged:receipt.indexUnchanged,pinnedBundleUnchanged:receipt.pinnedBundleUnchanged});
if(!receipt.pinnedBundleUnchanged)process.exitCode=1;
