import json,pathlib,statistics
R=pathlib.Path('test-results/r18-release'); result=[]
for level in ['L1','L4','L7','L8','L10']:
 for backend in ['webgpu','webgl2']:
  for tier in ['low','high']:
   tag=f'{level}-{backend}-{tier}';sides={}
   for side in ['prod','candidate']:
    files=list((R/'cold'/side).glob(tag+'-[0-9]*.json'))
    if len(files)!=20:break
    rows=[json.load(open(p))for p in files];names=set(m['name']for r in rows for m in r['measures'])
    phases={name:statistics.median([next(m['ms']for m in reversed(r['measures'])if m['name']==name)for r in rows if any(m['name']==name for m in r['measures'])])for name in names}
    resources=set(x['name']for r in rows for x in r['resources']if x['name'].startswith('/assets/'))
    sides[side]={'phaseMedians':phases,'assets':sorted(resources),'medianFrontierTransferBytes':statistics.median(sum(x['bytes']for x in r['resources'])for r in rows)}
   if len(sides)!=2:continue
   p,c=(sides[s]for s in ['prod','candidate']);delta={n:c['phaseMedians'][n]-p['phaseMedians'][n]for n in p['phaseMedians'].keys()&c['phaseMedians'].keys()}
   result.append({'id':tag,'sides':sides,'extraCandidateAssets':sorted(set(c['assets'])-set(p['assets'])),'phaseDeltasMs':dict(sorted(delta.items(),key=lambda x:x[1],reverse=True)),'note':'Resource frontier is the tool-recorded set whose response overlaps or follows the real click. Phase medians may overlap and must not be summed. Added destruction LOD1/burned residency is visible in DistrictView.load; attribution does not claim an exact single-commit counterfactual.'})
(R/'load-attribution.json').write_text(json.dumps(result,indent=2)+'\n');print('attribution cells',len(result))
