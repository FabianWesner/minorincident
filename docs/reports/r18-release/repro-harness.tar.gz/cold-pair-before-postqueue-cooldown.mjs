import {spawnSync} from 'node:child_process';
import {mkdirSync,writeFileSync} from 'node:fs';
const [level,backend,tier]=process.argv.slice(2), root='test-results/r18-release';
const rows=[]; const base={...process.env,LOAD_FRESH_BROWSER:'1',LOAD_GAMEPLAY_MS:'10000',LOAD_GAMEPLAY_LAST:'1',E2E_UNITS:'1'};
for(const [side,port] of [['prod',4912],['candidate',4911]]){
 const out=`${root}/cold/${side}`;mkdirSync(out,{recursive:true});const started=new Date().toISOString(),start=Date.now();
 const result=spawnSync(process.execPath,['--import','tsx','tools/perf/cold-load-time.ts',`http://127.0.0.1:${port}`,backend,tier,'20',level],{env:{...base,LOAD_OUT:out,LOAD_ASSERT:side==='candidate'?'1':'0',LOAD_BASELINE:`${root}/cold/prod`},stdio:'inherit'});
 rows.push({side,level,backend,tier,started,finished:new Date().toISOString(),seconds:(Date.now()-start)/1000,code:result.status,signal:result.signal});
 writeFileSync(`${root}/cold/${level}-${backend}-${tier}-command.json`,JSON.stringify(rows,null,2)+'\n');
}
process.exitCode=rows.some(r=>r.code!==0)?1:0;
