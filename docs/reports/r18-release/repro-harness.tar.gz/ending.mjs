import './capture-admission.mjs';
import {launchBrowser}from'../../tools/browser-pool/client.ts';
import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import{gunzipSync}from'node:zlib';import{createHash}from'node:crypto';
const tier=process.argv[2]??'low',out=`test-results/r18-release/ending-${tier}.json`;const rows=[];

const browser=await launchBrowser({headless:true,args:['--use-angle=metal','--enable-gpu','--ignore-gpu-blocklist','--enable-unsafe-webgpu']});
try{for(const[side,port]of[['prod',4912],['candidate',4911]]){
 const seedBytes=readFileSync(`test-results/r18-release/ending-seeds/${side}-${tier}.json.gz`),seed=JSON.parse(gunzipSync(seedBytes));
 const context=await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1}),page=await context.newPage(),row={side,tier,seed:seed.seed,seedSha256:createHash('sha256').update(seedBytes).digest('hex'),protectedCourier:true,errors:[],measuredAt:new Date().toISOString()};page.setDefaultTimeout(180000);page.on('pageerror',e=>row.errors.push(e.message));
 try{
  if(side==='prod')await page.route('**/__perf6__/api.js',route=>route.fulfill({path:'test-results/r18-release/baseline-public-adapter.js',contentType:'text/javascript'}));
  await page.addInitScript('window.__name=f=>f');await page.goto(`http://127.0.0.1:${port}/?test=poses&testApi=1&scenelab=1&profile=1&quality=${tier}&audio=muted&dpr=1`);
  await page.waitForFunction(()=>!!window.__SS__&&!!window.__SCENE__);await page.evaluate(async()=>{await window.__SS__.ready;window.__SS__.pause()});
  row.hardware=await page.evaluate(async()=>{const a=await navigator.gpu.requestAdapter();return{architecture:a.info.architecture,fallback:a.isFallbackAdapter??a.info.isFallbackAdapter}});
  row.start=await page.evaluate(async({seed,tier})=>{const a=window.__SS__,g=window.__SCENE__.game;a.campaign.restore(seed);await a.loadLevel('L10',{seed:seed.seed});a.pause();a.cheats.god(true);a.settings.set({quality:tier});a.bot.start('complete');return{tick:g.world.tick,phase:g.world.missions.state.epilogue?.phase,backend:a.perf().backend,quality:g.quality.tier}},{seed,tier});
  await page.evaluate(()=>{const a=window.__SS__,g=window.__SCENE__.game,r=window.__ending={running:true,renderedFrameStart:g.view.renderedFrames,frames:[],detached:false},sample=now=>{if(!r.running)return;const w=g.world,m=w.missions.state,phase=m.epilogue?.phase;if(phase==='playable'&&!r.detached){a.bot.stop();r.detached=true;}if(r.previous!==undefined)r.frames.push({ms:now-r.previous,tick:w.tick,phase:phase??m.phase,draws:g.view.renderer.info.render.drawCalls,triangles:g.view.renderer.info.render.triangles,elapsed:m.cureFront?.elapsed,loading:g.loading,level:w.scenario});r.previous=now;if(phase==='credits'){r.running=false;r.finished=true;return;}requestAnimationFrame(sample)};a.resume();requestAnimationFrame(sample)});
  await page.waitForFunction(()=>window.__ending.finished,undefined,{timeout:200000});
  row.result=await page.evaluate(()=>{const r=window.__ending,a=window.__SS__,g=window.__SCENE__.game;r.running=false;a.pause();return{...r,renderedFrameEnd:g.view.renderedFrames,backend:a.perf().backend,quality:g.quality.tier,epilogue:g.world.missions.state.epilogue,world:g.world.scenario}});
  if(row.result.backend!=='webgpu'||row.result.quality!==tier||!row.result.detached||row.result.frames.some(f=>f.loading||f.level!=='L10'))throw Error('Ending timing coverage or backend/tier mismatch');
 }catch(e){row.failure=String(e)}finally{await context.close();rows.push(row);writeFileSync(out,JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify({side,tier,failure:row.failure,frames:row.result?.frames.length}));}
}}finally{await browser.close()}
if(rows.some(r=>r.failure||r.errors.length))process.exitCode=1;
