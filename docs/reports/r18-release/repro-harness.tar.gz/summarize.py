import json,pathlib,math,hashlib,sys
R=pathlib.Path('test-results/r18-release')
AREA=sys.argv[1] if len(sys.argv)>1 else 'initial'
LEVELS=['L1','L3','L4','L5','L7','L10']
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(a):
 if not a:return None
 return dict(samples=len(a),p95=sorted(a)[math.ceil(.95*len(a))-1],maximum=max(a),spikes66=sum(v>=66-1e-6 for v in a))
def compare(p,c):
 if not p or not c:return dict(verdict='INCOMPLETE',issues=['missing frames'])
 issues=[]
 if c['p95']>p['p95']+1+1e-6:issues.append('p95 > PROD+1 ms')
 if c['maximum']>p['maximum']+16.8+1e-6:issues.append('max > PROD+1 frame')
 if c['maximum']>=66-1e-6 and p['maximum']<66-1e-6:issues.append('new >=66 ms spike')
 return dict(verdict='FAIL' if issues else 'PASS',issues=issues,inherited66=c['maximum']>=66-1e-6 and p['maximum']>=66-1e-6)
loads=[];native=[]
for p in sorted((R/AREA).glob('*/loads/*.json')):
 for r in read(p):loads.append(dict(r,rawSource=str(p),rawSha256=sha(p)))
for p in sorted((R/AREA).glob('*/strips/webgpu/*.json')):
 for r in read(p):native.append(dict(r,rawSource=str(p),rawSha256=sha(p)))
rows=[]
for backend,level,tier in [('webgpu',l,t) for t in ['low','high'] for l in LEVELS]+[('webgl2',l,'low') for l in ['L1','L4','L7']]:
 row=dict(backend=backend,level=level,tier=tier,loads={},native={});issues=[]
 for side in ['prod','candidate']:
  selected=[r for r in loads if (r['backend'],r['level'],r['tier'],r['side'])==(backend,level,tier,side)]
  row['loads'][side]={r['temperature']:r['ms'] for r in selected}
  if len(selected)!=2:issues.append(side+': missing cold/warm')
  if any(r['errors'] or r['quality']!=tier for r in selected):issues.append(side+': load error/tier mismatch')
 if all(len(row['loads'][s])==2 for s in ['prod','candidate']):
  for temp in ['cold','warm']:
   p,c=(row['loads'][s][temp] for s in ['prod','candidate'])
   if c>6000:issues.append(temp+': >6 s')
   if c>p+500:issues.append(temp+': >PROD+0.5 s')
 if backend=='webgpu':
  sides={r['side']:r for r in native if r['level']==level and r['tier']==tier}
  for side,r in sides.items():
   f=r.get('performance');row['native'][side]=stats(f['frames']) if f else None
   if r.get('failure') or r['errors'] or r['diagnostic'] or not f or f['durationMs']<60000 or sum(f['frames'])<60000 or f['nonGameplayFrames']:issues.append(side+': invalid native capture')
  if len(sides)==2:
   comparison=compare(row['native']['prod'],row['native']['candidate']);issues+=comparison['issues'];row['inherited66']=comparison['inherited66']
  else:issues.append('missing native capture')
 row.update(verdict='INCOMPLETE' if any('missing' in s for s in issues) else 'FAIL' if issues else 'PASS',issues=issues)
 rows.append(row)
def window(r,kind):
 f=r['performance'];events=f['events'];mf=f['missionFrames']
 def event(typ):return next(e for e in events if (e['type']=='pickup.collected' if typ=='pickup' else e['type']=='combat.attack') and e.get('actionId')=='weapon.rocket-launcher' and (typ=='pickup' or e.get('sourceId')==1))
 if kind=='handover/outbreak':
  start=next(x['at'] for x in mf if x['phase']=='handover')-100
  end=next(e['at'] for e in events if e['type']=='l1.infectedExit')+2000
 elif kind in ['pickup','first rocket','pickup through first rocket']:
  pickup=event('pickup');rocket=event('rocket')
  impact=next(e for e in events if e['type']=='explosion' and e.get('defId')=='explosion.rocket' and e.get('sourceId')==1 and e['at']>=rocket['at'])
  start=(rocket if kind=='first rocket' else pickup)['at']-100
  end=(pickup if kind=='pickup' else impact)['at']+250
 elif kind=='charge through completion (+2 s)':start=0;end=next(x['at'] for x in f['chargeFrames'] if x['charge']>=3600)+2000
 else:raise ValueError(kind)
 assert end<=f['durationMs'],(kind,end,f['durationMs'])
 # A delta ends at the corresponding frame timestamp. Include every interval
 # intersecting the event window, including the frame that straddles its edge.
 clock=mf if mf else f['chargeFrames']
 indices=[i for i,x in enumerate(clock) if x['at']>=start and x['at']-f['frames'][i]<=end]
 return dict(startMs=start,endMs=end,indices=indices,stats=stats([f['frames'][i] for i in indices]))
extraMoments=[] if AREA!='initial' else [dict(r,rawSource=str(p),rawSha256=sha(p)) for p in sorted((R/'moments').glob('*/strips/webgpu/*.json')) for r in read(p)]
moments=[]
for level,tier,kind in [(l,t,k) for l,ks in [('L1',['handover/outbreak']),('L7',['pickup','first rocket','pickup through first rocket'])] for t in ['low','high'] for k in ks]+[('L10','high','charge through completion (+2 s)')]:
 row=dict(level=level,tier=tier,name=kind,sides={},windows={})
 for r in ([r for r in extraMoments if r['level']==level and r['tier']==tier] or native):
  if r['level']==level and r['tier']==tier and r.get('performance'):
   try:
    w=window(r,kind);w['rawSource']=r['rawSource'];row['sides'][r['side']]=w['stats'];row['windows'][r['side']]=w
   except (StopIteration,AssertionError) as e:row.setdefault('missingWindow',[]).append(r['side']+': '+str(e))
 row.update(compare(row['sides'].get('prod'),row['sides'].get('candidate')));moments.append(row)
g01=[r for r in loads if r['backend']=='webgl2' and r['level']=='L1' and r['tier']=='low' and r['temperature']=='cold']
result=dict(matrix=rows,moments=moments,g01=[{k:r[k] for k in ['side','ms','begin','errors','rawSource']} for r in g01],loadRows=len(loads),nativeRows=len(native))
(R/('summary.json' if AREA=='initial' else 'summary-'+AREA+'.json')).write_text(json.dumps(result,indent=2))
for r in rows:print(r['backend'],r['level'],r['tier'],r['verdict'],r['issues'])
for r in moments:print('MOMENT',r['level'],r['tier'],r['name'],r['verdict'],r['issues'])
