"""Run after GPU jobs terminate; retain raw receipts, harnesses and SHA-256 manifest."""
import hashlib,json,pathlib,tarfile,io
R=pathlib.Path('test-results/r18-release'); D=pathlib.Path('docs/reports/r18-release')
folders=['cold','native','charge-full','ending','lamp','ending-seeds','conditions','logs','attempts','diagnostic-loads','diagnostic-native-L4','diagnostic-native-L9','invariants-initial','invariants-prod-mirror','invariants-mirror-startup-invalid-browser']
files=set()
for folder in folders:
 p=R/folder
 if p.exists():files.update(q for q in p.rglob('*')if q.is_file() and q.suffix != '.zip')
files.update(p for p in R.iterdir()if p.is_file()and p.suffix in ['.json','.mjs','.py','.ts','.js','.log','.txt','.gz'])
# The restored source archive is reproducible from the pinned Git object; no mirrored asset duplication.
manifest=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(files)]
raw=(json.dumps(manifest,indent=2)+'\n').encode();(D/'evidence-files.json').write_bytes(raw)
with tarfile.open(D/'evidence.tar.gz','w:gz',compresslevel=6)as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(R)),recursive=False)
 info=tarfile.TarInfo('evidence-files.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(D/'evidence.tar.gz','r:gz')as tar:
 for row in manifest:
  assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256'],row['path']
print('Verified',len(manifest),'files in evidence.tar.gz')
