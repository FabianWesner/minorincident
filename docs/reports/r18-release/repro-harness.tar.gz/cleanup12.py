import pathlib,json,shutil,datetime,subprocess,urllib.request,re
R=pathlib.Path('test-results/r18-release');O=pathlib.Path('docs/reports/perf12');D=pathlib.Path('dist')
stop=json.loads((R/'server-stop.json').read_text());assert stop['stoppedOwnedServers']
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
owned=[line for line in ps.splitlines()if re.search(r'^\s*\d+\s+(?:\S*/)?node\s+.*test-results/r18-release/(?:serve(?:-probe)?|run-job|native|extra-native|final-batch|extras-batch|ssr-cost)\.mjs(?:\s|$)',line)]
assert not owned,owned
with urllib.request.urlopen('http://127.0.0.1:4329/health',timeout=5)as response:health=json.load(response)
reservations=[x for k in ['exclusive','leases','waiters']for x in health.get(k,[])if x.get('job')=='perf12'];assert not reservations,reservations
raw=[p for p in R.rglob('*')if p.is_file()];build=[p for p in D.rglob('*')if p.is_file()]
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),rawFilesDeleted=len(raw),rawBytesDeleted=sum(p.stat().st_size for p in raw),buildFilesDeleted=len(build),buildBytesDeleted=sum(p.stat().st_size for p in build),stoppedOwnedServers=stop['stoppedOwnedServers'],ownedProcesses=owned,ownedReservations=reservations,browserPoolRunning=True)
shutil.rmtree(R);shutil.rmtree(D);result['rawPathsAbsent']=not R.exists()and not D.exists();assert result['rawPathsAbsent']
(O/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
