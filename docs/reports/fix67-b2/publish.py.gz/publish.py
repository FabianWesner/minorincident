from pathlib import Path
import gzip,json,hashlib,subprocess,datetime,re
root=Path('docs/reports/fix67-b2');runroot=Path('test-results/fix67-b2');canonical=Path('docs/reports/fix51-verify')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def gzsave(name,data):
 with gzip.open(root/name,'wb')as f:f.write(data)
receipts={f'{level}-{tier}-{kind}.json':read(canonical/'receipts'/f'{level}-{tier}-{kind}.json')for level in ['L4','L5']for tier in ['low','high']for kind in ['complete','stationary','fixtures','checkpoints']}
source=receipts['L4-low-complete.json']['sourceHash'];revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert all(p['sourceHash']==source for p in receipts.values())
tank=json.load(gzip.open(root/'final-tank.json.gz'));assert tank['sourceHash']==source
rows=[]
for r in tank['rows']:
 native=receipts[f"L4-{r['tier']}-complete.json"]
 assert r['finalHash']==native['nativeStateHash']==r['canonicalHash']
 shots=r['shots'];war=[s for s in shots if s['phase']=='war'];gaps=[(b['tick']-a['tick'])/60 for a,b in zip(war,war[1:])]
 minimum=min(a['distance']for s in shots for a in s['protected']);forced=min(a['distance']for a in shots[-1]['protected'])
 assert minimum>=15 and all(8<=g<=12 for g in gaps)
 rows.append({'tier':r['tier'],'shotCount':len(shots),'minimumProtectedClearanceM':minimum,'forcedClearanceM':forced,'warIntervalsSeconds':gaps,'canonicalHash':r['finalHash']})
metrics=[]
census=[]
for level in ['L4','L5']:
 for tier in ['low','high']:
  for policy in ['complete','stationary']:
   p=receipts[f'{level}-{tier}-{policy}.json'];assert not p['error']
   combat=next(x for x in p['threat']['phases']if x['key']==('step/hold'if level=='L4'else'step/look'))
   bounded=combat['boundedPaths'];assert bounded['samples'] and bounded['minimumPercent']>=90
   if level=='L5'and policy=='complete':
    assert combat['attacksPerMinute']+combat['groupAttacksPerMinute']>=3
    initial=[e for e in p['observation']['initial']['census']if e['infected'] and e['hp']>0]
    alphas=[e for e in initial if 'alpha' in e['archetype']]
    assert len(initial)==(100 if tier=='low'else 150) and len(alphas)==2
    census.append({'tier':tier,'initialInfected':len(initial),'initialAlphas':len(alphas),'alphaPositions':[{'id':e['id'],'x':e['x'],'z':e['z']}for e in alphas]})
   metrics.append({'level':level,'tier':tier,'policy':policy,'boundedPaths':bounded,'playerAttacksPerMinute':combat['attacksPerMinute'],'groupAttacksPerMinute':combat['groupAttacksPerMinute'],'firstPlayerAttackSeconds':combat['firstAttackSeconds'],'nativeStateHash':p['nativeStateHash'],'outcome':p['run']['outcome']})
  for kind in ['fixtures','checkpoints']:
   p=receipts[f'{level}-{tier}-{kind}.json'];assert not p['errors']
   if kind=='checkpoints':assert p['control']['identical']
audit=read('test-results/qa-threat/audit.json');assert audit['revision']==revision and not audit['flags'] and len(audit['levels'])==10
assert int((runroot/'threat-exit.txt').read_text())==0
for name in ['typecheck','lint','test']:assert int((runroot/f'{name}-exit.txt').read_text())==0
summaries={}
for level in ['L4','L5']:
 p=read(canonical/f'{level}.json');assert p['sourceHash']==source
 summaries[level]={'rowFailures':[r['id']for r in p['rows']if r['currentStatus']=='FAIL'],'globalFailures':[r['id']for r in p['globals']if r['currentStatus']=='FAIL'],'incompleteRows':[r['id']for r in p['rows']if r['currentStatus']=='NOT CHECKED'],'L5-05':next((r['currentStatus']for r in p['rows']if r['id']=='L5-05'),None)}
assert summaries['L5']['L5-05']=='PASS'
assert receipts['L5-high-complete.json']['nativeStateHash']=='f14b9e54'
assert 'G-13' not in summaries['L5']['globalFailures']
g13=next(r for r in read(canonical/'L5.json')['globals']if r['id']=='G-13')
assert g13['currentStatus']!='FAIL' and all(c['status']=='PASS'for c in g13['checks'])
gzsave('canonical-receipts.json.gz',json.dumps(receipts).encode())
for name,path in [('threat-audit.json.gz','test-results/qa-threat/audit.json'),('threat-budget.json.gz','test-results/timings/qa-threat.json')]:gzsave(name,Path(path).read_bytes())
for name in ['accept-L4','accept-L5','accept-L4-low','accept-L4-high','accept-L5-low','accept-L5-high','typecheck','lint','test','threat','final-tank']:
 p=runroot/f'{name}.log';gzsave(name+'.log.gz',p.read_bytes())
result={'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'codeCommit':revision,'sourceHash':source,'truck':{'x':16.3,'z':-45},'northernAlpha':{'low':{'x':-42,'z':-41.5},'high':{'x':-40,'z':-37.4}},'tank':rows,'L5InitialCensus':census,'native':metrics,'acceptance':summaries,'G13':{'status':g13['currentStatus'],'measuredChecks':[{'clause':c['clause'],'tier':c['tier'],'policy':c['policy'],'status':c['status']}for c in g13['checks']]},'threat':{'exit':0,'levels':len(audit['levels']),'flags':audit['flags'],'seconds':audit['seconds'],'loadBefore':read(runroot/'threat-load.json')},'gates':{name:int((runroot/f'{name}-exit.txt').read_text())for name in ['accept-L4','accept-L5','typecheck','lint','test','threat','final-tank']},'evidence':{str(p):sha(p)for p in sorted(root.iterdir())if p.is_file()and p.suffix!='md'and p.name!='qualification.json'}}
(root/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
