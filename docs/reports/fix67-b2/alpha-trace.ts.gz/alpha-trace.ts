import { writeFileSync } from 'node:fs';
import { preset } from '../../src/sim/progression/Campaign';
import { LevelFiveBot } from '../../src/debug/bot/LevelFiveBot';
import { loadLevel } from '../../tools/sim-runner/levels';
import { PathProbe } from '../../tools/qa/threat/observer';
const save=preset('L5-default');save.settings.quality='low';
const w=await loadLevel('L5',1,save,0,{quality:'low'});
try{const bot=new LevelFiveBot(w,'complete');const snapshots=[];const paths=new PathProbe();
for(let i=0;i<2400;i++){w.applyInput(bot.sample(),'keyboard');w.update();
 if([1,1800,2100,2237,2357].includes(w.tick)){
 const a=w.entities.get(97)!;const p=w.entities.get(1)!;const nav=w.infected!.navigation.grid(a.transform);
 snapshots.push({tick:w.tick,alpha:structuredClone(a),player:structuredClone(p.transform),nativeGoal:w.infected!.navigation.target(a.transform,p.transform),direct:Math.hypot(a.transform.x-p.transform.x,a.transform.z-p.transform.z),path:paths.distance(nav,a,p.transform),walls:(nav as any).walls,center:nav.center});
 }}writeFileSync('test-results/fix67-b2/alpha-trace.json',JSON.stringify(snapshots));console.log(snapshots.map(s=>({tick:s.tick,at:s.alpha.transform,player:s.player,direct:s.direct,path:s.path,goal:s.nativeGoal})));}
finally{w.dispose();}
