import { writeFileSync } from 'node:fs';
import { preset } from '../../src/sim/progression/Campaign';
import { stateHash } from '../../src/sim/world/stateHash';
import { runLevel } from '../../tools/sim-runner/levels';
import { provenance } from '../../tools/qa/accept/probe';
const rows=[];
for(const tier of ['low','high'] as const){
 const save=preset('L4-default');save.settings.quality=tier;
 const shots: any[]=[];let finalHash='';
 const run=await runLevel('L4','complete',1,undefined,'auto',save,undefined,0,{quality:tier,beforeBegin:w=>{
 w.events.on('l4.tankFire',ev=>{if(ev.type!=='l4.tankFire')return;const s=w.missions!.state.l4!;
 const ids=[...new Set([1,...s.soldierIds,...s.armed.map(a=>a.id)])];
 shots.push({...ev,phase:s.phase,protected:ids.flatMap(id=>{const e=w.entities.get(id);if(!e||e.health.current<=0||id!==1&&!e.civilian)return[];return[{id,at:{...e.transform},health:{...e.health},distance:Math.hypot(e.transform.x-ev.to.x,e.transform.z-ev.to.z)}]})});
 },8);},beforeDispose:w=>{finalHash=stateHash(w.getState());}});
 rows.push({tier,run,finalHash,shots});
 console.log(tier,JSON.stringify({min:Math.min(...shots.flatMap(s=>s.protected.map((p:any)=>p.distance))),forced:Math.min(...shots.at(-1).protected.map((p:any)=>p.distance)),finalHash}));
}
writeFileSync('test-results/fix67-b2/tank-screen.json',JSON.stringify({...provenance(),rows}));
