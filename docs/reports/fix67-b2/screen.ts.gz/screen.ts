import { writeFileSync } from 'node:fs';
import { preset } from '../../src/sim/progression/Campaign';
import { stateHash } from '../../src/sim/world/stateHash';
import { runLevel } from '../../tools/sim-runner/levels';
import { ThreatObserver } from '../../tools/qa/threat/observer';
import { provenance } from '../../tools/qa/accept/probe';
const tier = (process.argv[2] ?? 'low') as 'low' | 'high';
const campaign = preset('L5-default'); campaign.settings.quality = tier;
let observer: ThreatObserver, result: unknown;
const run = await runLevel('L5', 'complete', 1, undefined, 'auto', campaign, undefined, 0, {
 quality: tier, beforeBegin: w => { observer = new ThreatObserver(w, 'L5'); },
 beforeDispose: w => { result = { finalHash: stateHash(w.getState()), threat: observer.finish() }; },
});
const receipt = { ...provenance(), tier, run, ...(result as object) };
writeFileSync(`test-results/fix67-b2/screen-${tier}.json`, JSON.stringify(receipt));
console.log(JSON.stringify({sourceHash:receipt.sourceHash,tier,run,phases:(receipt as any).threat.phases.filter((p:any)=>p.threat).map((p:any)=>({key:p.key,bounded:p.boundedPaths,rate:p.attacksPerMinute}))}));
