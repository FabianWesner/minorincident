/** Current underground PNGs with exact courier and depth-tested crowd-eye masks. */
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import type { Game } from '../../src/Game';
import type { RenderProbes } from '../../src/render/RenderProbes';
import { preset } from '../../src/sim/progression/Campaign';
import { SceneSession, stopServer } from '../scenelab/session';
import { provenance } from './accept/probe';
const requested = process.argv[2]; if (requested !== 'low' && requested !== 'high') throw new Error('Expected low/high');
const tier: 'low' | 'high' = requested, out = `test-results/sweep-b/L6-readability-${tier}`;
mkdirSync(`${out}/captures`, { recursive: true });
const session = new SceneSession({ tier, backend: 'webgl2', query: { profile: '0', ui: '0' } });
try {
  await session.open(); const save = preset('L6-default'); save.settings.quality = tier;
  const state = await session.page.evaluate(async ({ tier, save }) => {
    const a = window.__SS__!; a.settings.set({ quality: tier }); a.campaign.restore(save); await a.loadLevel('L6', { seed: 1 });
    a.pause(); a.missions.begin(); a.cheats.god(false); a.cheats.completeObjective('shelter');
    a.teleport(1, { x: 110, z: 15 }); a.camera.follow(); a.camera.zoom(1.5);
    const g = (window.__SCENE__ as unknown as { game: Game }).game, w = g.world;
    const enemy = w.infected!.active.find(e => e.health.current > 0 && !e.hidden && e.infected?.l1)!;
    if (!enemy) throw new Error('No actual breach infected to present');
    a.teleport(enemy.id, { x: 113.5, z: 15 });
    await a.step(30); enemy.transform.yaw = -Math.PI / 4; g.view.update(1); await a.screenshotReady();
    const probes = (g.view as unknown as { probes: RenderProbes }).probes; probes.setHidden({ courier: false, crowd: false, bars: true }); g.view.update(1); await a.screenshotReady();
    return { tick: w.tick, tier: w.infected!.director.tier, renderTier: g.view.getState().quality, god: w.combat!.damage.god, player: { ...w.entities.get(1)!.transform }, enemy: { id: enemy.id, archetype: enemy.archetype, at: { ...enemy.transform }, appearance: enemy.appearance, infected: enemy.infected }, figures: a.crowdFigures().filter(f => f.id === enemy.id), lighting: g.view.getState().lighting, camera: g.view.getState().camera, mainPower: w.missions!.state.l6!.mainPower, emergency: w.missions!.state.l6!.emergency, flashlight: w.missions!.state.l6!.flashlight };
  }, { tier, save });
  const captures: { file: string; sha256: string }[] = [];
  const capture = async (name: string) => { const file = `${out}/captures/${name}.png`; await session.ready(); await session.page.screenshot({ path: file }); captures.push({ file, sha256: createHash('sha256').update(readFileSync(file)).digest('hex') }); };
  await capture('native');
  await session.page.evaluate(() => { const g = (window.__SCENE__ as unknown as { game: Game }).game; (g.view as unknown as { probes: RenderProbes }).probes.setHidden({ courier: true, crowd: false, bars: true }); g.view.update(1); });
  await capture('courier-hidden');
  await session.page.evaluate(() => { const g = (window.__SCENE__ as unknown as { game: Game }).game, p = (g.view as unknown as { probes: RenderProbes }).probes; p.setHidden({ courier: false, crowd: false, bars: true }); p.idPass = true; g.view.update(1); });
  await capture('courier-id');
  await session.page.evaluate(async () => {
    const g = (window.__SCENE__ as unknown as { game: Game }).game; (g.view as unknown as { probes: RenderProbes }).probes.idPass = false; g.view.update(1);
    const path = '/tools/scenelab/hat-eye-mask.ts'; const { installEyeMask } = await import(path);
    (window as unknown as { sweepEye: ReturnType<typeof installEyeMask> }).sweepEye = installEyeMask(g);
    (window as unknown as { sweepEye: { set(eyes: boolean, hats: boolean): void } }).sweepEye.set(false, true);
  });
  await capture('eyes-black');
  await session.page.evaluate(() => (window as unknown as { sweepEye: { set(eyes: boolean, hats: boolean): void } }).sweepEye.set(true, true));
  await capture('eyes-white');
  await session.page.evaluate(() => (window as unknown as { sweepEye: { restore(): void } }).sweepEye.restore());
  writeFileSync(`${out}/ledger.json`, JSON.stringify({ ...provenance(), producerSha256: createHash('sha256').update(readFileSync('tools/qa/sweep-b-l6-readability.ts')).digest('hex'), eyeMaskHelperSha256: createHash('sha256').update(readFileSync('tools/scenelab/hat-eye-mask.ts')).digest('hex'), method: 'Explicit underground presentation fixture at original tunnel x110/z15, actual first-breach infected identity moved nearby, mortal player, unchanged light preset/power. Paused exact pose; native lossless PNG then same-pose courier-hidden background and production magenta courier ID pass. Existing depth-tested eye-mask helper captures black/white eye IDs with hats retained. Health bars suppressed for scene luminance. No game changes or performance measurements.', state, captures, errors: session.errors }, null, 2)+'\n');
  console.log(tier, JSON.stringify(state));
} finally { await session.close(); stopServer(); }
