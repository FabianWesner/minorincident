import { fork } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const out = process.argv[2]; await mkdir(out, { recursive: true });
const variants = {
  default: [],
  noMaglev: ['--no-maglev'],
  inline: ['--max-inlined-bytecode-size=1000', '--max-inlined-bytecode-size-cumulative=4000', '--max-inlined-bytecode-size-small=100'],
  turbolev: ['--turbolev'],
};
const results = await Promise.all(Object.entries(variants).map(([mode, flags]) => new Promise((resolve, reject) => {
  let timing;
  const child = fork('tools/qa/.r2-runtime-probe.ts', [`${out}/${mode}.json`], { execArgv: [...flags, '--import', 'tsx/esm'], stdio: ['ignore', 'inherit', 'inherit', 'ipc'] });
  child.once('message', value => { timing = value; });
  child.once('error', reject);
  child.once('exit', code => code === 0 && timing ? resolve({ mode, flags, ...timing }) : reject(new Error(`${mode}: exit ${code}`)));
})));
const baseline = JSON.parse(await readFile(`${out}/default.json`, 'utf8'));
for (const { mode } of results) assert.deepEqual(JSON.parse(await readFile(`${out}/${mode}.json`, 'utf8')), baseline);
const summary = { node: process.version, platform: process.platform, architecture: process.arch, workers: 4, identical: true, results };
await writeFile(`${out}/summary.json`, JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary));
