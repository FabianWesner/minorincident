import { runLevel } from '../sim-runner/levels';
import { preset } from '../../src/sim/progression/Campaign';
import { ThreatObserver } from './threat/observer';
import { stateHash } from '../../src/sim/world/stateHash';
import { writeFile } from 'node:fs/promises';
const campaign = preset('L4-default'); campaign.seed = 1; campaign.settings.quality = 'low';
let observer: ThreatObserver; let observation: ReturnType<ThreatObserver['finish']>; let hash: string;
const start = performance.now(), cpu = process.cpuUsage();
const run = await runLevel('L4', 'complete', 1, undefined, 'auto', campaign, undefined, 0, {
  quality: 'low', beforeBegin: world => { observer = new ThreatObserver(world, 'L4'); },
  beforeDispose: world => { observation = observer.finish(); hash = stateHash(world.getState()); },
});
await writeFile(process.argv[2], JSON.stringify({ run, observation: observation!, hash: hash! }));
const used = process.cpuUsage(cpu);
process.send!({ seconds: (performance.now() - start) / 1000, cpuSeconds: (used.user + used.system) / 1e6 });
process.disconnect();
